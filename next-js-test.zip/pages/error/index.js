import React from 'react'

const Error = () => {
  return (
    <div>Sorry</div>
  )
}

export default Error