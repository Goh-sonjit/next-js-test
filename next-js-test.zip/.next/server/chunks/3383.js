exports.id = 3383;
exports.ids = [3383];
exports.modules = {

/***/ 3383:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

const jwtToken = __webpack_require__(9344);
const cookie = __webpack_require__(4802);
const catchError = __webpack_require__(7296);
exports.token = catchError(async (userid, statuscode, res)=>{
    const token = jwtToken.sign({
        id: userid
    }, "thisismysecretejsonWebToken", {
        expiresIn: "7d"
    });
    const option = {
        path: "/",
        httpOnly: true,
        expires: new Date(Date.now() + 7 * 24 * 3600000),
        httpOnly: false,
        sameSite: "strict"
    };
    return res.status(statuscode).setHeader("Set-Cookie", cookie.serialize(String(userid), token, option)).json({
        success: true,
        message: "Login Successfully"
    });
});
exports.verifyToken = catchError(async (req, res, next)=>{
    const cookieData = req.cookies;
    if (!cookieData) {
        return res.status(400).json({
            message: "No Cookie Found"
        });
    }
    const token = Object.values(cookieData)[0];
    if (!token) {
        return res.status(400).json({
            message: "No Token Found"
        });
    } else {
        return jwtToken.verify(token, "thisismysecretejsonWebToken", async (err, user)=>{
            if (err) {
                return res.status(206).json({
                    message: "InValid Token"
                });
            } else {
                req.id = user.id;
                next();
            }
        });
    }
});


/***/ })

};
;