"use strict";
exports.id = 3462;
exports.ids = [3462];
exports.modules = {

/***/ 3462:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3590);
/* harmony import */ var _allApi_apis__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1889);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_2__, _allApi_apis__WEBPACK_IMPORTED_MODULE_3__]);
([react_toastify__WEBPACK_IMPORTED_MODULE_2__, _allApi_apis__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




const Countdown = ({ initialTime , email , setSendOtp  })=>{
    const [time, setTime] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(initialTime);
    const [tme, setTme] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const Completionist = ()=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
            className: "text-success",
            onClick: ()=>resend(),
            children: "Resend OTP"
        });
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const intervalId = setInterval(()=>{
            setTime((time)=>{
                if (time === 1) {
                    clearInterval(intervalId);
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Completionist, {});
                }
                return time - 1;
            });
        }, 1000);
        return ()=>clearInterval(intervalId);
    }, [
        tme
    ]);
    const resend = async ()=>{
        if (isNaN(parseInt(email))) {
            const data = await (0,_allApi_apis__WEBPACK_IMPORTED_MODULE_3__/* .emailOTP */ .dQ)(email);
            if (data.success == true) {
                setSendOtp(true);
            } else {
                (0,react_toastify__WEBPACK_IMPORTED_MODULE_2__.toast)(data.message);
            }
        } else {
            const data = await (0,_allApi_apis__WEBPACK_IMPORTED_MODULE_3__/* .mobileOTP */ .yA)(email);
            if (data.success == true) {
                setSendOtp(true);
            } else {
                (0,react_toastify__WEBPACK_IMPORTED_MODULE_2__.toast)(data.message);
            }
        }
        setTme(!tme);
        setTime(120);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                className: "text-danger",
                children: [
                    time,
                    " "
                ]
            }),
            " ",
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_toastify__WEBPACK_IMPORTED_MODULE_2__.ToastContainer, {})
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Countdown);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;