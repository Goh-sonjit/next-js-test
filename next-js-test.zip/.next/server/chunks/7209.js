"use strict";
exports.id = 7209;
exports.ids = [7209];
exports.modules = {

/***/ 7209:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9816);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var cookies_next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8982);
/* harmony import */ var cookies_next__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(cookies_next__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _allApi_apis__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1889);
/* harmony import */ var next_legacy_image__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9755);
/* harmony import */ var next_legacy_image__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_legacy_image__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_allApi_apis__WEBPACK_IMPORTED_MODULE_5__]);
_allApi_apis__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







const City = ()=>{
    const [serviceIcon, setServiceIcon] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(_allApi_apis__WEBPACK_IMPORTED_MODULE_5__/* .CityNameImage */ .xe);
    const directlink = (e)=>{
        const services = [
            ...serviceIcon
        ];
        (0,cookies_next__WEBPACK_IMPORTED_MODULE_4__.setCookie)("category_name", "traditional-ooh-media"), (0,cookies_next__WEBPACK_IMPORTED_MODULE_4__.setCookie)("city_name", e.city), services.map((el)=>el.value2 = false);
        setServiceIcon(services);
    };
    const City = [
        {
            city: "Delhi",
            href: "/delhi",
            no: "2493+",
            src: "/images/web_pics/01-min.png"
        },
        {
            city: "Mumbai",
            href: "/mumbai",
            no: "1716+",
            src: "/images/web_pics/02-min.png"
        },
        {
            city: "Bengaluru",
            href: "/bengaluru",
            no: "960+",
            src: "/images/web_pics/03-min.png"
        },
        {
            city: "Chennai",
            href: "/chennai",
            no: "482+",
            src: "/images/web_pics/04-min.png"
        },
        {
            city: "Hyderabad",
            href: "/hyderabad",
            no: "897+",
            src: "/images/web_pics/05-min.png"
        },
        {
            city: "Pune",
            href: "/pune",
            no: "429+",
            src: "/images/web_pics/06-min.png"
        }
    ];
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "jsx-669c2a7fa785ad3e" + " " + "citylist m-0 mt-3 mt-md-5  py-md-4",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                className: "jsx-669c2a7fa785ad3e",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                        className: "jsx-669c2a7fa785ad3e" + " " + "text-center text-nowrap pt-2 pt-md-0",
                        children: "Explore your City Listings"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h6", {
                        className: "jsx-669c2a7fa785ad3e" + " " + " text-center",
                        children: [
                            "Explore some of the best business from around the",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {
                                className: "jsx-669c2a7fa785ad3e"
                            }),
                            "world from our partners and friends."
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "jsx-669c2a7fa785ad3e" + " " + "container mt-5 ",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "jsx-669c2a7fa785ad3e" + " " + "row",
                    children: City.slice(0, 3).map((e, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "jsx-669c2a7fa785ad3e" + " " + "col col-md-4",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                href: e.href,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    onClick: ()=>{
                                        directlink(e);
                                    },
                                    className: "jsx-669c2a7fa785ad3e" + " " + "city-img-container ",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_legacy_image__WEBPACK_IMPORTED_MODULE_6___default()), {
                                            layout: "responsive",
                                            width: 340,
                                            height: 210,
                                            src: e.src,
                                            className: "rounded ",
                                            alt: "Delhi Hording"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "jsx-669c2a7fa785ad3e" + " " + "bottom-left",
                                            children: e.city
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "jsx-669c2a7fa785ad3e" + " " + "bottom-left-media",
                                            children: [
                                                e.no,
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "jsx-669c2a7fa785ad3e" + " " + "bottom-left-media-text",
                                                    children: "medias "
                                                }),
                                                " "
                                            ]
                                        })
                                    ]
                                })
                            })
                        }, i))
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "jsx-669c2a7fa785ad3e" + " " + "container mt-4",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "jsx-669c2a7fa785ad3e" + " " + "row",
                    children: City.slice(3).map((e, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "jsx-669c2a7fa785ad3e" + " " + "col col-md-4",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                href: e.href,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    onClick: ()=>{
                                        directlink(e);
                                    },
                                    className: "jsx-669c2a7fa785ad3e" + " " + "city-img-container ",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_legacy_image__WEBPACK_IMPORTED_MODULE_6___default()), {
                                            layout: "responsive",
                                            width: 340,
                                            height: 210,
                                            src: e.src,
                                            className: "rounded ",
                                            alt: "Delhi Hording"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "jsx-669c2a7fa785ad3e" + " " + "bottom-left",
                                            children: e.city
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "jsx-669c2a7fa785ad3e" + " " + "bottom-left-media",
                                            children: [
                                                e.no,
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "jsx-669c2a7fa785ad3e" + " " + "bottom-left-media-text",
                                                    children: "medias "
                                                }),
                                                " "
                                            ]
                                        })
                                    ]
                                })
                            })
                        }, i))
                })
            }),
            react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default()), {
                id: "669c2a7fa785ad3e",
                children: ".citylist.jsx-669c2a7fa785ad3e{background-color:#ececec}h1.jsx-669c2a7fa785ad3e{font-size:2.2rem;font-weight:700;color:#373435}h6.jsx-669c2a7fa785ad3e{font-size:1.1rem;font-weight:400;color:#373435}.city-img-container.jsx-669c2a7fa785ad3e{position:relative;z-index:0;-webkit-transition:-webkit-transform.6s;-moz-transition:-moz-transform.6s;-o-transition:-o-transform.6s;transition:-webkit-transform.6s;transition:-moz-transform.6s;transition:-o-transform.6s;transition:transform.6s}.bottom-left.jsx-669c2a7fa785ad3e{position:absolute;bottom:42px;color:#fff;left:16px;font-size:1.1rem}.bottom-left-media.jsx-669c2a7fa785ad3e{position:absolute;bottom:8px;color:#fff;left:16px;font-size:1.6rem;font-weight:700;padding-right:0px}.bottom-left-media-text.jsx-669c2a7fa785ad3e{color:#fff;font-size:1.1rem;font-weight:400!important}.city-img-container.jsx-669c2a7fa785ad3e:hover{-webkit-transform:scale(1.1);-moz-transform:scale(1.1);-ms-transform:scale(1.1);-o-transform:scale(1.1);transform:scale(1.1);z-index:2}@media screen and (max-width:425px){#citygh.jsx-669c2a7fa785ad3e{padding:0px!important}h1.jsx-669c2a7fa785ad3e{font-size:1.6rem}h6.jsx-669c2a7fa785ad3e{display:none}.city-img-container.jsx-669c2a7fa785ad3e:before{width:100%!important;height:150px;margin:0px}.bottom-left.jsx-669c2a7fa785ad3e{position:absolute;bottom:0px;color:#fff;left:5px;font-size:.8rem}.bottom-left-media.jsx-669c2a7fa785ad3e{bottom:14px;left:5px;font-size:.9rem;font-weight:600;padding-right:0px}.bottom-left-media-text.jsx-669c2a7fa785ad3e{display:none}}}\r\n      "
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (City);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;