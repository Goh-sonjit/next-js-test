exports.id = 5283;
exports.ids = [5283];
exports.modules = {

/***/ 5604:
/***/ ((module) => {

// Exports
module.exports = {
	"back_map": "markers_back_map__hU_0x",
	"media_image": "markers_media_image__Baab_",
	"this_area": "markers_this_area__PunAS",
	"this_area_button": "markers_this_area_button__3GusQ",
	"streetv": "markers_streetv__8Czc_",
	"Load_more": "markers_Load_more__CBKya",
	"infoWindow": "markers_infoWindow__oP6j9",
	"mark_img": "markers_mark_img__IC3gt",
	"sitemark": "markers_sitemark__F9d7A",
	"info_window": "markers_info_window__0inxQ"
};


/***/ }),

/***/ 5283:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _styles_markers_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5604);
/* harmony import */ var _styles_markers_module_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_markers_module_scss__WEBPACK_IMPORTED_MODULE_3__);




const GoogleStreetView = next_dynamic__WEBPACK_IMPORTED_MODULE_2___default()(null, {
    loadableGenerated: {
        modules: [
            "map\\streetview.jsx -> " + "react-google-streetview"
        ]
    },
    ssr: false
});
const Streetview = ({ latitude , longitude , closeKeyword  })=>{
    const googleMapsApiKey = "AIzaSyDEKx_jLb_baUKyDgkXvzS_o-xlOkvLpeE";
    const streetViewPanoramaOptions = {
        position: {
            lat: parseFloat(latitude),
            lng: parseFloat(longitude)
        },
        pov: {
            heading: 100,
            pitch: 0
        },
        zoom: 1,
        addressControl: false,
        showRoadLabels: false,
        zoomControl: true
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "container-fluid h-100 p-0",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                className: `${(_styles_markers_module_scss__WEBPACK_IMPORTED_MODULE_3___default().back_map)}  p-2`,
                onClick: closeKeyword,
                children: "Back"
            }),
            latitude != undefined && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(GoogleStreetView, {
                apiKey: googleMapsApiKey,
                streetViewPanoramaOptions: streetViewPanoramaOptions
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Streetview);


/***/ })

};
;