"use strict";
exports.id = 4806;
exports.ids = [4806];
exports.modules = {

/***/ 7481:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


const { createPool  } = __webpack_require__(2744);
const ErrorHandle = __webpack_require__(6146);
const db_config = createPool({
    user: "root",
    host: "localhost",
    password: "",
    database: "gohoardi_goh"
});
const executeQuery = (query, arraParms, next)=>{
    return new Promise((resolve, reject)=>{
        db_config.getConnection((err, conn)=>{
            if (err) {
                // handle error
                reject(err);
            } else if (query) {
                conn.changeUser({
                    database: arraParms
                });
                conn.query(query, async (err, data)=>{
                    if (err) {
                        // handle error
                        next(new ErrorHandle(err, `The query in which error occurred ${query}`, 206));
                        return reject(err);
                    } else {
                        // handle success
                        return resolve(data);
                    }
                });
                conn.release();
            }
        });
    });
};
module.exports = {
    executeQuery
};


/***/ }),

/***/ 7296:
/***/ ((module) => {


module.exports = (catchError)=>(req, res, next)=>{
        Promise.resolve(catchError(req, res, next)).catch(next);
    };


/***/ }),

/***/ 6146:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


const fs = __webpack_require__(7147);
class ErrorHandle extends Error {
    constructor(message, apiAddrss, statusCode){
        super(message);
        this.statusCode = statusCode;
        const date = new Date();
        fs.appendFileSync("Error.txt", `\n ${message} arrived on ${date} at ${apiAddrss}`);
        Error.captureStackTrace(this, this.constructor);
    }
}
module.exports = ErrorHandle;


/***/ })

};
;