exports.id = 524;
exports.ids = [524];
exports.modules = {

/***/ 9447:
/***/ ((module) => {

// Exports
module.exports = {
	"userDetail2_mbil": "navbarHome_userDetail2_mbil__RycQH",
	"login_profifgtle": "navbarHome_login_profifgtle__CpRvJ",
	"userDetail2_dekstopp": "navbarHome_userDetail2_dekstopp__Hs252",
	"userDetail2_dekstop": "navbarHome_userDetail2_dekstop__T8_qe",
	"login-profile": "navbarHome_login-profile__cf0mw",
	"drop-item": "navbarHome_drop-item__zQ6l2",
	"fixd_nabar": "navbarHome_fixd_nabar__yoPLk",
	"brand_logo": "navbarHome_brand_logo__0WCZm",
	"mapLink": "navbarHome_mapLink__1Purj",
	"nav_text_btn": "navbarHome_nav_text_btn__JHqQl",
	"login_profile": "navbarHome_login_profile__RNh7t",
	"drop_togel": "navbarHome_drop_togel__x9pIS",
	"login_icon": "navbarHome_login_icon__tKIKs",
	"drop_item": "navbarHome_drop_item__EMjE2",
	"font_map_btn": "navbarHome_font_map_btn__EuOEE",
	"font_map_logo": "navbarHome_font_map_logo__8Yp3a",
	"dropdown_basic_user": "navbarHome_dropdown_basic_user__5O_2D",
	"anchor": "navbarHome_anchor__MWS_M",
	"login_icon_cart": "navbarHome_login_icon_cart__kip31",
	"cart": "navbarHome_cart__bRlKy"
};


/***/ }),

/***/ 3379:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const instance = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
    baseURL: "http://localhost:3000/api/"
});
instance.defaults.headers.common["Content-Type"] = "multipart/form-data";
instance.defaults.withCredentials = true;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (instance);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 524:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap_Nav__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2540);
/* harmony import */ var react_bootstrap_Nav__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Nav__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_bootstrap_Navbar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4934);
/* harmony import */ var react_bootstrap_Navbar__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Navbar__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _allApi_apicontext__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3484);
/* harmony import */ var _styles_navbarHome_module_scss__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9447);
/* harmony import */ var _styles_navbarHome_module_scss__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_styles_navbarHome_module_scss__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var cookies_next__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8982);
/* harmony import */ var cookies_next__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(cookies_next__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _maintenance__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9293);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _allApi_axios__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3379);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_allApi_apicontext__WEBPACK_IMPORTED_MODULE_5__, _allApi_axios__WEBPACK_IMPORTED_MODULE_10__]);
([_allApi_apicontext__WEBPACK_IMPORTED_MODULE_5__, _allApi_axios__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












const NavbarH = ()=>{
    const route = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const { handleClose , handleShow  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_allApi_apicontext__WEBPACK_IMPORTED_MODULE_5__/* .AccountContext */ .w0);
    const getMap = async ()=>{
        const { data  } = await _allApi_axios__WEBPACK_IMPORTED_MODULE_10__/* ["default"].get */ .Z.get(`forgetPass`);
        if (data.message == "InValid Token") {
            handleShow();
        } else {
            (0,cookies_next__WEBPACK_IMPORTED_MODULE_7__.removeCookies)("meta_title");
            (0,cookies_next__WEBPACK_IMPORTED_MODULE_7__.removeCookies)("state_name");
            route.push("/map");
        }
    };
    const Userdetail = next_dynamic__WEBPACK_IMPORTED_MODULE_6___default()(null, {
        loadableGenerated: {
            modules: [
                "..\\components\\navbar\\navbar.jsx -> " + "./userdetail"
            ]
        },
        ssr: false
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_maintenance__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Navbar__WEBPACK_IMPORTED_MODULE_3___default()), {
                expand: `lg px-md-0 pb-0 ${(_styles_navbarHome_module_scss__WEBPACK_IMPORTED_MODULE_11___default().fixd_nabar)} sdsd mt-3`,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "navbar container-xxl  container-xl container-lg container-md",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Navbar__WEBPACK_IMPORTED_MODULE_3___default().Brand), {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_9___default()), {
                                width: 223,
                                height: 42,
                                src: "/images/web_pics/logo.png",
                                className: (_styles_navbarHome_module_scss__WEBPACK_IMPORTED_MODULE_11___default().rand_logo),
                                alt: "gohoardings"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Navbar__WEBPACK_IMPORTED_MODULE_3___default().Toggle), {
                            "aria-controls": "basic-navbar-nav",
                            className: ""
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Navbar__WEBPACK_IMPORTED_MODULE_3___default().Collapse), {
                            id: (_styles_navbarHome_module_scss__WEBPACK_IMPORTED_MODULE_11___default().basic_navbar_nav),
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Nav__WEBPACK_IMPORTED_MODULE_2___default()), {
                                className: " ms-auto ",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Nav__WEBPACK_IMPORTED_MODULE_2___default().Link), {
                                        className: `me-2  me-md-0   ${(_styles_navbarHome_module_scss__WEBPACK_IMPORTED_MODULE_11___default().nav_text_btn)}  text-center`,
                                        href: "https://odoads.com/",
                                        target: "_blank",
                                        children: "Odoads"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Nav__WEBPACK_IMPORTED_MODULE_2___default().Link), {
                                        className: `me-2  me-md-0   ${(_styles_navbarHome_module_scss__WEBPACK_IMPORTED_MODULE_11___default().nav_text_btn)}  text-center`,
                                        href: "https://blog.gohoardings.com/",
                                        target: "_blank",
                                        children: "Blog"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Nav__WEBPACK_IMPORTED_MODULE_2___default().Link), {
                                        className: `me-3  me-md-0   ${(_styles_navbarHome_module_scss__WEBPACK_IMPORTED_MODULE_11___default().nav_text_btn)}  text-center`,
                                        onClick: ()=>route.push("/contact-us"),
                                        children: "Contact"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Nav__WEBPACK_IMPORTED_MODULE_2___default().Link), {
                                        className: `ms-2  me-md-0   ${(_styles_navbarHome_module_scss__WEBPACK_IMPORTED_MODULE_11___default().nav_text_btn)}  text-center`,
                                        onClick: getMap,
                                        children: "Map View"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: `  me-md-0   ${(_styles_navbarHome_module_scss__WEBPACK_IMPORTED_MODULE_11___default().fixed_login)}  text-center `,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Userdetail, {})
                                    })
                                ]
                            })
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NavbarH);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;