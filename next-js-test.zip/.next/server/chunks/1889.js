"use strict";
exports.id = 1889;
exports.ids = [1889];
exports.modules = {

/***/ 1889:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$0": () => (/* binding */ cartitems),
/* harmony export */   "$F": () => (/* binding */ getCityDataApi),
/* harmony export */   "$V": () => (/* binding */ userDetails),
/* harmony export */   "Ax": () => (/* binding */ updateProfilePic),
/* harmony export */   "CL": () => (/* binding */ enquiryApi),
/* harmony export */   "DI": () => (/* binding */ singlemnedia),
/* harmony export */   "Ef": () => (/* binding */ subCategoryFilterApi),
/* harmony export */   "G4": () => (/* binding */ getAllCity),
/* harmony export */   "Gm": () => (/* binding */ loginOTP),
/* harmony export */   "I4": () => (/* binding */ clientId),
/* harmony export */   "Lo": () => (/* binding */ companydata),
/* harmony export */   "OA": () => (/* binding */ sendOTP),
/* harmony export */   "Qt": () => (/* binding */ allcompanydata),
/* harmony export */   "XF": () => (/* binding */ mediaApi),
/* harmony export */   "_U": () => (/* binding */ latLongApi),
/* harmony export */   "a$": () => (/* binding */ registerUser),
/* harmony export */   "bz": () => (/* binding */ profileDetails),
/* harmony export */   "ck": () => (/* binding */ updateProfile),
/* harmony export */   "cl": () => (/* binding */ removeItem),
/* harmony export */   "dO": () => (/* binding */ statemediaApi),
/* harmony export */   "dQ": () => (/* binding */ emailOTP),
/* harmony export */   "dt": () => (/* binding */ changePasswordApi),
/* harmony export */   "gW": () => (/* binding */ iconFiltersData),
/* harmony export */   "ij": () => (/* binding */ LocationFilterApi),
/* harmony export */   "jX": () => (/* binding */ addItem),
/* harmony export */   "mX": () => (/* binding */ emailformate),
/* harmony export */   "pH": () => (/* binding */ loginUser),
/* harmony export */   "sk": () => (/* binding */ OtpRegister),
/* harmony export */   "u8": () => (/* binding */ mediaDataApi),
/* harmony export */   "u9": () => (/* binding */ googleLogin),
/* harmony export */   "v0": () => (/* binding */ brandLogoApi),
/* harmony export */   "vF": () => (/* binding */ markersPosition),
/* harmony export */   "w4": () => (/* binding */ illuminationFilterApi),
/* harmony export */   "xe": () => (/* binding */ CityNameImage),
/* harmony export */   "yA": () => (/* binding */ mobileOTP)
/* harmony export */ });
/* unused harmony exports logoutUser, deleteCartItem, reviewApi, getreviewApi, mediawithlocation, mediaFilters, priceSubIllu, nearProduct */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3379);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_gi__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8866);
/* harmony import */ var react_icons_gi__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_gi__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_icons_tb__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4152);
/* harmony import */ var react_icons_tb__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_tb__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_icons_tfi__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1740);
/* harmony import */ var react_icons_tfi__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_tfi__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_icons_im__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(924);
/* harmony import */ var react_icons_im__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_icons_im__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_axios__WEBPACK_IMPORTED_MODULE_2__]);
_axios__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];








const emailformate = /^\w+([-,.]?\w+)*@\w+(.-]?\w+)*(\.\w{2,3})+$/;
const clientId = "85378901999-efhrgq7ltamh5730qq1776fatpm0mhd0.apps.googleusercontent.com";
const CityNameImage = [
    {
        id: 1,
        label: "InFlight Branding",
        value: "inflight-media",
        value2: false,
        srcImgCtSlc: "/images/web_pics/final/flight.png",
        srcImgCt: "/images/web_pics/final/Grey/flight.png",
        srcImg: "/images/web_pics/InflightBann.png",
        srcImgM: "/images/web_pics/InflightBanner.png",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_gi__WEBPACK_IMPORTED_MODULE_4__.GiCommercialAirplane, {}),
        link: "inflight-media/",
        city: "delhi"
    },
    {
        id: 2,
        label: "Traditional OOH Media ",
        value2: false,
        value: "traditional-ooh-media",
        srcImgCtSlc: "/images/web_pics/final/Tradition_OOH_01.png",
        srcImgCt: "/images/web_pics/final/Grey/Tradition_OOH.png",
        srcImg: "/images/web_pics/traditional-ooh-media-advertising-near-me.jpg",
        srcImgM: "/images/web_pics/traditional-ooh-media-advertising.jpg",
        Link: `/traditional-ooh-media/delhi`,
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_gi__WEBPACK_IMPORTED_MODULE_4__.GiAwareness, {}),
        city: "delhi"
    },
    {
        id: 3,
        label: "Digital Media",
        value: "digital-media",
        value2: false,
        srcImgCtSlc: "/images/web_pics/final/Digital_OOH_Media.png",
        srcImgCt: "/images/web_pics/final/Grey/Digital_OOH_Media.png",
        srcImg: "/images/web_pics/digital-media-hoardings-near-me.jpg",
        srcImgM: "/images/web_pics/digital-media-hoardings-digital-hoardings.jpg",
        Link: `/digital-media/delhi`,
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_gi__WEBPACK_IMPORTED_MODULE_4__.GiLaptop, {}),
        city: "mumbai"
    },
    {
        id: 4,
        label: "Mall Media",
        value: "mall-media",
        value2: false,
        srcImgCtSlc: "/images/web_pics/final/Mall_Media_01.png",
        srcImgCt: "/images/web_pics/final/Grey/Mall_Media.png",
        srcImg: "/images/web_pics/mall-media-advertising-company.jpg",
        srcImgM: "/images/web_pics/mall-media-advertising-near-me.jpg",
        Link: `/mall-media/delhi`,
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_tb__WEBPACK_IMPORTED_MODULE_5__.TbBuildingCommunity, {}),
        city: "bengaluru"
    },
    {
        id: 5,
        label: "Office Branding",
        value: "office-media",
        value2: false,
        srcImgCtSlc: "/images/web_pics/final/Office_Branding.png",
        srcImgCt: "/images/web_pics/final/Grey/Office_Branding.png",
        srcImg: "/images/web_pics/office-branding-advertising-company.jpg",
        srcImgM: "/images/web_pics/office-branding-media-near-me.jpg",
        Link: `/office-branding/delhi`,
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_im__WEBPACK_IMPORTED_MODULE_7__.ImOffice, {}),
        city: "pune"
    },
    {
        id: 6,
        label: "Transit Media",
        value: "transit-media",
        value2: false,
        srcImgCtSlc: "/images/web_pics/final/Transit_Media.png",
        srcImgCt: "/images/web_pics/final/Grey/Transit_Media.png",
        srcImg: "/images/web_pics/transit-media-advertising-in-delhi.jpg",
        srcImgM: "/images/web_pics/transit-media-advertising-near-me.jpg",
        Link: `/transit-media/delhi`,
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_tfi__WEBPACK_IMPORTED_MODULE_6__.TfiLayoutMediaCenterAlt, {}),
        city: "chennai"
    },
    {
        id: 7,
        label: "Airport Branding",
        value: "airport-media",
        value2: false,
        srcImgCtSlc: "/images/web_pics/final/Airport_Branding.png",
        srcImgCt: "/images/web_pics/final/Grey/Airport_Branding_01.png",
        srcImg: "/images/web_pics/airport-media-hoardings-near-me.jpg",
        srcImgM: "/images/web_pics/airport-media-digital-hoardings.jpg",
        Link: `/airport-media/delhi`,
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_gi__WEBPACK_IMPORTED_MODULE_4__.GiAirplaneDeparture, {}),
        city: "hyderabad"
    }
];
const getAllCity = async (value)=>{
    const { data  } = await _axios__WEBPACK_IMPORTED_MODULE_2__/* ["default"].patch */ .Z.patch("medias", {
        value
    });
    return data;
};
const logoutUser = async ()=>{
    const { data  } = await instance.get("sociallogin");
    return data;
};
const googleLogin = async (res)=>{
    const { data  } = await _axios__WEBPACK_IMPORTED_MODULE_2__/* ["default"].post */ .Z.post("sociallogin", res);
    return data;
};
const loginUser = async (email, password)=>{
    const { data  } = await _axios__WEBPACK_IMPORTED_MODULE_2__/* ["default"].patch */ .Z.patch("loginApis", {
        email,
        password
    });
    return data;
};
const registerUser = async (email, phone)=>{
    const { data  } = await _axios__WEBPACK_IMPORTED_MODULE_2__/* ["default"].post */ .Z.post("loginApis", {
        email,
        phone
    });
    return data;
};
const OtpRegister = async (name, email, phone, password, otp)=>{
    const { data  } = await _axios__WEBPACK_IMPORTED_MODULE_2__/* ["default"].put */ .Z.put("loginApis", {
        name,
        email,
        phone,
        password,
        otp
    });
    return data;
};
const deleteCartItem = async (obj)=>{
    const data = await instance.post("cart/deleteFromCart", {
        code: obj
    });
    return data;
};
const profileDetails = async ()=>{
    const { data  } = await _axios__WEBPACK_IMPORTED_MODULE_2__/* ["default"].get */ .Z.get("linkedin");
    return data;
};
const updateProfile = async (firstname, phonenumber, newPassword, confirmPassword)=>{
    const { data  } = await _axios__WEBPACK_IMPORTED_MODULE_2__/* ["default"].post */ .Z.post("profile", {
        firstname,
        phonenumber,
        newPassword,
        confirmPassword
    });
    return data;
};
const updateProfilePic = async (img)=>{
    const formData = new FormData();
    formData.append("file", img);
    const { data  } = await _axios__WEBPACK_IMPORTED_MODULE_2__/* ["default"].post */ .Z.post("upload", formData);
    return data;
};
const emailOTP = async (email)=>{
    const { data  } = await _axios__WEBPACK_IMPORTED_MODULE_2__/* ["default"].put */ .Z.put(`${email}`);
    return data;
};
const mobileOTP = async (email)=>{
    const { data  } = await _axios__WEBPACK_IMPORTED_MODULE_2__/* ["default"].patch */ .Z.patch(`${email}`);
    return data;
};
const sendOTP = async (otp)=>{
    const { data  } = await _axios__WEBPACK_IMPORTED_MODULE_2__/* ["default"].patch */ .Z.patch(`forgetPass`, {
        otp
    });
    return data;
};
const changePasswordApi = async (password, confirmpasswords, expire)=>{
    const { data  } = await _axios__WEBPACK_IMPORTED_MODULE_2__/* ["default"].put */ .Z.put("forgetPass", {
        password,
        confirmpasswords,
        expire
    });
    return data;
};
const enquiryApi = async (name, email, phone, message)=>{
    const { data  } = await _axios__WEBPACK_IMPORTED_MODULE_2__/* ["default"].post */ .Z.post("enquiries", {
        name,
        email,
        phone,
        message
    });
    return data;
};
const reviewApi = async (feedback, rating, ip)=>{
    const { data  } = await instance.post("enquiry/review", {
        feedback,
        rating,
        ip
    });
    return data;
};
const getreviewApi = async ()=>{
    const { data  } = await instance.get("enquiries");
    return data;
};
const mediaDataApi = async (category_name, city_name)=>{
    const { data  } = await _axios__WEBPACK_IMPORTED_MODULE_2__/* ["default"].post */ .Z.post("medias", {
        category_name,
        city_name
    });
    return data;
};
const mediawithlocation = async (category_name, city_name, loca)=>{
    const { data  } = await instance.put(`team`, {
        category_name,
        city_name,
        loca
    });
    return data;
};
const mediaFilters = async (category_name, illunation, categorys, city_name)=>{
    const { data  } = await instance.put(`filters`, {
        category_name,
        illunation,
        categorys,
        city_name
    });
    return data;
};
const loginOTP = async (otp)=>{
    const { data  } = await _axios__WEBPACK_IMPORTED_MODULE_2__/* ["default"].put */ .Z.put("linkedin", {
        otp
    });
    return data;
};
const companydata = async (inputs)=>{
    const { data  } = await _axios__WEBPACK_IMPORTED_MODULE_2__/* ["default"].patch */ .Z.patch("profile", {
        company: inputs.company,
        city: inputs.city,
        phone: inputs.phone,
        address: inputs.address,
        website: inputs.website,
        state: inputs.state,
        zip_code: inputs.zip_code,
        pan: inputs.pan,
        gstin: inputs.gstin
    });
    return data;
};
const allcompanydata = async ()=>{
    const { data  } = await _axios__WEBPACK_IMPORTED_MODULE_2__/* ["default"].get */ .Z.get("profile");
    return data;
};
const singlemnedia = async (meta_title, category_name)=>{
    const { data  } = await _axios__WEBPACK_IMPORTED_MODULE_2__/* ["default"].post */ .Z.post("seedetails", {
        meta_title,
        category_name
    });
    return data;
};
const userDetails = async ()=>{
    const { data  } = await _axios__WEBPACK_IMPORTED_MODULE_2__/* ["default"].get */ .Z.get("loginApis", {
        withCredentials: true
    });
    return data;
};
const priceSubIllu = async (category_name, illumination, table, city, locations)=>{
    const { data  } = await instance.post(`filters`, {
        category_name,
        illumination,
        table,
        city,
        locations
    });
    return data;
};
const iconFiltersData = async (datas, table, city, minLatitude, maxLatitude, uniqueValues)=>{
    const { data  } = await _axios__WEBPACK_IMPORTED_MODULE_2__/* ["default"].patch */ .Z.patch(`filters`, {
        datas,
        table,
        city,
        minLatitude,
        maxLatitude,
        uniqueValues
    });
    return data;
};
const cartitems = async ()=>{
    const { data  } = await _axios__WEBPACK_IMPORTED_MODULE_2__/* ["default"].get */ .Z.get(`cart`);
    return data;
};
const addItem = async (mediaid, mediatype)=>{
    const { data  } = await _axios__WEBPACK_IMPORTED_MODULE_2__/* ["default"].put */ .Z.put(`cart`, {
        mediaid,
        mediatype
    });
    return data;
};
const removeItem = async (code)=>{
    const { data  } = await _axios__WEBPACK_IMPORTED_MODULE_2__/* ["default"].patch */ .Z.patch(`cart`, {
        code
    });
    return data;
};
const nearProduct = async (code, category_name)=>{
    const { data  } = await instance.patch("enquiries", {
        code,
        category_name
    });
    return data;
};
const markersPosition = async (NorthLat, SouthLat, NorthLong, SouthLong)=>{
    const { data  } = await _axios__WEBPACK_IMPORTED_MODULE_2__/* ["default"].post */ .Z.post("team", {
        NorthLat,
        SouthLat,
        NorthLong,
        SouthLong
    });
    return data;
};
const latLongApi = async (lat, long)=>{
    const { data  } = await _axios__WEBPACK_IMPORTED_MODULE_2__/* ["default"].patch */ .Z.patch("linkedin", {
        lat,
        long
    });
    return data;
};
const mediaApi = async (category_name, noofPage)=>{
    const { data  } = await _axios__WEBPACK_IMPORTED_MODULE_2__/* ["default"].patch */ .Z.patch("excel", {
        category_name,
        noofPage
    });
    return data;
};
const statemediaApi = async (state_name, pages)=>{
    const { data  } = await _axios__WEBPACK_IMPORTED_MODULE_2__/* ["default"].patch */ .Z.patch("ppt", {
        state_name,
        pages
    });
    return data;
};
const subCategoryFilterApi = async (category_name, subcategory, city)=>{
    const { data  } = await _axios__WEBPACK_IMPORTED_MODULE_2__/* ["default"].patch */ .Z.patch("newFilters", {
        category_name,
        subcategory,
        city
    });
    return data;
};
const LocationFilterApi = async (category_name, location, city)=>{
    const { data  } = await _axios__WEBPACK_IMPORTED_MODULE_2__/* ["default"].put */ .Z.put("newFilters", {
        category_name,
        location,
        city
    });
    return data;
};
const illuminationFilterApi = async (category_name, illumination, city)=>{
    const { data  } = await _axios__WEBPACK_IMPORTED_MODULE_2__/* ["default"].post */ .Z.post("newFilters", {
        category_name,
        illumination,
        city
    });
    return data;
};
const getCityDataApi = async (city)=>{
    const { data  } = await _axios__WEBPACK_IMPORTED_MODULE_2__/* ["default"].put */ .Z.put("excel", {
        city
    });
    return data;
};
const brandLogoApi = async ()=>{
    const { data  } = await _axios__WEBPACK_IMPORTED_MODULE_2__/* ["default"].get */ .Z.get("excel");
    return data;
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3379:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const instance = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
    baseURL: "http://localhost:3000/api/"
});
instance.defaults.headers.common["Content-Type"] = "multipart/form-data";
instance.defaults.withCredentials = true;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (instance);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;