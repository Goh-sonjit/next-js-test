"use strict";
exports.id = 599;
exports.ids = [599];
exports.modules = {

/***/ 599:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _styles_filter_module_scss__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(341);
/* harmony import */ var _styles_filter_module_scss__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_styles_filter_module_scss__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _searchGoogle__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6177);
/* harmony import */ var _allApi_apis__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1889);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4041);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_md__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6652);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_bi__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_icons_si__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(764);
/* harmony import */ var react_icons_si__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_icons_si__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_icons_ri__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8098);
/* harmony import */ var react_icons_ri__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_icons_ri__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_icons_tb__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4152);
/* harmony import */ var react_icons_tb__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_icons_tb__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react_icons_cg__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7865);
/* harmony import */ var react_icons_cg__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_icons_cg__WEBPACK_IMPORTED_MODULE_10__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_searchGoogle__WEBPACK_IMPORTED_MODULE_3__, _allApi_apis__WEBPACK_IMPORTED_MODULE_4__]);
([_searchGoogle__WEBPACK_IMPORTED_MODULE_3__, _allApi_apis__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












const Filters = ({ search , setSearch , setNsearch  })=>{
    const [mediaData, setMediadata] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [locationData, setlocationData] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [categoryData, setcategoryData] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [table, setCategory] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [city, setCity] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [filtervalue, setFilterValue] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [categoryvalue, setcategoryValue] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [intrestedvalue, setintrestedValue] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const apiforFillters = async ()=>{
        if (search.length > 0) {
            const category_name = search[0].category_name;
            setCategory(category_name);
            const city_name = search[0].city_name;
            setCity(city_name);
            const data = await (0,_allApi_apis__WEBPACK_IMPORTED_MODULE_4__/* .mediaDataApi */ .u8)(category_name, city_name);
            setMediadata(data);
            setlocationData(data);
            setcategoryData(data);
        }
    };
    let Icons = [
        {
            name: "education",
            value: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_5__.MdSchool, {
                className: "icon-clr",
                id: (_styles_filter_module_scss__WEBPACK_IMPORTED_MODULE_11___default().select_location_icon)
            }),
            id: "cb1"
        },
        {
            name: "bar",
            value: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bi__WEBPACK_IMPORTED_MODULE_6__.BiDrink, {
                className: "icon-clr",
                id: (_styles_filter_module_scss__WEBPACK_IMPORTED_MODULE_11___default().select_location_icon)
            }),
            id: "cb2"
        },
        {
            name: "hotel",
            value: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_si__WEBPACK_IMPORTED_MODULE_7__.SiHotelsdotcom, {
                className: "icon-clr",
                id: (_styles_filter_module_scss__WEBPACK_IMPORTED_MODULE_11___default().select_location_icon)
            }),
            id: "cb3"
        },
        {
            name: "restaurant",
            value: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_5__.MdOutlineRestaurantMenu, {
                className: "icon-clr",
                id: (_styles_filter_module_scss__WEBPACK_IMPORTED_MODULE_11___default().select_location_icon)
            }),
            id: "cb4"
        },
        {
            name: "hospital",
            value: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ri__WEBPACK_IMPORTED_MODULE_8__.RiHospitalFill, {
                className: "icon-clr",
                id: (_styles_filter_module_scss__WEBPACK_IMPORTED_MODULE_11___default().select_location_icon)
            }),
            id: "cb5"
        },
        {
            name: "spa",
            value: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_tb__WEBPACK_IMPORTED_MODULE_9__.TbMassage, {
                className: "icon-clr",
                id: (_styles_filter_module_scss__WEBPACK_IMPORTED_MODULE_11___default().select_location_icon)
            }),
            id: "cb6"
        },
        {
            name: "cinema",
            value: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ri__WEBPACK_IMPORTED_MODULE_8__.RiMovie2Fill, {
                className: "icon-clr",
                id: (_styles_filter_module_scss__WEBPACK_IMPORTED_MODULE_11___default().select_location_icon)
            }),
            id: "cb7"
        },
        {
            name: "gym",
            value: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_cg__WEBPACK_IMPORTED_MODULE_10__.CgGym, {
                className: "icon-clr",
                id: (_styles_filter_module_scss__WEBPACK_IMPORTED_MODULE_11___default().select_location_icon)
            }),
            id: "cb8"
        }
    ];
    let locations;
    const allLocations = locationData.map((locate)=>locate.location);
    locations = [
        ...new Set(allLocations)
    ];
    let category;
    const allSubcategory = categoryData.map((category)=>category.subcategory);
    category = [
        ...new Set(allSubcategory)
    ];
    let ILLUMINATION;
    const allIllumations = mediaData.map((illumation)=>illumation.illumination);
    ILLUMINATION = [
        ...new Set(allIllumations)
    ];
    async function categoryFilter(cate) {
        setcategoryValue(cate);
        const data = await (0,_allApi_apis__WEBPACK_IMPORTED_MODULE_4__/* .subCategoryFilterApi */ .Ef)(table, cate, city);
        setSearch(data);
    }
    async function mediaTypeFilter(cate) {
        setFilterValue(cate);
        const data = await (0,_allApi_apis__WEBPACK_IMPORTED_MODULE_4__/* .illuminationFilterApi */ .w4)(table, cate, city);
        setSearch(data);
    }
    let uniqueValues = new Set();
    if (search) {
        search.forEach((el)=>{
            uniqueValues.add(el.latitude);
        });
    }
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        apiforFillters();
    }, [
        search
    ]);
    const submitfilters = async (datas)=>{
        setintrestedValue(datas.name);
        const value = [
            ...search
        ];
        const table = value[0].category_name;
        const city = value[0].city_name;
        const latitudes = search.map((item)=>item.latitude);
        const minLatitude = Math.min(...latitudes);
        const maxLatitude = Math.max(...latitudes);
        let array = [
            ...uniqueValues
        ];
        let arrayJJson = JSON.stringify(array);
        let newString = arrayJJson.replace(/\[|\]/g, "");
        const data = await (0,_allApi_apis__WEBPACK_IMPORTED_MODULE_4__/* .iconFiltersData */ .gW)(datas.name, table, city, minLatitude, maxLatitude, newString);
        setNsearch(data);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.DropdownButton, {
                title: filtervalue ? filtervalue : "Illumination",
                id: (_styles_filter_module_scss__WEBPACK_IMPORTED_MODULE_11___default().select_media_box),
                // onSelect={(e) => setUserType(e)}
                drop: "down-centered",
                children: ILLUMINATION.map((el, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Dropdown.Item, {
                        className: "p-2 mt-0 ",
                        onClick: (e)=>mediaTypeFilter(el),
                        children: el
                    }, i))
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.DropdownButton, {
                title: categoryvalue ? categoryvalue : "Category type",
                id: (_styles_filter_module_scss__WEBPACK_IMPORTED_MODULE_11___default().select_media_box),
                drop: "down-centered",
                children: category.map((cate, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Dropdown.Item, {
                        className: "p-2 mt-0 ",
                        onClick: (e)=>categoryFilter(cate),
                        children: cate.substring(0, 13)
                    }, i))
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.DropdownButton, {
                title: intrestedvalue ? intrestedvalue.toUpperCase() : "Intrested things",
                id: (_styles_filter_module_scss__WEBPACK_IMPORTED_MODULE_11___default().select_media_box),
                drop: "down-centered",
                children: Icons.map((el, i)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Dropdown.Item, {
                        className: "p-2 mt-0 ",
                        onClick: (e)=>submitfilters(el),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "m-2",
                                children: [
                                    " ",
                                    el.value,
                                    " "
                                ]
                            }),
                            el.name.toUpperCase()
                        ]
                    }, i))
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_searchGoogle__WEBPACK_IMPORTED_MODULE_3__["default"], {
                setSearch: setSearch,
                search: search
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Filters);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;