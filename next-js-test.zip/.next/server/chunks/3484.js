"use strict";
exports.id = 3484;
exports.ids = [3484];
exports.modules = {

/***/ 3484:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "w0": () => (/* binding */ AccountContext)
/* harmony export */ });
/* unused harmony export AccountProvider */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3379);
/* harmony import */ var cookies_next__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8982);
/* harmony import */ var cookies_next__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(cookies_next__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_axios__WEBPACK_IMPORTED_MODULE_2__]);
_axios__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const AccountContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(null);
const AccountProvider = ({ children  })=>{
    const [show, setShow] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    var [initalState, setInitalState] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const item = async ()=>{
        const value = (0,cookies_next__WEBPACK_IMPORTED_MODULE_3__.getCookie)("permissions");
        if (value) {
            const { data  } = await _axios__WEBPACK_IMPORTED_MODULE_2__/* ["default"].get */ .Z.get(`forgetPass`);
            if (data.message == "InValid Token") {
                setInitalState(0);
            } else {
                setInitalState(data[0].item);
            }
        }
    };
    const reducer = (state, action)=>{
        if (action.type === "INCR") {
            state = state + 1;
        }
        if (state > 0 && action.type === "DECR") {
            state = state - 1;
        }
        return state;
    };
    const [state, addRemove] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useReducer)(reducer, item());
    const handleClose = ()=>setShow(false);
    const handleShow = ()=>setShow(true);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AccountContext.Provider, {
        value: {
            initalState,
            state,
            addRemove,
            show,
            handleClose,
            handleShow
        },
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AccountProvider);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;