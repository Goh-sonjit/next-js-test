"use strict";
exports.id = 6405;
exports.ids = [6405];
exports.modules = {

/***/ 4240:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9816);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



const Branding = (props)=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                className: "jsx-40258aa4193eeaf4" + " " + "inn-page-bg mt-5",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "jsx-40258aa4193eeaf4" + " " + "container",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "jsx-40258aa4193eeaf4" + " " + "row",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "jsx-40258aa4193eeaf4" + " " + "inn-pag-ban",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                className: "jsx-40258aa4193eeaf4",
                                children: props.title
                            })
                        })
                    })
                })
            }),
            react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default()), {
                id: "40258aa4193eeaf4",
                children: '.inn-page-bg.jsx-40258aa4193eeaf4:before{content:"";position:absolute;background:-webkit-linear-gradient(bottom,rgba(32,52,76,.64)14%,#393939 66%);background:-moz-linear-gradient(bottom,rgba(32,52,76,.64)14%,#393939 66%);background:-o-linear-gradient(bottom,rgba(32,52,76,.64)14%,#393939 66%);background:linear-gradient(to top,rgba(32,52,76,.64)14%,#393939 66%);top:0;bottom:0;left:0;width:100%}.inn-page-bg.jsx-40258aa4193eeaf4{background:url("../images/web_pics/branding.jpg")no-repeat;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;position:relative;margin-top:0px;background-color:none}.logo.jsx-40258aa4193eeaf4{position:absolute;top:35px;left:50px;height:38px}.inn-pag-ban.jsx-40258aa4193eeaf4 h2.jsx-40258aa4193eeaf4{font-size:50px;font-weight:700;margin-top:0;margin-bottom:0;position:relative;overflow:hidden;margin:0 auto;padding:75px 35px;color:#fff;text-align:center}@media screen and (max-width:425px){.logo.jsx-40258aa4193eeaf4{position:absolute;top:15px;left:20px;height:14px}.inn-pag-ban.jsx-40258aa4193eeaf4 h2.jsx-40258aa4193eeaf4{font-size:18px;padding:55px 17px}}@media screen and (max-width:768px){.logo.jsx-40258aa4193eeaf4{position:absolute;top:25px;left:30px;height:25px}.inn-pag-ban.jsx-40258aa4193eeaf4 h2.jsx-40258aa4193eeaf4{font-size:40px;padding:55px 17px;font-weight:600}}'
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Branding);


/***/ })

};
;