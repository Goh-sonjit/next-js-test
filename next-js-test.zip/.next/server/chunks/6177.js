exports.id = 6177;
exports.ids = [6177];
exports.modules = {

/***/ 341:
/***/ ((module) => {

// Exports
module.exports = {
	"select_media_box": "filter_select_media_box__pHceF",
	"select_location_icon": "filter_select_location_icon__SA7lO",
	"checkIndex": "filter_checkIndex__YiI6F"
};


/***/ }),

/***/ 6177:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _allApi_apis__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1889);
/* harmony import */ var react_places_autocomplete__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1790);
/* harmony import */ var react_places_autocomplete__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_places_autocomplete__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _styles_filter_module_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(341);
/* harmony import */ var _styles_filter_module_scss__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_styles_filter_module_scss__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4041);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_md__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_allApi_apis__WEBPACK_IMPORTED_MODULE_2__]);
_allApi_apis__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







function SearchGoogle({ setSearch , search  }) {
    const [address, setAddress] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const handleSelect = async (value)=>{
        const results = await (0,react_places_autocomplete__WEBPACK_IMPORTED_MODULE_3__.geocodeByAddress)(value);
        const latLng = await (0,react_places_autocomplete__WEBPACK_IMPORTED_MODULE_3__.getLatLng)(results[0]);
        const latitude = latLng.lat;
        const longitude = latLng.lng;
        if (latitude && longitude) {
            const data = await (0,_allApi_apis__WEBPACK_IMPORTED_MODULE_2__/* .latLongApi */ ._U)(latitude, longitude);
            setSearch();
            setSearch(data);
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_places_autocomplete__WEBPACK_IMPORTED_MODULE_3___default()), {
            value: address,
            onChange: setAddress,
            onSelect: handleSelect,
            children: ({ getInputProps , suggestions , getSuggestionItemProps , loading  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            className: "w-100 ",
                            id: (_styles_filter_module_scss__WEBPACK_IMPORTED_MODULE_5___default().select_media_box),
                            ...getInputProps({
                                placeholder: "Type location"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: address ? "dropdown-menu show ms-2 text-dark" : "dropdown-menu",
                                children: suggestions.map((suggestion, i)=>/*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createElement)("div", {
                                        ...getSuggestionItemProps(suggestion),
                                        key: i,
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_4__.MdOutlineLocationOn, {
                                                className: "icon-clr ",
                                                id: (_styles_filter_module_scss__WEBPACK_IMPORTED_MODULE_5___default().select_location_icon)
                                            }),
                                            "   ",
                                            suggestion.description
                                        ]
                                    }))
                            })
                        })
                    ]
                })
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SearchGoogle);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;