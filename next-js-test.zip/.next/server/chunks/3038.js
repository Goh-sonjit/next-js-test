exports.id = 3038;
exports.ids = [3038];
exports.modules = {

/***/ 3038:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

var __webpack_unused_export__;
const { executeQuery  } = __webpack_require__(7481);
const catchError = __webpack_require__(7296);
exports.SV = catchError(async (req, res, next)=>{
    const sql = "SELECT staff.*, role.name FROM tblstaff as staff  RIGHT JOIN tblroles as role ON staff.role = role.roleid WHERE staff.active=1";
    const data = await executeQuery(sql, "gohoardi_crmapp", next);
    if (!data) {
        return res.status(206).json({
            success: false,
            message: "Data Not Found"
        });
    } else {
        return res.status(200).json(data);
    }
});
__webpack_unused_export__ = catchError(async (req, res, next)=>{
    const data = await executeQuery("SELECT * FROM goh_quick_links", "gohoardi_goh", next);
    if (!data) {
        return res.status(206).json({
            success: false,
            message: "Data Not Found"
        });
    } else {
        return res.status(200).json(data);
    }
});
exports.FU = catchError(async (req, res, next)=>{
    const data = await executeQuery("SELECT * FROM goh_faqs", "gohoardi_goh", next);
    if (!data) {
        return res.status(206).json({
            success: false,
            message: "Data Not Found"
        });
    } else {
        return res.status(200).json(data);
    }
});
exports.Be = catchError(async (req, res, next)=>{
    const data = await executeQuery("SELECT * FROM goh_media_and_news", "gohoardi_goh", next);
    if (!data) {
        return res.status(206).json({
            success: false,
            message: "Data Not Found"
        });
    } else {
        return res.status(200).json(data);
    }
});
exports.bg = catchError(async (req, res, next)=>{
    const data = await executeQuery("SELECT * FROM goh_testimonials", "gohoardi_goh", next);
    if (!data) {
        return res.status(206).json({
            success: false,
            message: "Data Not Found"
        });
    } else {
        return res.status(200).json(data);
    }
});


/***/ })

};
;