"use strict";
exports.id = 103;
exports.ids = [103];
exports.modules = {

/***/ 3974:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9816);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);



function Loader() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "jsx-8fb85bf949523d78" + " " + "loading-container text-center",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                width: 100,
                height: 250,
                src: "/images/web_pics/loading.gif",
                className: "loading"
            }),
            react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default()), {
                id: "8fb85bf949523d78",
                children: ".loading.jsx-8fb85bf949523d78{height:200px!important;width:auto}"
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Loader);


/***/ }),

/***/ 103:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _react_google_maps_api__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2433);
/* harmony import */ var _react_google_maps_api__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_react_google_maps_api__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _streetview__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5283);
/* harmony import */ var _styles_markers_module_scss__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5604);
/* harmony import */ var _styles_markers_module_scss__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_styles_markers_module_scss__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _allApi_apis__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1889);
/* harmony import */ var _components_loader__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3974);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_allApi_apis__WEBPACK_IMPORTED_MODULE_5__]);
_allApi_apis__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];









const Markers = ({ markers , nsearch , setSearch , removefromCart , addonCart , More  })=>{
    const [map, setMap] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [hasmarker, sethasmarker] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [combinedArray, setCombinedArray] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    if (markers) {
        markers.forEach((e)=>{
            e["position"] = {
                lat: parseFloat(e.latitude),
                lng: parseFloat(e.longitude)
            };
        });
    }
    var center = {
        lat: markers?.[0].latitude,
        lng: markers?.[0].longitude
    };
    const updateCombinedArray = ()=>{
        if (nsearch) {
            const newArray = [].concat(...nsearch);
            newArray.forEach((e)=>{
                e["position"] = {
                    lat: e.lat,
                    lng: e.lng
                };
            });
            setCombinedArray(newArray);
        }
    };
    const [activeMarker, setActiveMarker] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const handleActiveMarker = (marker)=>{
        if (marker === activeMarker) {
            return;
        }
        setActiveMarker(marker);
    };
    const handleOnLoad = (map)=>{
        if (markers) {
            setMap(map);
            const bounds = new window.google.maps.LatLngBounds();
            markers.forEach(({ position  })=>bounds.extend(position));
            map.fitBounds(bounds);
        }
    };
    const onBoundsChanged = async ()=>{
        if (map) {
            const mapThing = map;
            const bounds = mapThing.getBounds();
            const ne = bounds.getNorthEast();
            const sw = bounds.getSouthWest();
            const data = await (0,_allApi_apis__WEBPACK_IMPORTED_MODULE_5__/* .markersPosition */ .vF)(ne.lat(), sw.lat(), ne.lng(), sw.lng());
            if (data.length > 0) {
                setSearch(data);
            }
        }
    };
    const customMapStyle = [
        {
            featureType: "landscape.man_made",
            elementType: "geometry",
            stylers: [
                {
                    color: "#f7f1df"
                }
            ]
        },
        {
            featureType: "landscape.natural",
            elementType: "geometry",
            stylers: [
                {
                    color: "#d0e3b4"
                }
            ]
        },
        {
            featureType: "landscape.natural.terrain",
            elementType: "geometry",
            stylers: [
                {
                    visibility: "off"
                }
            ]
        },
        {
            featureType: "poi",
            elementType: "labels",
            stylers: [
                {
                    visibility: "off"
                }
            ]
        },
        {
            featureType: "poi.business",
            elementType: "all",
            stylers: [
                {
                    visibility: "off"
                }
            ]
        },
        {
            featureType: "poi.medical",
            elementType: "geometry",
            stylers: [
                {
                    color: "#fbd3da"
                }
            ]
        },
        {
            featureType: "poi.park",
            elementType: "geometry",
            stylers: [
                {
                    color: "#bde6ab"
                }
            ]
        },
        {
            featureType: "road",
            elementType: "geometry.stroke",
            stylers: [
                {
                    visibility: "off"
                }
            ]
        },
        {
            featureType: "road",
            elementType: "labels",
            stylers: [
                {
                    visibility: "off"
                }
            ]
        },
        {
            featureType: "road.highway",
            elementType: "geometry.fill",
            stylers: [
                {
                    color: "#ffe15f"
                }
            ]
        },
        {
            featureType: "road.highway",
            elementType: "geometry.stroke",
            stylers: [
                {
                    color: "#efd151"
                }
            ]
        },
        {
            featureType: "road.arterial",
            elementType: "geometry.fill",
            stylers: [
                {
                    color: "#ffffff"
                }
            ]
        },
        {
            featureType: "road.local",
            elementType: "geometry.fill",
            stylers: [
                {
                    color: "black"
                }
            ]
        },
        {
            featureType: "transit.station.airport",
            elementType: "geometry.fill",
            stylers: [
                {
                    color: "#cfb2db"
                }
            ]
        },
        {
            featureType: "water",
            elementType: "geometry",
            stylers: [
                {
                    color: "#a2daf2"
                }
            ]
        }
    ];
    const [streetView, setStreetView] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [latitude, setLatitude] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [longitude, setlongitude] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const onStreet = (latitude, longitude)=>{
        setlongitude(longitude);
        setLatitude(latitude);
        setStreetView(!streetView);
    };
    const closeKeyword = ()=>{
        setStreetView(!streetView);
        setActiveMarker(null);
        sethasmarker(false);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (markers?.[markers.length - 1].position) {
            sethasmarker(true);
        }
    }, [
        streetView
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        updateCombinedArray();
    }, [
        nsearch
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: streetView ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_streetview__WEBPACK_IMPORTED_MODULE_4__["default"], {
            latitude: latitude,
            longitude: longitude,
            closeKeyword: closeKeyword
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_google_maps_api__WEBPACK_IMPORTED_MODULE_2__.GoogleMap, {
                onLoad: handleOnLoad,
                zoom: "8",
                onClick: ()=>setActiveMarker(null),
                mapContainerStyle: {
                    height: "100%"
                },
                center: center,
                options: {
                    styles: customMapStyle
                },
                streetView: activeMarker,
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: `${(_styles_markers_module_scss__WEBPACK_IMPORTED_MODULE_8___default().this_area)} d-flex`,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: (_styles_markers_module_scss__WEBPACK_IMPORTED_MODULE_8___default().this_area_button),
                                onClick: ()=>onBoundsChanged(),
                                children: "Search in this area"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: (_styles_markers_module_scss__WEBPACK_IMPORTED_MODULE_8___default().this_area_button),
                                onClick: ()=>More(),
                                children: "Load more"
                            })
                        ]
                    }),
                    !hasmarker ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_loader__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}) : markers.map(({ id , position , medianame , price , illumination , subcategory , height , width , ftf , code , category_name , thumb , isDelete , mediaownercompanyname , latitude , longitude , meta_title  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_google_maps_api__WEBPACK_IMPORTED_MODULE_2__.Marker, {
                            icon: isDelete == 0 ? "/images/web_pics/placeholder2.png" : "/images/web_pics/placeholder.png",
                            position: position,
                            onClick: ()=>handleActiveMarker(id),
                            children: activeMarker === id ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_google_maps_api__WEBPACK_IMPORTED_MODULE_2__.InfoWindow, {
                                onCloseClick: ()=>setActiveMarker(null),
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_styles_markers_module_scss__WEBPACK_IMPORTED_MODULE_8___default().infoWindow),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: (_styles_markers_module_scss__WEBPACK_IMPORTED_MODULE_8___default().media_image),
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                href: `/seedetails/${category_name}/${meta_title}`,
                                                className: "text-decoration-none",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                    width: 500,
                                                    height: 500,
                                                    src: thumb.startsWith("https") ? thumb : `https://${mediaownercompanyname.trim().split(" ").slice(0, 2).join("_").toLowerCase()}.odoads.com/media/${mediaownercompanyname.trim().split(" ").slice(0, 2).join("_").toLowerCase()}/media/images/new${thumb}`,
                                                    alt: "About media",
                                                    className: "rounded-top",
                                                    id: (_styles_markers_module_scss__WEBPACK_IMPORTED_MODULE_8___default().mark_img)
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: `${(_styles_markers_module_scss__WEBPACK_IMPORTED_MODULE_8___default().info_window)} bg-white`,
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                    href: `/seedetails/${category_name}/${meta_title}`,
                                                    className: "text-decoration-none",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                                        className: " text-dark",
                                                        children: illumination + "-" + medianame
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            children: "Media Type : "
                                                        }),
                                                        subcategory
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            children: "Height X Width : "
                                                        }),
                                                        height,
                                                        " X ",
                                                        width,
                                                        " feet"
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            children: "FTF : "
                                                        }),
                                                        ftf
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                    width: 500,
                                                    height: 500,
                                                    src: "/images/web_pics/streetv.gif",
                                                    className: (_styles_markers_module_scss__WEBPACK_IMPORTED_MODULE_8___default().streetv),
                                                    onClick: (e, i)=>onStreet(latitude, longitude)
                                                }),
                                                isDelete === 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                    width: 500,
                                                    height: 500,
                                                    src: "/images/web_pics/A-chek.png",
                                                    onClick: ()=>removefromCart(code),
                                                    className: `${(_styles_markers_module_scss__WEBPACK_IMPORTED_MODULE_8___default().addonCart)} icon-clr ${(_styles_markers_module_scss__WEBPACK_IMPORTED_MODULE_8___default().sitemark)} `,
                                                    alt: "check_button"
                                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                    width: 500,
                                                    height: 500,
                                                    alt: "cart_icon",
                                                    src: "/images/web_pics/A-cart.png",
                                                    onClick: ()=>addonCart(code, category_name),
                                                    className: `${(_styles_markers_module_scss__WEBPACK_IMPORTED_MODULE_8___default().addonCart)} icon-clr ${(_styles_markers_module_scss__WEBPACK_IMPORTED_MODULE_8___default().sitemark)} `
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }) : null
                        }, id)),
                    combinedArray.map(({ id , position , name , Type , city_name , photo  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_google_maps_api__WEBPACK_IMPORTED_MODULE_2__.Marker, {
                            icon: "/images/web_pics/restaurant.png",
                            position: position,
                            onClick: ()=>handleActiveMarker(id),
                            children: activeMarker === id && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_google_maps_api__WEBPACK_IMPORTED_MODULE_2__.InfoWindow, {
                                onCloseClick: ()=>setActiveMarker(null),
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_styles_markers_module_scss__WEBPACK_IMPORTED_MODULE_8___default().infoWindow),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: (_styles_markers_module_scss__WEBPACK_IMPORTED_MODULE_8___default().media_image),
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                width: 500,
                                                height: 500,
                                                src: `https://maps.googleapis.com/maps/api/place/photo?photoreference=` + photo + `&sensor=false&maxheight=210&maxwidth=330&key=AIzaSyDEKx_jLb_baUKyDgkXvzS_o-xlOkvLpeE`,
                                                alt: "",
                                                srcset: "",
                                                onError: (e)=>e.target.src = "/images/web_pics/alter-img.png"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                            className: "mb-2",
                                            children: [
                                                "Name : ",
                                                name
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                            className: "mb-2",
                                            children: [
                                                "Type : ",
                                                Type
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                            className: "mb-2",
                                            children: [
                                                "City : ",
                                                city_name
                                            ]
                                        })
                                    ]
                                })
                            })
                        }, id))
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Markers);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;