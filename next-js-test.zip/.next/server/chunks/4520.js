exports.id = 4520;
exports.ids = [4520];
exports.modules = {

/***/ 8546:
/***/ ((module) => {

// Exports
module.exports = {
	"our_clients_content": "enquire_our_clients_content__YQ2mp",
	"trending_cardd": "enquire_trending_cardd__djH4h",
	"enquire_content": "enquire_enquire_content__zUYlZ",
	"enquire_description_row": "enquire_enquire_description_row__zsJ4z",
	"enquire_description": "enquire_enquire_description__k_rr9",
	"enquire_qsns_cant": "enquire_enquire_qsns_cant__j_6go",
	"enquire_qsns_cant_qsn": "enquire_enquire_qsns_cant_qsn__axOVc",
	"enquire_ans_cant": "enquire_enquire_ans_cant__XMzvP",
	"hor_border": "enquire_hor_border__KVGNu",
	"txt_clr_tlk": "enquire_txt_clr_tlk__IA9TW",
	"txt_clr": "enquire_txt_clr__Yb5BU",
	"form-control": "enquire_form-control__CX_yW",
	"message_btn": "enquire_message_btn__KMPfy"
};


/***/ }),

/***/ 4520:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8096);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _enquireregister__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2928);
/* harmony import */ var _styles_enquire_module_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8546);
/* harmony import */ var _styles_enquire_module_scss__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_styles_enquire_module_scss__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _allApi_apis__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1889);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_enquireregister__WEBPACK_IMPORTED_MODULE_3__, _allApi_apis__WEBPACK_IMPORTED_MODULE_5__]);
([_enquireregister__WEBPACK_IMPORTED_MODULE_3__, _allApi_apis__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const Enquire = ()=>{
    const [logo, SetLogo] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const allLogo = async ()=>{
        const data = await (0,_allApi_apis__WEBPACK_IMPORTED_MODULE_5__/* .brandLogoApi */ .v0)();
        SetLogo(data);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        allLogo();
    }, []);
    const slice = logo.slice(0, 21);
    {
        var settings = {
            pauseOnHover: false,
            infinite: true,
            slidesToShow: 7,
            slidesToScroll: 3,
            autoplay: true,
            speed: 4700,
            autoplaySpeed: 4700,
            cssEase: "linear",
            responsive: [
                {
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 4,
                        slidesToScroll: 2,
                        initialSlide: 0
                    }
                },
                {
                    breakpoint: 425,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 3,
                        initialSlide: 0
                    }
                }
            ]
        };
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                className: `${(_styles_enquire_module_scss__WEBPACK_IMPORTED_MODULE_6___default().our_clients_content)} my-4 enqry`,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_slick__WEBPACK_IMPORTED_MODULE_2___default()), {
                    ...settings,
                    children: slice.map((clients, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "container pt-md-3",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "row  ",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col p-md-3 ",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                                        width: 160,
                                        height: 100,
                                        src: clients.img,
                                        alt: clients.alt,
                                        className: `rounded-2  ${(_styles_enquire_module_scss__WEBPACK_IMPORTED_MODULE_6___default().trending_cardd)}`
                                    }, i)
                                })
                            })
                        }, i))
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `container-xxl  container-xl container-lg container-md ${(_styles_enquire_module_scss__WEBPACK_IMPORTED_MODULE_6___default().enquire_content)} py-2 py-md-5 my-md-3 px-md-5 `,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: `row p-2 ${(_styles_enquire_module_scss__WEBPACK_IMPORTED_MODULE_6___default().enquire_description_row)}`,
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: ` col-md-4  p-4 p-md-3  ${(_styles_enquire_module_scss__WEBPACK_IMPORTED_MODULE_6___default().enquire_description)} col-xs-0`,
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h3", {
                                    className: `${(_styles_enquire_module_scss__WEBPACK_IMPORTED_MODULE_6___default().enquire_qsns_cant)} text-light`,
                                    children: [
                                        "What can Gohoardings",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        " help you with?"
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: `${(_styles_enquire_module_scss__WEBPACK_IMPORTED_MODULE_6___default().hor_border)} py-2`,
                                    children: " "
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "row ",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                            className: `${(_styles_enquire_module_scss__WEBPACK_IMPORTED_MODULE_6___default().enquire_qsns_cant_qsn)}  mb-1`,
                                            children: "Have a requirement ?"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: (_styles_enquire_module_scss__WEBPACK_IMPORTED_MODULE_6___default().enquire_ans_cant),
                                            children: "Tell us your requirements and we will reach you with the brainstormed, creative and most effective solutions instantly."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "row py-1",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                            className: `${(_styles_enquire_module_scss__WEBPACK_IMPORTED_MODULE_6___default().enquire_qsns_cant_qsn)}  mb-1`,
                                            children: "Have a query ?"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: (_styles_enquire_module_scss__WEBPACK_IMPORTED_MODULE_6___default().enquire_ans_cant),
                                            children: "Feel free to write to us. Our reps are right there to answer them all."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "row py-1",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                            className: (_styles_enquire_module_scss__WEBPACK_IMPORTED_MODULE_6___default().enquire_qsns_cant_qsn),
                                            children: "Have a suggestion?"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: `${(_styles_enquire_module_scss__WEBPACK_IMPORTED_MODULE_6___default().enquire_ans_cant)} mb-4`,
                                            children: "Your feedback and suggestions are always welcome. We are constantly striving to be better than what we were yesterday."
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: " col-md-8 p-md-3 p-md-3 ps-md-5 pt-md-2 ",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_enquireregister__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Enquire);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2928:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9816);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3590);
/* harmony import */ var _styles_enquire_module_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8546);
/* harmony import */ var _styles_enquire_module_scss__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_styles_enquire_module_scss__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _allApi_apis__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1889);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_3__, _allApi_apis__WEBPACK_IMPORTED_MODULE_4__]);
([react_toastify__WEBPACK_IMPORTED_MODULE_3__, _allApi_apis__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const Enquireregister = ()=>{
    const [name, setName] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const [phone, setNumber] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const [email, setEmail] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const [message, setMessage] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const [error, setEror] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    let count = 0;
    const onSubmit = async (e)=>{
        e.preventDefault();
        if (name === "") {
            setEror(true);
            count = +1;
        } else if (phone.length !== 10) {
            count = +1;
            setEror(true);
        } else if (!_allApi_apis__WEBPACK_IMPORTED_MODULE_4__/* .emailformate.test */ .mX.test(email)) {
            count = +1;
            setEror(true);
        } else if (message === "") {
            count = +1;
            setEror(true);
        } else if (count === 0) {
            const data = await (0,_allApi_apis__WEBPACK_IMPORTED_MODULE_4__/* .enquiryApi */ .CL)(name, email, phone, message);
            if (data.success == true) {
                setName("");
                setNumber("");
                setEmail("");
                setMessage("");
                setEror(false);
                (0,react_toastify__WEBPACK_IMPORTED_MODULE_3__.toast)(data.message);
            }
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                className: "jsx-885616695b5f7f09" + " " + ((_styles_enquire_module_scss__WEBPACK_IMPORTED_MODULE_5___default().txt_clr_tlk) || ""),
                children: "Talk to us!"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                className: "jsx-885616695b5f7f09" + " " + ((_styles_enquire_module_scss__WEBPACK_IMPORTED_MODULE_5___default().txt_clr) || ""),
                children: "*Please fill all the details."
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                onSubmit: onSubmit,
                className: "jsx-885616695b5f7f09" + " " + "mt-md-4  mt-2 position-relative",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "jsx-885616695b5f7f09" + " " + "form-group py-md-3 py-1",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                htmlFor: "formGroupExampleInput",
                                className: "jsx-885616695b5f7f09",
                                children: "Name*"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                autoComplete: "off",
                                type: "text",
                                id: "formGroupExampleInput",
                                placeholder: "Your Full Name",
                                value: name,
                                onChange: (e)=>{
                                    setName(e.target.value);
                                },
                                className: "jsx-885616695b5f7f09" + " " + "form-control ps-0 rounded-0"
                            }),
                            error == true && name === "" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                                className: "jsx-885616695b5f7f09" + " " + "p-0 text-danger text-small ",
                                children: "Please enter your name"
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: " "
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "jsx-885616695b5f7f09" + " " + "row py-md-3 py-1",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "jsx-885616695b5f7f09" + " " + "col",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        htmlFor: "Last-name",
                                        className: "jsx-885616695b5f7f09",
                                        children: "Email*"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        type: "text",
                                        autoComplete: "off",
                                        placeholder: "Your Mail ID",
                                        id: "first-name",
                                        value: email,
                                        onChange: (e)=>{
                                            setEmail(e.target.value);
                                        },
                                        className: "jsx-885616695b5f7f09" + " " + "form-control ps-0 rounded-0"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                        className: "jsx-885616695b5f7f09" + " " + "error-msg",
                                        children: [
                                            " ",
                                            error == true && !_allApi_apis__WEBPACK_IMPORTED_MODULE_4__/* .emailformate.test */ .mX.test(email) ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                                                className: "jsx-885616695b5f7f09" + " " + "p-0 p-0 text-danger text-small  ",
                                                children: "Type your email corectly"
                                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                children: " "
                                            }),
                                            " "
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "jsx-885616695b5f7f09" + " " + "col",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        htmlFor: "Last-name",
                                        className: "jsx-885616695b5f7f09",
                                        children: "phone*"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        autoComplete: "off",
                                        type: "number",
                                        placeholder: "012 3456 789",
                                        value: phone,
                                        onChange: (e)=>setNumber(e.target.value),
                                        className: "jsx-885616695b5f7f09" + " " + "form-control ps-0 rounded-0"
                                    }),
                                    error == true && phone.length !== 10 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                                        className: "jsx-885616695b5f7f09" + " " + "p-0 text-danger text-small  ",
                                        children: "Type your 10 digit phone corectly"
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                        children: " "
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "jsx-885616695b5f7f09" + " " + "form-group py-md-3 py-1",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                htmlFor: "formGroupExampleInput2",
                                className: "jsx-885616695b5f7f09",
                                children: "Message*"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                autoComplete: "off",
                                type: "text",
                                id: "formGroupExampleInput2",
                                placeholder: "Write your message..",
                                value: message,
                                onChange: (e)=>{
                                    setMessage(e.target.value);
                                },
                                className: "jsx-885616695b5f7f09" + " " + "form-control ps-0 rounded-0"
                            }),
                            error == true && message === "" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                                className: "jsx-885616695b5f7f09" + " " + "p-0 text-danger text-small  p-0 ",
                                children: "Please enter your message for our team"
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: " "
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "jsx-885616695b5f7f09" + " " + " p-0 mt-1 mt-md-0 position-relative ",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                type: "submit",
                                role: "button",
                                className: "jsx-885616695b5f7f09" + " " + `btn btn-lg ${(_styles_enquire_module_scss__WEBPACK_IMPORTED_MODULE_5___default().message_btn)}  float-end`,
                                children: "Send Message"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_toastify__WEBPACK_IMPORTED_MODULE_3__.ToastContainer, {})
                        ]
                    })
                ]
            }),
            react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default()), {
                id: "885616695b5f7f09",
                children: ".form-control.jsx-885616695b5f7f09{border:none!important;border-bottom:1px solid#b5b4b4!important}label.jsx-885616695b5f7f09{color:#6c757d!important;font-size:.9rem}.jsx-885616695b5f7f09::-webkit-input-placeholder{font-size:1rem!important}.form-control.jsx-885616695b5f7f09:focus{border-color:rgba(100,100,100,1)!important;-webkit-box-shadow:none!important;-moz-box-shadow:none!important;box-shadow:none!important}@media screen and (max-width:425px){.txt-clr-tlk.jsx-885616695b5f7f09{color:#373435;font-size:1.6rem}.txt-clr.jsx-885616695b5f7f09{color:#373435}.jsx-885616695b5f7f09::-webkit-input-placeholder{font-size:.9rem!important}.message-btn.jsx-885616695b5f7f09{font-size:.9rem}}"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Enquireregister);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;