"use strict";
exports.id = 3651;
exports.ids = [3651];
exports.modules = {

/***/ 3651:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _login__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9083);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _signup__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7733);
/* harmony import */ var _forgetPass__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6413);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3590);
/* harmony import */ var _allApi_apis__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1889);
/* harmony import */ var react_google_login__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(67);
/* harmony import */ var react_google_login__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_google_login__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4041);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_icons_md__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9332);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_navigation__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _styles_login_module_scss__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(8522);
/* harmony import */ var _styles_login_module_scss__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_styles_login_module_scss__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var cookies_next__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8982);
/* harmony import */ var cookies_next__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(cookies_next__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _allApi_apicontext__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3484);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9847);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_icons_ai__WEBPACK_IMPORTED_MODULE_13__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_signup__WEBPACK_IMPORTED_MODULE_4__, _forgetPass__WEBPACK_IMPORTED_MODULE_5__, react_toastify__WEBPACK_IMPORTED_MODULE_6__, _allApi_apis__WEBPACK_IMPORTED_MODULE_7__, _allApi_apicontext__WEBPACK_IMPORTED_MODULE_12__]);
([_signup__WEBPACK_IMPORTED_MODULE_4__, _forgetPass__WEBPACK_IMPORTED_MODULE_5__, react_toastify__WEBPACK_IMPORTED_MODULE_6__, _allApi_apis__WEBPACK_IMPORTED_MODULE_7__, _allApi_apicontext__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);















const LoginN = ()=>{
    const [name, setName] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [nameValidate, setNameValidate] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [email, setEmail] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [emailsValidate, setEmailsValidate] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [password, setPassword] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [passwordsValidate, setPasswordsValidate] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [phone, setNumber] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const { handleClose , addRemove  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_allApi_apicontext__WEBPACK_IMPORTED_MODULE_12__/* .AccountContext */ .w0);
    const [numbervalidate, setNumbervalidate] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [forget, setForget] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [pass, setPass] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [fnotify, setFnotify] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [signin, setSignIn] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const [otp, setOtp] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [sendOtp, setSendOtp] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [expire, setexpire] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [confirmpasswords, setconfirmPasswords] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [withOtp, setWithOtp] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [success, setSuccess] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const navigate = (0,next_navigation__WEBPACK_IMPORTED_MODULE_10__.useRouter)();
    const afterLogin = async ()=>{
        (0,cookies_next__WEBPACK_IMPORTED_MODULE_11__.setCookie)("permissions", true);
        addRemove({
            type: "DECR"
        });
        handleClose();
        setSuccess(true);
        setSendOtp(false);
    };
    // Google Login Request
    const onSuccess = async (res)=>{
        const profile = res.profileObj;
        const data = await (0,_allApi_apis__WEBPACK_IMPORTED_MODULE_7__/* .googleLogin */ .u9)(profile);
        if (data.success === true) {
            afterLogin();
        } else {
            (0,react_toastify__WEBPACK_IMPORTED_MODULE_6__.toast)(data.message);
        }
    };
    // Google Login failures
    const onFailure = async (res)=>{
        return false;
    };
    const { signIn  } = (0,react_google_login__WEBPACK_IMPORTED_MODULE_8__.useGoogleLogin)({
        onSuccess,
        clientId: _allApi_apis__WEBPACK_IMPORTED_MODULE_7__/* .clientId */ .I4,
        onFailure
    });
    const checkOTPForLogin = async (e)=>{
        e.preventDefault();
        const data = await (0,_allApi_apis__WEBPACK_IMPORTED_MODULE_7__/* .loginOTP */ .Gm)(otp);
        if (data.success === true) {
            afterLogin();
        } else {
            (0,react_toastify__WEBPACK_IMPORTED_MODULE_6__.toast)(data.message);
        }
    };
    let count = 0;
    const [eyeViseble, setEyeViseble] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const onVisible = ()=>{
        let x = document.getElementById("inputPassword");
        if (x.type == "password") {
            x.type = "text";
            setEyeViseble(!eyeViseble);
        } else {
            x.type = "password";
            setEyeViseble(!eyeViseble);
        }
    };
    //validation and submit  for signIn
    const onSignIn = async (e)=>{
        if (email === "") {
            count = +1;
            setEmailsValidate(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_9__.MdOutlineError, {
                className: "text-danger"
            }));
        } else if (!_allApi_apis__WEBPACK_IMPORTED_MODULE_7__/* .emailformate.test */ .mX.test(email)) {
            count = +1;
            setEmailsValidate("Type your email corectly");
        } else if (password === "") {
            count = +1;
            setPasswordsValidate(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_9__.MdOutlineError, {
                className: "text-danger"
            }));
        } else if (count === 0) {
            e.preventDefault();
            const data = await (0,_allApi_apis__WEBPACK_IMPORTED_MODULE_7__/* .loginUser */ .pH)(email, password);
            if (data.success === true) {
                afterLogin();
            } else {
                (0,react_toastify__WEBPACK_IMPORTED_MODULE_6__.toast)(data.message);
            }
        }
        e.preventDefault();
    };
    //toggle between signIn & register
    const toggleSignUp = ()=>{
        setSignIn(!signin);
    };
    //foget password
    const clickforget = ()=>{
        setForget(true);
    };
    const onForget = async (e)=>{
        e.preventDefault();
        if (isNaN(parseInt(phone))) {
            const data = await (0,_allApi_apis__WEBPACK_IMPORTED_MODULE_7__/* .emailOTP */ .dQ)(phone);
            if (data.success == true) {
                setSendOtp(true);
            } else {
                (0,react_toastify__WEBPACK_IMPORTED_MODULE_6__.toast)(data.message);
            }
        } else {
            const data = await (0,_allApi_apis__WEBPACK_IMPORTED_MODULE_7__/* .mobileOTP */ .yA)(phone);
            if (data.success == true) {
                setSendOtp(true);
            } else {
                (0,react_toastify__WEBPACK_IMPORTED_MODULE_6__.toast)(data.message);
            }
        }
    };
    const changePassword = async (e)=>{
        e.preventDefault();
        const data = await (0,_allApi_apis__WEBPACK_IMPORTED_MODULE_7__/* .changePasswordApi */ .dt)(password, confirmpasswords, expire);
        setPassword(" ");
        setconfirmPasswords(" ");
        if (data.success === true) {
            afterLogin();
        } else {
            (0,react_toastify__WEBPACK_IMPORTED_MODULE_6__.toast)(data.message);
        }
    };
    const checkOTP = async (e)=>{
        e.preventDefault();
        const data = await (0,_allApi_apis__WEBPACK_IMPORTED_MODULE_7__/* .sendOTP */ .OA)(otp);
        if (data.success === true) {
            setexpire(data.message);
            setPass(true);
        } else {
            (0,react_toastify__WEBPACK_IMPORTED_MODULE_6__.toast)(data.message);
        }
    };
    const onRegister = async (e)=>{
        e.preventDefault();
        if (phone.length <= 0) {
            count = +1;
            setNumbervalidate(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_9__.MdOutlineError, {
                className: "text-danger"
            }));
        } else if (phone.length != 10) {
            count = +1;
            setNumbervalidate("Type your 10 digit no correctly");
        } else if (email === "") {
            count = +1;
            setEmailsValidate(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_9__.MdOutlineError, {
                className: "text-danger"
            }));
        } else if (!_allApi_apis__WEBPACK_IMPORTED_MODULE_7__/* .emailformate.test */ .mX.test(email)) {
            count = +1;
            setEmailsValidate("Type your email corectly");
        } else if (password === "") {
            count = +1;
            setPasswordsValidate(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_9__.MdOutlineError, {
                className: "text-danger"
            }));
        } else if (count === 0) {
            e.preventDefault();
            const data = await (0,_allApi_apis__WEBPACK_IMPORTED_MODULE_7__/* .registerUser */ .a$)(email, phone);
            if (data.success === true) {
                setSendOtp(true);
                return true;
            } else {
                (0,react_toastify__WEBPACK_IMPORTED_MODULE_6__.toast)(data.message);
            }
        }
    };
    const registerOtp = async (e)=>{
        e.preventDefault();
        if (name === "") {
            count = +1;
            setNameValidate(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_9__.MdOutlineError, {
                className: "text-danger"
            }));
        } else if (phone.length <= 0) {
            count = +1;
            setNumbervalidate(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_9__.MdOutlineError, {
                className: "text-danger"
            }));
        } else if (phone.length != 10) {
            count = +1;
            setNumbervalidate("Type your 10 digit no correctly");
        } else if (email === "") {
            count = +1;
            setEmailsValidate(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_9__.MdOutlineError, {
                className: "text-danger"
            }));
        } else if (!_allApi_apis__WEBPACK_IMPORTED_MODULE_7__/* .emailformate.test */ .mX.test(email)) {
            count = +1;
            setEmailsValidate("Type your email corectly");
        } else if (password === "") {
            count = +1;
            setPasswordsValidate(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_9__.MdOutlineError, {
                className: "text-danger"
            }));
        } else if (password.length <= 3) {
            setPasswordsValidate("Password should be atleast 4 digit ");
        } else if (count === 0 && _allApi_apis__WEBPACK_IMPORTED_MODULE_7__/* .sendOTP */ .OA) {
            const data = await (0,_allApi_apis__WEBPACK_IMPORTED_MODULE_7__/* .OtpRegister */ .sk)(name, email, phone, password, otp);
            if (data.success === true) {
                afterLogin();
            } else {
                (0,react_toastify__WEBPACK_IMPORTED_MODULE_6__.toast)(data.message);
            }
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "lgn",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: " d-flex",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "col-md-6 ",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_styles_login_module_scss__WEBPACK_IMPORTED_MODULE_14___default().wrapper),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: `${(_styles_login_module_scss__WEBPACK_IMPORTED_MODULE_14___default().opacitydiv)} rounded-4 `,
                            children: signin ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: [
                                    " ",
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: `${(_styles_login_module_scss__WEBPACK_IMPORTED_MODULE_14___default().title)} pt-3 ps-4  `,
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                                                children: [
                                                    "Promote ",
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                    "your brand"
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                                children: "in just one click"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                                        width: 500,
                                        height: 500,
                                        src: "/images/web_pics/login1.png",
                                        className: (_styles_login_module_scss__WEBPACK_IMPORTED_MODULE_14___default().img_responsive),
                                        alt: "Registraion"
                                    })
                                ]
                            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: `${(_styles_login_module_scss__WEBPACK_IMPORTED_MODULE_14___default().title)} pt-3 ps-4 `,
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                                                children: [
                                                    "Gohoardings ",
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                    "OOH Advertising"
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                                children: "made easy & affordable"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h6", {
                                                children: [
                                                    "Create an account for best OOH media ",
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                    "solutions in just a few clicks."
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                                        width: 500,
                                        height: 500,
                                        src: "/images/web_pics/login2.png",
                                        className: (_styles_login_module_scss__WEBPACK_IMPORTED_MODULE_14___default().img_responsive2),
                                        alt: "Login image"
                                    })
                                ]
                            })
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "col-md-6 p-4 m-0",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: `container-xxl  container-xl container-lg container-md  ${(_styles_login_module_scss__WEBPACK_IMPORTED_MODULE_14___default().login_container2)}`,
                        children: forget ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_forgetPass__WEBPACK_IMPORTED_MODULE_5__["default"], {
                                setconfirmPasswords: setconfirmPasswords,
                                expire: expire,
                                setOtp: setOtp,
                                otp: otp,
                                setNumber: setNumber,
                                checkOTP: checkOTP,
                                changePassword: changePassword,
                                phone: phone,
                                success: success,
                                sendOtp: sendOtp,
                                setSendOtp: setSendOtp,
                                onForget: onForget,
                                fnotif: fnotify,
                                emailsValidate: emailsValidate,
                                password: password,
                                setPassword: setPassword,
                                setForget: setForget,
                                setPass: setPass,
                                pass: pass
                            })
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: signin ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_login__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                setEmailValidate: setEmailsValidate,
                                onSignIn: onSignIn,
                                afterLogin: afterLogin,
                                setEmail: setEmail,
                                email: email,
                                setWithOtp: setWithOtp,
                                success: success,
                                withOtp: withOtp,
                                sendOtp: sendOtp,
                                emailsValidate: emailsValidate,
                                passwordsValidate: passwordsValidate,
                                setPassword: setPassword,
                                password: password,
                                onVisible: onVisible,
                                eyeViseble: eyeViseble,
                                AiFillEye: react_icons_ai__WEBPACK_IMPORTED_MODULE_13__.AiFillEye,
                                AiFillEyeInvisible: react_icons_ai__WEBPACK_IMPORTED_MODULE_13__.AiFillEyeInvisible,
                                clickforget: clickforget,
                                ToastContainer: react_toastify__WEBPACK_IMPORTED_MODULE_6__.ToastContainer,
                                googleSignIn: signIn,
                                toggleSignUp: toggleSignUp,
                                onForget: onForget,
                                setOtp: setOtp,
                                setNumber: setNumber,
                                checkOTPForLogin: checkOTPForLogin
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_signup__WEBPACK_IMPORTED_MODULE_4__["default"], {
                                onVisible: onVisible,
                                afterLogin: afterLogin,
                                eyeViseble: eyeViseble,
                                toggleSignUp: toggleSignUp,
                                signIn: signIn,
                                toast: react_toastify__WEBPACK_IMPORTED_MODULE_6__.toast,
                                success: success,
                                sendOtp: sendOtp,
                                passwordsValidate: passwordsValidate,
                                setPassword: setPassword,
                                password: password,
                                setEmail: setEmail,
                                email: email,
                                emailsValidate: emailsValidate,
                                numbervalidate: numbervalidate,
                                phone: phone,
                                AiFillEyeInvisible: react_icons_ai__WEBPACK_IMPORTED_MODULE_13__.AiFillEyeInvisible,
                                AiFillEye: react_icons_ai__WEBPACK_IMPORTED_MODULE_13__.AiFillEye,
                                setNumber: setNumber,
                                nameValidate: nameValidate,
                                setName: setName,
                                name: name,
                                onRegister: onRegister,
                                onForget: onForget,
                                setOtp: setOtp,
                                checkOTPForLogin: checkOTPForLogin,
                                registerOtp: registerOtp
                            })
                        })
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LoginN);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;