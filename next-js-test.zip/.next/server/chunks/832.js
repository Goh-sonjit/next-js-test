"use strict";
exports.id = 832;
exports.ids = [832];
exports.modules = {

/***/ 832:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9816);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _allApi_apis__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1889);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_allApi_apis__WEBPACK_IMPORTED_MODULE_3__]);
_allApi_apis__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const Medialogo = ({ category_name , city_name  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "jsx-4e89df513413eb5f" + " " + "media-branding-n",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "jsx-4e89df513413eb5f" + " " + "media-branding",
                    children: _allApi_apis__WEBPACK_IMPORTED_MODULE_3__/* .CityNameImage.map */ .xe.map((el, i)=>{
                        if (category_name === el.value || category_name === el.city) {
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "jsx-4e89df513413eb5f",
                                children: [
                                    " ",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: el.srcImgM,
                                        alt: el.srcImg,
                                        className: "jsx-4e89df513413eb5f"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "jsx-4e89df513413eb5f" + " " + "centered",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                                                className: "jsx-4e89df513413eb5f",
                                                children: [
                                                    "About ",
                                                    el.label
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                className: "jsx-4e89df513413eb5f" + " " + "mt-1 mt-md-4",
                                                children: [
                                                    "We can help you to grow your business in ",
                                                    city_name,
                                                    " .",
                                                    " ",
                                                    "our affordable outdoor hoarding advertising company",
                                                    " ",
                                                    "team of well-experienced marketing professionals has already studied the market; they know where to place your banner in the city so that more people will notice it. You just have to share your requirements & ideas; our team will design a banner for you, place it, and take care of permission & all the other stuff. At Go Hoarding, we are providing fully managed hoarding advertising services."
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }, i);
                        }
                    })
                })
            }),
            react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default()), {
                id: "4e89df513413eb5f",
                children: ".media-branding-n.jsx-4e89df513413eb5f{margin-top:2%}.media-branding.jsx-4e89df513413eb5f{text-align:center;color:white;position:relative;z-index:0;-webkit-transition:-webkit-transform.6s;-moz-transition:-moz-transform.6s;-o-transition:-o-transform.6s;transition:-webkit-transform.6s;transition:-moz-transform.6s;transition:-o-transform.6s;transition:transform.6s}img.jsx-4e89df513413eb5f{height:36vh;width:100%;-webkit-border-radius:6px;-moz-border-radius:6px;border-radius:6px}.centered.jsx-4e89df513413eb5f{width:76vw;position:absolute;top:50%;left:50%;-webkit-transform:translate(-50%,-50%);-moz-transform:translate(-50%,-50%);-ms-transform:translate(-50%,-50%);-o-transform:translate(-50%,-50%);transform:translate(-50%,-50%)}h1.jsx-4e89df513413eb5f{font-size:32px;font-weight:700;line-height:37.92px;color:#fff}p.jsx-4e89df513413eb5f{font-size:1.1rem;color:#fff;font-weight:300}@media screen and (max-width:1024px){img.jsx-4e89df513413eb5f{height:45vh;width:100%}h1.jsx-4e89df513413eb5f{font-size:2.8rem}p.jsx-4e89df513413eb5f{font-size:1rem}}@media screen and (max-width:425px){img.jsx-4e89df513413eb5f{height:24vh;width:100%}.centered.jsx-4e89df513413eb5f{width:95vw}h1.jsx-4e89df513413eb5f{font-size:1.2rem}p.jsx-4e89df513413eb5f{font-size:.6rem}}"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Medialogo);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;