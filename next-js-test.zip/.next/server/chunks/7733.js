"use strict";
exports.id = 7733;
exports.ids = [7733];
exports.modules = {

/***/ 7733:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _googleLogin__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5985);
/* harmony import */ var _styles_login_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8522);
/* harmony import */ var _styles_login_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_styles_login_module_scss__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3590);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_3__]);
react_toastify__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const Sign = ({ passwordsValidate , googleSignIn , toggleSignUp , sendOtp , setPassword , afterLogin , password , setEmail , email , emailsValidate , numbervalidate , phone , AiFillEye , AiFillEyeInvisible , setNumber , nameValidate , setName , name , onRegister , onForget , setOtp , checkOTPForLogin , registerOtp  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                className: " fw-bold ",
                children: "Sign up to Continue"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                onSubmit: registerOtp,
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "form-floating mt-4",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                type: "text",
                                className: "form-control",
                                autoComplete: "off",
                                placeholder: "name",
                                value: name,
                                onChange: (e)=>{
                                    setName(e.target.value);
                                }
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "ms-3 p-0 text text-danger",
                                children: nameValidate
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                htmlFor: "floatingInput",
                                children: "Full Name"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "form-floating mt-2",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                type: "email",
                                className: "form-control",
                                autoComplete: "off",
                                placeholder: "name@example.com",
                                value: email,
                                onChange: (e)=>{
                                    setEmail(e.target.value);
                                }
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "ms-2 p-0 text text-danger",
                                children: emailsValidate
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                htmlFor: "floatingInput",
                                children: "Email"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "form-floating mt-2 d-flex pe-0 ",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                type: "number",
                                className: "form-control",
                                autoComplete: "off",
                                placeholder: "0123456789",
                                id: "mnd",
                                onChange: (e)=>{
                                    setNumber(e.target.value);
                                }
                            }),
                            " ",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: "border-0",
                                id: (_styles_login_module_scss__WEBPACK_IMPORTED_MODULE_4___default().sendf),
                                onClick: onRegister,
                                children: "Send"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                htmlFor: "floatingInput",
                                children: "Phone"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "ms-2 p-0 text text-danger",
                        children: numbervalidate
                    }),
                    sendOtp && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "form-floating mt-2",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                type: "number",
                                className: "form-control",
                                autoComplete: "off",
                                placeholder: "OTP",
                                pattern: "[0-9]{3}-[0-9]{2}-[0-9]{3}",
                                onChange: (e)=>setOtp(e.target.value)
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                htmlFor: "floatingInput",
                                children: "OTP"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "form-floating  mt-2 ",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                type: "password",
                                className: "form-control",
                                autoComplete: "off",
                                id: "num",
                                placeholder: "Password",
                                value: password,
                                onChange: (e)=>{
                                    setPassword(e.target.value);
                                }
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                htmlFor: "floatingPassword",
                                children: "Password"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "ms-2 p-0 text text-danger",
                        children: passwordsValidate
                    }),
                    sendOtp ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "d-grid mt-3",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                type: "submit",
                                className: "border-0 rounded btn-lg  mb-2 ",
                                children: "Sign up"
                            }),
                            " "
                        ]
                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "d-grid mt-3",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                disabled: true,
                                className: "border-0 rounded btn-lg  mb-2 ",
                                id: "noget",
                                children: "Sign up"
                            }),
                            " "
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h6", {
                className: "mt-2",
                children: [
                    "Already have an account?  ",
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: `fw-bold ${(_styles_login_module_scss__WEBPACK_IMPORTED_MODULE_4___default()["switch"])} `,
                        onClick: ()=>toggleSignUp(),
                        children: "Login"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_googleLogin__WEBPACK_IMPORTED_MODULE_2__["default"], {
                googleSignIn: googleSignIn,
                afterLogin: afterLogin,
                setNumber: setNumber,
                onForget: onForget,
                setOtp: setOtp,
                checkOTPForLogin: checkOTPForLogin
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Sign);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;