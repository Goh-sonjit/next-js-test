exports.id = 4849;
exports.ids = [4849];
exports.modules = {

/***/ 8848:
/***/ ((module) => {

// Exports
module.exports = {
	"heading": "mediaN_heading__wDM63",
	"service": "mediaN_service__qASrg",
	"service_Icon_cnt": "mediaN_service_Icon_cnt__htUV6",
	"service_Icon": "mediaN_service_Icon__WbNlj",
	"select_media_box": "mediaN_select_media_box__hfjzB",
	"nosubmit": "mediaN_nosubmit__US4wB",
	"card_media": "mediaN_card_media__ol2b9",
	"project": "mediaN_project__aqsa7",
	"figure": "mediaN_figure__cmU72",
	"img_responsive_media": "mediaN_img_responsive_media__iGcDD",
	"project_details": "mediaN_project_details__TlRwA",
	"project_price": "mediaN_project_price__vRNc1",
	"project_creator": "mediaN_project_creator__3yDDh",
	"rupees_logo": "mediaN_rupees_logo__LusZU",
	"offer_logo": "mediaN_offer_logo__U1R28",
	"off_text": "mediaN_off_text__BrOZg",
	"addonCart": "mediaN_addonCart__sNkE6",
	"load_button": "mediaN_load_button__MudBg",
	"select_location_icon": "mediaN_select_location_icon__cSIHj",
	"no_data": "mediaN_no_data__KgvRo"
};


/***/ }),

/***/ 3974:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9816);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);



function Loader() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "jsx-8fb85bf949523d78" + " " + "loading-container text-center",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                width: 100,
                height: 250,
                src: "/images/web_pics/loading.gif",
                className: "loading"
            }),
            react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default()), {
                id: "8fb85bf949523d78",
                children: ".loading.jsx-8fb85bf949523d78{height:200px!important;width:auto}"
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Loader);


/***/ }),

/***/ 4849:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _cards__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9219);
/* harmony import */ var _styles_mediaN_module_scss__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8848);
/* harmony import */ var _styles_mediaN_module_scss__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_styles_mediaN_module_scss__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _allApi_apicontext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3484);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4041);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_md__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _allApi_apis__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1889);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_allApi_apicontext__WEBPACK_IMPORTED_MODULE_3__, _allApi_apis__WEBPACK_IMPORTED_MODULE_8__]);
([_allApi_apicontext__WEBPACK_IMPORTED_MODULE_3__, _allApi_apis__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const MainUi = ({ noOfLogo , setnoOfLogo , categoryData , mediaData , locationData , setSearch , search , category_name , onSearch , SelectServc , value , focus , serviceIcon , city , setValue , setFocus  })=>{
    const Medialogo = next_dynamic__WEBPACK_IMPORTED_MODULE_7___default()(()=>__webpack_require__.e(/* import() */ 832).then(__webpack_require__.bind(__webpack_require__, 832)), {
        loadableGenerated: {
            modules: [
                "..\\components\\mediaComponents\\MainUi.jsx -> " + "@/components/mediaBranding"
            ]
        }
    });
    const OverView = next_dynamic__WEBPACK_IMPORTED_MODULE_7___default()(()=>__webpack_require__.e(/* import() */ 5165).then(__webpack_require__.bind(__webpack_require__, 5165)), {
        loadableGenerated: {
            modules: [
                "..\\components\\mediaComponents\\MainUi.jsx -> " + "./overView"
            ]
        }
    });
    const { addRemove , handleShow  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_allApi_apicontext__WEBPACK_IMPORTED_MODULE_3__/* .AccountContext */ .w0);
    const [citys, setCity] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [ilocationvalue, setilocationValue] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [filtervalue, setFilterValue] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [categoryvalue, setcategoryValue] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const onChange = async (e)=>{
        setValue(e);
        const data = await (0,_allApi_apis__WEBPACK_IMPORTED_MODULE_8__/* .getAllCity */ .G4)(value);
        setFocus(true);
        setCity(data);
    };
    let slice;
    if (search.success != false) {
        slice = search.slice(0, noOfLogo);
    }
    let locations;
    const allLocations = locationData.map((locate)=>locate.location);
    locations = [
        ...new Set(allLocations)
    ];
    let category;
    const allSubcategory = categoryData.map((category)=>category.subcategory);
    category = [
        ...new Set(allSubcategory)
    ];
    let ILLUMINATION;
    const allIllumations = mediaData.map((illumation)=>illumation.illumination);
    ILLUMINATION = [
        ...new Set(allIllumations)
    ];
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_9__.useRouter)();
    async function categoryFilter(cate) {
        setcategoryValue(cate);
        const data = await (0,_allApi_apis__WEBPACK_IMPORTED_MODULE_8__/* .subCategoryFilterApi */ .Ef)(category_name, cate, city);
        setilocationValue("");
        setFilterValue("");
        setSearch(data);
        if (category_name !== "" && city !== "") {
            router.push({
                pathname: `/${category_name}/${city}`,
                query: {
                    category: cate
                }
            });
        } else if (category_name !== "" && city == "") {
            router.push({
                pathname: `/${category_name}`,
                query: {
                    category: cate
                }
            });
        } else if (city !== "" && category_name == "") {
            router.push({
                pathname: `/${city}`,
                query: {
                    category: cate
                }
            });
        }
    }
    async function locationFilter(loca) {
        setilocationValue(loca);
        const data = await (0,_allApi_apis__WEBPACK_IMPORTED_MODULE_8__/* .LocationFilterApi */ .ij)(category_name, loca, city);
        setcategoryValue("");
        setFilterValue("");
        setSearch(data);
        if (category_name !== "" && city !== "") {
            router.push({
                pathname: `/${category_name}/${city}`,
                query: {
                    location: loca
                }
            });
        } else if (category_name !== "" && city == "") {
            router.push({
                pathname: `/${category_name}`,
                query: {
                    location: loca
                }
            });
        } else if (city !== "" && category_name == "") {
            router.push({
                pathname: `/${city}`,
                query: {
                    location: loca
                }
            });
        }
    }
    async function mediaTypeFilter(cate) {
        setFilterValue(cate);
        const data = await (0,_allApi_apis__WEBPACK_IMPORTED_MODULE_8__/* .illuminationFilterApi */ .w4)(category_name, cate, city);
        setilocationValue("");
        setcategoryValue("");
        setSearch(data);
        if (category_name !== "" && city !== "") {
            router.push({
                pathname: `/${category_name}/${city}`,
                query: {
                    illumination: cate
                }
            });
        } else if (category_name !== "" && city == "") {
            router.push({
                pathname: `/${category_name}`,
                query: {
                    illumination: cate
                }
            });
        } else if (city !== "" && category_name == "") {
            router.push({
                pathname: `/${city}`,
                query: {
                    illumination: cate
                }
            });
        }
    }
    const addonCart = async (e)=>{
        const data = await (0,_allApi_apis__WEBPACK_IMPORTED_MODULE_8__/* .addItem */ .jX)(e.code, e.category_name);
        if (data.message == "Login First") {
            handleShow();
        } else {
            addRemove({
                type: "INCR"
            });
            add(e);
        }
    };
    const add = (event)=>{
        search.forEach((element)=>{
            if (element.code == event.code) {
                element.isDelete = 0;
            }
        });
    };
    const removefromCart = async (obj)=>{
        const data = await (0,_allApi_apis__WEBPACK_IMPORTED_MODULE_8__/* .removeItem */ .cl)(obj.code);
        if (data.message == "Done") {
            addRemove({
                type: "DECR"
            });
            remove(obj);
        }
    };
    const remove = (event)=>{
        let dataa = [
            ...search
        ];
        dataa.forEach((element)=>{
            if (element.code == event.code) {
                element.isDelete = 1;
            }
        });
    };
    const More = async ()=>{
        if (search.length >= noOfLogo) {
            setnoOfLogo(noOfLogo + 16);
            window.scrollBy(0, 1150);
        }
    };
    const Less = async ()=>{
        if (noOfLogo > 16) {
            setnoOfLogo(noOfLogo - 16);
            window.scrollBy(0, -1550);
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: " container-xxl  container-xl container-lg container-md my-5 pt-4 animate__animated  animate__fadeIn ",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                    className: `my-md-4 mt-md-5 p-2 ${(_styles_mediaN_module_scss__WEBPACK_IMPORTED_MODULE_10___default().service)} d-flex text-center`,
                    children: serviceIcon.map((el, i)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: `text-center ms-3 me-3 ${(_styles_mediaN_module_scss__WEBPACK_IMPORTED_MODULE_10___default().service_Icon_cnt)}`,
                            onClick: ()=>SelectServc(el),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_6___default()), {
                                    width: 50,
                                    height: 45,
                                    className: `${(_styles_mediaN_module_scss__WEBPACK_IMPORTED_MODULE_10___default().service_Icon)} mb-2`,
                                    src: el.value2 == true ? el.srcImgCtSlc : el.srcImgCt,
                                    alt: el.srcImg
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                    "aria-expanded": el.value2,
                                    children: el.label
                                })
                            ]
                        }, i))
                }),
                search.success != false ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                            className: `ms-2 ms-md-0 p-md-2 ps-0 my-3 my-md-2 mb-0  ${(_styles_mediaN_module_scss__WEBPACK_IMPORTED_MODULE_10___default().filter_section)} d-flex media-filter-drop`,
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    className: "media-new-search ",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            className: (_styles_mediaN_module_scss__WEBPACK_IMPORTED_MODULE_10___default().nosubmit),
                                            type: "search",
                                            "aria-describedby": "basic-addon1",
                                            placeholder: "Search Cities",
                                            onChange: (e)=>onChange(e.target.value),
                                            value: value,
                                            // onBlur={() => setFocus(false)}
                                            autoComplete: "off"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: focus ? "dropdown-menu show ms-2 text-dark" : "dropdown-menu ",
                                            children: citys.map((el, i)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    onClick: ()=>onSearch(el.name),
                                                    children: [
                                                        " ",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_5__.MdOutlineLocationOn, {
                                                            className: "icon-clr ",
                                                            id: (_styles_mediaN_module_scss__WEBPACK_IMPORTED_MODULE_10___default().select_location_icon)
                                                        }),
                                                        " ",
                                                        el.name
                                                    ]
                                                }, i))
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_4__.DropdownButton, {
                                    className: "map-filter-drop",
                                    title: filtervalue ? filtervalue : "Illumination type",
                                    id: (_styles_mediaN_module_scss__WEBPACK_IMPORTED_MODULE_10___default().select_media_box),
                                    // onSelect={(e) => setUserType(e)}
                                    drop: "down-centered",
                                    children: ILLUMINATION.map((el, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_4__.Dropdown.Item, {
                                            className: "p-2 mt-0 ",
                                            onClick: (e)=>mediaTypeFilter(el),
                                            children: el
                                        }, i))
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_4__.DropdownButton, {
                                    title: categoryvalue ? categoryvalue : "Category type",
                                    className: "map-filter-drop",
                                    id: (_styles_mediaN_module_scss__WEBPACK_IMPORTED_MODULE_10___default().select_media_box),
                                    // onSelect={(e) => setUserType(e)}
                                    drop: "down-centered",
                                    children: category.map((cate, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_4__.Dropdown.Item, {
                                            className: "p-2 mt-0 ",
                                            onClick: (e)=>categoryFilter(cate),
                                            children: cate.substring(0, 13)
                                        }, i))
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_4__.DropdownButton, {
                                    className: "map-filter-drop",
                                    id: (_styles_mediaN_module_scss__WEBPACK_IMPORTED_MODULE_10___default().select_media_box),
                                    title: ilocationvalue ? ilocationvalue.substring(0, 45) : "Location",
                                    drop: "down-centered",
                                    children: locations.map((el, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_4__.Dropdown.Item, {
                                            className: "p-2 mt-0 ",
                                            onClick: (e)=>locationFilter(el),
                                            children: el
                                        }, i))
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                            className: "my-2 my-md-2 p-2",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_cards__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                slice: slice,
                                addonCart: addonCart,
                                removefromCart: removefromCart
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                            children: slice.length < 16 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: " my-3 text-center",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: " ",
                                        children: [
                                            slice.length !== search.length && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                className: `${(_styles_mediaN_module_scss__WEBPACK_IMPORTED_MODULE_10___default().load_button)} `,
                                                onClick: More,
                                                children: "View More"
                                            }),
                                            slice.length > 16 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                className: `${(_styles_mediaN_module_scss__WEBPACK_IMPORTED_MODULE_10___default().load_button)}  ms-5`,
                                                onClick: Less,
                                                children: "View Less"
                                            })
                                        ]
                                    })
                                })
                            })
                        })
                    ]
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "container ",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: `${(_styles_mediaN_module_scss__WEBPACK_IMPORTED_MODULE_10___default().no_data)} row  text-center my-3`,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_6___default()), {
                            width: 250,
                            height: 250,
                            src: "../../../images/web_pics/no-data.png",
                            alt: "No Data Found",
                            className: ""
                        })
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                    className: "my-2",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Medialogo, {
                            category_name: category_name,
                            city_name: city
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(OverView, {})
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MainUi);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9219:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4041);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_icons_md__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _styles_mediaN_module_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8848);
/* harmony import */ var _styles_mediaN_module_scss__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_styles_mediaN_module_scss__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1111);
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_hi__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_loader__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3974);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_5__);







const Mediacard = ({ slice , addonCart , removefromCart  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: slice.length == 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "container ",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `${(_styles_mediaN_module_scss__WEBPACK_IMPORTED_MODULE_6___default().no_data)} row  text-center my-3`,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_loader__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
            })
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: (_styles_mediaN_module_scss__WEBPACK_IMPORTED_MODULE_6___default().card_media),
            children: slice.map((item, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: `${(_styles_mediaN_module_scss__WEBPACK_IMPORTED_MODULE_6___default().project)}   mt-2  animate__animated  animate__fadeIn`,
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: `${(_styles_mediaN_module_scss__WEBPACK_IMPORTED_MODULE_6___default().img_responsive)} ${(_styles_mediaN_module_scss__WEBPACK_IMPORTED_MODULE_6___default().figure)}  `,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                href: `/seedetails/${item.category_name}/${item.meta_title}`,
                                className: "text-decoration-none",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
                                    width: 200,
                                    height: 200,
                                    className: `${(_styles_mediaN_module_scss__WEBPACK_IMPORTED_MODULE_6___default().img_responsive_media)} rounded_top`,
                                    alt: item.mediaownercompanyname,
                                    src: item.thumb.startsWith("https") ? item.thumb : `https://${item.mediaownercompanyname.trim().split(" ").slice(0, 2).join("_").toLowerCase()}.odoads.com/media/${item.mediaownercompanyname.trim().split(" ").slice(0, 2).join("_").toLowerCase()}/media/images/new${item.thumb}`,
                                    onError: (e)=>e.target.src = "/images/web_pics/alter-img.png"
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("figcaption", {
                                className: "rounded-top",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        href: `/seedetails/${item.category_name}/${item.meta_title}`,
                                        className: "text-decoration-none",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            className: (_styles_mediaN_module_scss__WEBPACK_IMPORTED_MODULE_6___default().project_details),
                                            children: [
                                                item.subcategory,
                                                " at ",
                                                item.medianame.substring(0, 6),
                                                "..."
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: `${(_styles_mediaN_module_scss__WEBPACK_IMPORTED_MODULE_6___default().project_creator)} mt-2 ms-0 `,
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_hi__WEBPACK_IMPORTED_MODULE_3__.HiOutlineCurrencyRupee, {
                                                className: `${(_styles_mediaN_module_scss__WEBPACK_IMPORTED_MODULE_6___default().rupees_logo)} icon-clr`
                                            }),
                                            " ",
                                            "Price ",
                                            "",
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                className: `text-muted `,
                                                children: [
                                                    " ",
                                                    parseInt(item.price * 11 / 10 / 30),
                                                    " "
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: `ms-2 ${(_styles_mediaN_module_scss__WEBPACK_IMPORTED_MODULE_6___default().off_text)}`,
                                                children: " 9% off"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: ` ${(_styles_mediaN_module_scss__WEBPACK_IMPORTED_MODULE_6___default().project_creator)} mt-2 ms-0`,
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_1__.MdLocalOffer, {
                                                className: `${(_styles_mediaN_module_scss__WEBPACK_IMPORTED_MODULE_6___default().offer_logo)} icon-clr`
                                            }),
                                            " ",
                                            "Offer ",
                                            "",
                                            parseInt(item.price / 30)
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: (_styles_mediaN_module_scss__WEBPACK_IMPORTED_MODULE_6___default().project_price),
                                        children: item.isDelete === 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
                                            width: 100,
                                            height: 100,
                                            alt: "check",
                                            src: "/images/web_pics/A-chek.png",
                                            onClick: ()=>removefromCart(item),
                                            className: ` ${(_styles_mediaN_module_scss__WEBPACK_IMPORTED_MODULE_6___default().addonCart)} `
                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
                                            width: 100,
                                            height: 100,
                                            alt: "cart-icon",
                                            src: "/images/web_pics/A-cart.png",
                                            onClick: ()=>addonCart(item),
                                            className: ` ${(_styles_mediaN_module_scss__WEBPACK_IMPORTED_MODULE_6___default().addonCart)} `
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                }, i))
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Mediacard);


/***/ })

};
;