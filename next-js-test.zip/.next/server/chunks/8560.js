exports.id = 8560;
exports.ids = [8560];
exports.modules = {

/***/ 3720:
/***/ ((module) => {

// Exports
module.exports = {
	"media_branding_n": "__404_media_branding_n__oY9Bv",
	"logo_img": "__404_logo_img__c_eN9",
	"go_corner": "__404_go_corner__Fw6mt",
	"go_arrow": "__404_go_arrow__o9V6G",
	"grid_containerN": "__404_grid_containerN__Rd4tP",
	"container": "__404_container__MNLb7",
	"card1": "__404_card1__f1_xr"
};


/***/ }),

/***/ 8560:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_navbar_fixednavbar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6826);
/* harmony import */ var _allApi_apis__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1889);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _styles_404_module_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3720);
/* harmony import */ var _styles_404_module_scss__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_styles_404_module_scss__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_navbar_fixednavbar__WEBPACK_IMPORTED_MODULE_1__, _allApi_apis__WEBPACK_IMPORTED_MODULE_2__]);
([_components_navbar_fixednavbar__WEBPACK_IMPORTED_MODULE_1__, _allApi_apis__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const ErrorPage = ()=>{
    let slice = _allApi_apis__WEBPACK_IMPORTED_MODULE_2__/* .CityNameImage.slice */ .xe.slice(0, 6);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `${(_styles_404_module_scss__WEBPACK_IMPORTED_MODULE_5___default().media_branding_n)} text-center`,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_navbar_fixednavbar__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "d-hide drop-nd"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mt-5 pt-5",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                        src: "/images/web_pics/404.png",
                        alt: "404 img",
                        width: 180,
                        height: 120
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: "mt-2",
                        children: " You've found a page that doesn't exist "
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `${(_styles_404_module_scss__WEBPACK_IMPORTED_MODULE_5___default().grid_containerN)} container-xxl  container-xl text-center container-lg container-md my-5 p`,
                children: slice.map((pos, index)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                        href: `/${pos.value}/delhi`,
                        className: "text-decoration-none",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_styles_404_module_scss__WEBPACK_IMPORTED_MODULE_5___default().container),
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_404_module_scss__WEBPACK_IMPORTED_MODULE_5___default().card1),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_styles_404_module_scss__WEBPACK_IMPORTED_MODULE_5___default().logo_img),
                                        children: pos.icon
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        children: pos.label
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_styles_404_module_scss__WEBPACK_IMPORTED_MODULE_5___default().go_corner),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: (_styles_404_module_scss__WEBPACK_IMPORTED_MODULE_5___default().go_arrow),
                                            children: "→"
                                        })
                                    })
                                ]
                            })
                        })
                    }, index);
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ErrorPage);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;