exports.id = 7530;
exports.ids = [7530];
exports.modules = {

/***/ 7530:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

const catchError = __webpack_require__(7296);
const { executeQuery  } = __webpack_require__(7481);
const redis = __webpack_require__(7773);
const client = redis.createClient();
client.connect();
exports.k = catchError(async (req, res, next)=>{
    const sql = await executeQuery("SELECT DISTINCT name FROM goh_cities", "gohoardi_goh", next);
    if (sql) {
        res.send(sql);
    }
});
exports.N = catchError(async (req, res, next)=>{
    const category_name = req.query.email;
    switch(category_name){
        case "traditional-ooh-media":
            table_name = "goh_media";
            break;
        case "digital-media":
            table_name = "goh_media_digital";
            break;
        case "transit-media":
            table_name = "goh_media_transit";
            break;
        case "mall-media":
            table_name = "goh_media_mall";
            break;
        case "airport-media":
            table_name = "goh_media_airport";
            break;
        case "inflight_media":
            table_name = "goh_media_inflight";
            break;
        case "office-media":
            table_name = "goh_media_office";
            break;
        default:
            table_name = "goh_media";
    }
    const sql = await executeQuery("SELECT DISTINCT meta_title, category_name FROM " + table_name + " WHERE  category_name = '" + category_name + "' &&  meta_title IS NOT NULL", "gohoardi_goh", next);
    if (sql) {
        return res.send(sql);
    }
});


/***/ })

};
;