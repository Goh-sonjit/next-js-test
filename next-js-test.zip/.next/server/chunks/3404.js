"use strict";
exports.id = 3404;
exports.ids = [3404];
exports.modules = {

/***/ 3404:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9816);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _allApi_apis__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1889);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3590);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_allApi_apis__WEBPACK_IMPORTED_MODULE_3__, react_toastify__WEBPACK_IMPORTED_MODULE_4__]);
([_allApi_apis__WEBPACK_IMPORTED_MODULE_3__, react_toastify__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const initalState = {
    company: " ",
    city: " ",
    phone: " ",
    address: " ",
    website: " ",
    state: " ",
    zip_code: " ",
    pan: " ",
    gstin: " "
};
const Companyprofile = ()=>{
    const [stateData, setState] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(initalState);
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]);
    const { company , city , phone , address , website , state , zip_code , pan , gstin  } = stateData;
    const handleChange = async (e)=>{
        setState({
            ...stateData,
            [e.target.name]: e.target.value
        });
    };
    const allData = async ()=>{
        const company = await (0,_allApi_apis__WEBPACK_IMPORTED_MODULE_3__/* .allcompanydata */ .Qt)();
        setData(company);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        allData();
    }, []);
    const getComapnayData = async ()=>{
        const data = await (0,_allApi_apis__WEBPACK_IMPORTED_MODULE_3__/* .companydata */ .Lo)(stateData);
        if (data.sucess == true) {
            (0,react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast)(data.message);
        // window.location.reload();
        } else {
            (0,react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast)(data.message);
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        setState({
            ...data[0]
        });
    }, [
        data
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "jsx-3c385565ea329c9d" + " " + " row p-3",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "jsx-3c385565ea329c9d" + " " + "col-md-12",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "jsx-3c385565ea329c9d" + " " + "form-group my-1",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                for: "company",
                                className: "jsx-3c385565ea329c9d" + " " + "control-label ps-2",
                                children: "Company Name"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                placeholder: "company Name",
                                value: company,
                                onChange: handleChange,
                                type: "text",
                                name: "company",
                                className: "jsx-3c385565ea329c9d" + " " + "form-control"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "jsx-3c385565ea329c9d" + " " + "form-group my-1",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                for: "website",
                                className: "jsx-3c385565ea329c9d" + " " + "control-label ps-2",
                                children: "Website"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                onChange: handleChange,
                                placeholder: "www.org.com",
                                value: website,
                                type: "text",
                                name: "website",
                                id: "website",
                                className: "jsx-3c385565ea329c9d" + " " + "form-control"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        "app-field-wrapper": "custom_fields[customers][10]",
                        className: "jsx-3c385565ea329c9d" + " " + "form-group my-1",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                for: "custom_fields[customers][10]",
                                className: "jsx-3c385565ea329c9d" + " " + "control-label ps-2",
                                children: "PAN"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                placeholder: "PAN",
                                onChange: handleChange,
                                value: pan,
                                type: "text",
                                id: "custom_fields[customers][10]",
                                name: "pan",
                                "data-fieldto": "customers",
                                "data-fieldid": "10",
                                className: "jsx-3c385565ea329c9d" + " " + "form-control"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        "app-field-wrapper": "custom_fields[customers][11]",
                        className: "jsx-3c385565ea329c9d" + " " + "form-group my-1",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                for: "custom_fields[customers][11]",
                                className: "jsx-3c385565ea329c9d" + " " + "control-label ps-2",
                                children: "GSTIN"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                type: "text",
                                id: "custom_fields[customers][11]",
                                name: "gstin",
                                onChange: handleChange,
                                placeholder: "GSTIN",
                                value: gstin,
                                "data-fieldto": "customers",
                                "data-fieldid": "11",
                                className: "jsx-3c385565ea329c9d" + " " + "form-control"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "jsx-3c385565ea329c9d" + " " + "form-group my-1",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                for: "phonenumber",
                                className: "jsx-3c385565ea329c9d" + " " + "control-label ps-2",
                                children: "Phone"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                type: "number",
                                onChange: handleChange,
                                placeholder: "+91 898 9899 898",
                                value: phone,
                                name: "phone",
                                id: "phonenumber",
                                className: "jsx-3c385565ea329c9d" + " " + "form-control"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "jsx-3c385565ea329c9d" + " " + "col-md-4 ",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "jsx-3c385565ea329c9d" + " " + "form-group my-1",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                            for: "city",
                            className: "jsx-3c385565ea329c9d" + " " + "ps-2",
                            children: "City"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            onChange: handleChange,
                            placeholder: "City",
                            value: city,
                            type: "text",
                            name: "city",
                            id: "city",
                            className: "jsx-3c385565ea329c9d" + " " + "form-control"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "jsx-3c385565ea329c9d" + " " + "col-md-4 ",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "jsx-3c385565ea329c9d" + " " + "form-group my-1",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                            for: "state",
                            className: "jsx-3c385565ea329c9d" + " " + "ps-2",
                            children: "State"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            onChange: handleChange,
                            placeholder: "State",
                            value: state,
                            type: "text",
                            name: "state",
                            id: "state",
                            className: "jsx-3c385565ea329c9d" + " " + "form-control"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "jsx-3c385565ea329c9d" + " " + "col-md-4 ",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "jsx-3c385565ea329c9d" + " " + "form-group my-1",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                            for: "zip",
                            className: "jsx-3c385565ea329c9d" + " " + "ps-2",
                            children: "Zip Code"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            placeholder: "124507",
                            onChange: handleChange,
                            value: zip_code,
                            type: "number",
                            name: "zip_code",
                            id: "zip",
                            className: "jsx-3c385565ea329c9d" + " " + "form-control"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "jsx-3c385565ea329c9d" + " " + "form-group my-1",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                        for: "address",
                        className: "jsx-3c385565ea329c9d" + " " + "ps-2",
                        children: "Address"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                        onChange: handleChange,
                        placeholder: "address",
                        value: address,
                        name: "address",
                        id: "address",
                        rows: "3",
                        className: "jsx-3c385565ea329c9d" + " " + "form-control"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "jsx-3c385565ea329c9d" + " " + "col-md-12 ",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "jsx-3c385565ea329c9d" + " " + "form-group my-2 mb-0 text-center  rounded",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        type: "submit",
                        onClick: getComapnayData,
                        className: "jsx-3c385565ea329c9d" + " " + "btn update-btn w-50",
                        children: "Update"
                    })
                })
            }),
            react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default()), {
                id: "3c385565ea329c9d",
                children: ".update-btn.jsx-3c385565ea329c9d{background-color:#393939!important;color:#f0f0f0!important}"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Companyprofile);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;