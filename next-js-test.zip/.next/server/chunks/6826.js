exports.id = 6826;
exports.ids = [6826];
exports.modules = {

/***/ 214:
/***/ ((module) => {

// Exports
module.exports = {
	"navbar_main_floating": "fixedNavbar_navbar_main_floating__BcwIl",
	"home": "fixedNavbar_home__TnXAB",
	"sss": "fixedNavbar_sss____rWO",
	"GiHamburgerMenu": "fixedNavbar_GiHamburgerMenu__qoxtG",
	"float_btn_notalowed": "fixedNavbar_float_btn_notalowed__dLUcS",
	"nav_icon_6": "fixedNavbar_nav_icon_6__xb44a",
	"xyz": "fixedNavbar_xyz__cuUev",
	"border_1": "fixedNavbar_border_1__fZg3_",
	"float_brand": "fixedNavbar_float_brand__Jc8cG",
	"cart": "fixedNavbar_cart__Pohyd",
	"search_button_flotnav": "fixedNavbar_search_button_flotnav__VjUIm",
	"search_logo": "fixedNavbar_search_logo__gJCGF",
	"float_map_btn_id": "fixedNavbar_float_map_btn_id___iXC_",
	"search_location_box": "fixedNavbar_search_location_box__xAT5e",
	"select_media_box": "fixedNavbar_select_media_box__qVwWt",
	"select_media_icon": "fixedNavbar_select_media_icon__tmF2G",
	"float_map_btn": "fixedNavbar_float_map_btn__oSuK2",
	"new_search": "fixedNavbar_new_search__bekjr",
	"drop_togel": "fixedNavbar_drop_togel__Qa3cH"
};


/***/ }),

/***/ 111:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9816);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var cookies_next__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8982);
/* harmony import */ var cookies_next__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(cookies_next__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _allApi_apis__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1889);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_allApi_apis__WEBPACK_IMPORTED_MODULE_6__]);
_allApi_apis__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







const NavbarDropdown = ()=>{
    const route = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const pages = [
        {
            text: "About Us",
            href: "/about-us"
        },
        {
            text: "Team",
            href: "/team"
        },
        {
            text: "News & Media",
            href: "/media-and-news"
        },
        {
            text: "Contact",
            href: "/contact-us"
        },
        {
            text: "Testimonials",
            href: "/testimonial"
        },
        {
            text: "Blogs",
            href: "https://blog.gohoardings.com/",
            taget: "_blank"
        },
        {
            text: "FAQs",
            href: "/faqs"
        }
    ];
    const directlink = (e)=>{
        (0,cookies_next__WEBPACK_IMPORTED_MODULE_5__.setCookie)("category_name", e);
        (0,cookies_next__WEBPACK_IMPORTED_MODULE_5__.setCookie)("city_name", "delhi");
        _allApi_apis__WEBPACK_IMPORTED_MODULE_6__/* .CityNameImage.forEach */ .xe.forEach((el)=>{
            el.value2 = el.value === e ? true : false;
        });
        route.push(`/${e}`);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                id: "de",
                className: "jsx-eda638d679a4900f" + " " + "drop-menu   position-fixed  rounded-0  animate__animated  ",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "jsx-eda638d679a4900f" + " " + "container-xxl  container-xl container-lg container-md  ",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "jsx-eda638d679a4900f" + " " + "row m-1 drop-data",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "jsx-eda638d679a4900f" + " " + "col-3 p-0  border-box mb-3",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                    className: "jsx-eda638d679a4900f" + " " + "list-none ms-2",
                                    children: _allApi_apis__WEBPACK_IMPORTED_MODULE_6__/* .CityNameImage.slice */ .xe.slice(0, 4).map((e, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            onClick: ()=>directlink(e.value),
                                            className: "jsx-eda638d679a4900f" + " " + "button text-light text-nowrap is-small is-info",
                                            children: e.label
                                        }, i))
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "jsx-eda638d679a4900f" + " " + "col-3 p-0 m-0 border-box mb-3",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                    className: "jsx-eda638d679a4900f" + " " + "list-none",
                                    children: _allApi_apis__WEBPACK_IMPORTED_MODULE_6__/* .CityNameImage.slice */ .xe.slice(4).map((e, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            onClick: ()=>directlink(e.value),
                                            className: "jsx-eda638d679a4900f" + " " + "button text-light text-nowrap is-small is-info",
                                            children: e.label
                                        }, i))
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "jsx-eda638d679a4900f" + " " + "col-3 p-0 m-0 border-box mb-3",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                    className: "jsx-eda638d679a4900f" + " " + "list-none",
                                    children: pages.slice(0, 4).map((e, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            className: "jsx-eda638d679a4900f",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                href: e.href,
                                                className: "text-decoration-none text-light",
                                                children: e.text
                                            })
                                        }, i))
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "jsx-eda638d679a4900f" + " " + "col-3 p-0 m-0 mb-3",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                    className: "jsx-eda638d679a4900f" + " " + "list-none",
                                    children: pages.slice(4).map((e, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            className: "jsx-eda638d679a4900f",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                href: e.href,
                                                className: "text-decoration-none text-light",
                                                target: e.taget && e.taget,
                                                children: e.text
                                            })
                                        }, i))
                                })
                            })
                        ]
                    })
                })
            }),
            react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default()), {
                id: "eda638d679a4900f",
                children: '#de.jsx-eda638d679a4900f{background:#212121;opacity:.98!important;opacity:98%!important;width:93%;padding-top:1.4%;-webkit-box-shadow:rgba(0,0,0,.3)0px 19px 38px,rgba(0,0,0,.22)0px 15px 12px;-moz-box-shadow:rgba(0,0,0,.3)0px 19px 38px,rgba(0,0,0,.22)0px 15px 12px;box-shadow:rgba(0,0,0,.3)0px 19px 38px,rgba(0,0,0,.22)0px 15px 12px;border:none}.write.jsx-eda638d679a4900f{height:36px;width:46px}.drop-nd.jsx-eda638d679a4900f{height:1px}.drop-data.jsx-eda638d679a4900f ul.jsx-eda638d679a4900f li.jsx-eda638d679a4900f{color:rgb(103,103,103);width:130px;padding:4px;cursor:pointer;list-style-type:none}.drop-data.jsx-eda638d679a4900f ul.jsx-eda638d679a4900f li.jsx-eda638d679a4900f:after{display:block;content:"";border-bottom:solid 1px white;-webkit-transform:scalex(0);-moz-transform:scalex(0);-ms-transform:scalex(0);-o-transform:scalex(0);transform:scalex(0);-webkit-transition:-webkit-transform 300ms ease-in-out;-moz-transition:-moz-transform 300ms ease-in-out;-o-transition:-o-transform 300ms ease-in-out;transition:-webkit-transform 300ms ease-in-out;transition:-moz-transform 300ms ease-in-out;transition:-o-transform 300ms ease-in-out;transition:transform 300ms ease-in-out}.drop-data.jsx-eda638d679a4900f ul.jsx-eda638d679a4900f li.jsx-eda638d679a4900f:hover:after{-webkit-transform:scalex(1);-moz-transform:scalex(1);-ms-transform:scalex(1);-o-transform:scalex(1);transform:scalex(1)}.border-box.jsx-eda638d679a4900f{border-right:1px solid#c8c9ca}#write-btn.jsx-eda638d679a4900f{-webkit-box-shadow:rgba(0,0,0,.24)0px 3px 8px;-moz-box-shadow:rgba(0,0,0,.24)0px 3px 8px;box-shadow:rgba(0,0,0,.24)0px 3px 8px;opacity:.98;opacity:98%;width:200px;font-size:20px;font-weight:600;cursor:pointer;height:49px;text-align:center;border:none;-webkit-background-size:300%100%;-moz-background-size:300%100%;-o-background-size:300%100%;background-size:300%100%;-webkit-border-radius:0px;-moz-border-radius:0px;border-radius:0px;background-color:#fff212;--moz-transition:all 0.4s ease-in-out;-webkit-transition:all.4s ease-in-out;-moz-transition:all.4s ease-in-out;-o-transition:all.4s ease-in-out;transition:all.4s ease-in-out}'
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NavbarDropdown);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6826:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9816);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_bootstrap_Navbar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4934);
/* harmony import */ var react_bootstrap_Navbar__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Navbar__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_bootstrap_Nav__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2540);
/* harmony import */ var react_bootstrap_Nav__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Nav__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _allApi_apis__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1889);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4041);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_icons_md__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1937);
/* harmony import */ var react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5226);
/* harmony import */ var react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react_bootstrap_InputGroup__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2563);
/* harmony import */ var react_bootstrap_InputGroup__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_InputGroup__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var cookies_next__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8982);
/* harmony import */ var cookies_next__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(cookies_next__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _styles_fixedNavbar_module_scss__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(214);
/* harmony import */ var _styles_fixedNavbar_module_scss__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_styles_fixedNavbar_module_scss__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _dropdown__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(111);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _maintenance__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(9293);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_allApi_apis__WEBPACK_IMPORTED_MODULE_5__, _dropdown__WEBPACK_IMPORTED_MODULE_12__]);
([_allApi_apis__WEBPACK_IMPORTED_MODULE_5__, _dropdown__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/* eslint-disable jsx-a11y/alt-text */ 



















const Userdetail = next_dynamic__WEBPACK_IMPORTED_MODULE_13___default()(null, {
    loadableGenerated: {
        modules: [
            "..\\components\\navbar\\fixednavbar.jsx -> " + "./userdetail"
        ]
    },
    ssr: false
});
const Fixednavbar = ()=>{
    const [city, setCity] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]);
    const [posts, setPosts] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)();
    const [focus, setFocus] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const [value, setValue] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const [userType, setUserType] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const [userPath, setUserPath] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const [showMenu, setShowMenu] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const route = (0,next_router__WEBPACK_IMPORTED_MODULE_15__.useRouter)();
    const { pathname  } = (0,next_router__WEBPACK_IMPORTED_MODULE_15__.useRouter)();
    const getMap = ()=>{
        (0,cookies_next__WEBPACK_IMPORTED_MODULE_11__.removeCookies)("meta_title");
        (0,cookies_next__WEBPACK_IMPORTED_MODULE_11__.removeCookies)("state_name");
        route.push("/map");
    };
    let selecType;
    _allApi_apis__WEBPACK_IMPORTED_MODULE_5__/* .CityNameImage.map */ .xe.map((el)=>{
        if (el.value == userType) {
            selecType = el.label;
        }
    });
    const onChange = async (event)=>{
        setValue(event.target.value);
        const cities = event.target.value;
        const data = await (0,_allApi_apis__WEBPACK_IMPORTED_MODULE_5__/* .getAllCity */ .G4)(cities);
        setCity(data);
    };
    const mavigatetoMediaPage = (userType, value)=>{
        if (pathname === "/map" && userType.length > 3 && value.length > 2) {
            (0,cookies_next__WEBPACK_IMPORTED_MODULE_11__.setCookie)("category_name", userType);
            (0,cookies_next__WEBPACK_IMPORTED_MODULE_11__.removeCookies)("meta_title");
            (0,cookies_next__WEBPACK_IMPORTED_MODULE_11__.removeCookies)("state_name");
            (0,cookies_next__WEBPACK_IMPORTED_MODULE_11__.setCookie)("city_name", value);
            route.push(`/map`);
        } else if (userType.length > 3 && value.length > 2) {
            (0,cookies_next__WEBPACK_IMPORTED_MODULE_11__.setCookie)("category_name", userType);
            (0,cookies_next__WEBPACK_IMPORTED_MODULE_11__.setCookie)("city_name", value);
            _allApi_apis__WEBPACK_IMPORTED_MODULE_5__/* .CityNameImage.forEach */ .xe.forEach((el)=>{
                el.value2 = el.value === userType ? true : false;
            });
            route.push(`/${userType}/${value}`);
        }
    };
    const onSearch = (searchTerm)=>{
        setValue(searchTerm);
        setFocus(false);
    };
    function handleMouseEnter() {
        setShowMenu(true);
    }
    function handleMouseLeave() {
        setShowMenu(false);
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "fixed-top mb-2",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_maintenance__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Navbar__WEBPACK_IMPORTED_MODULE_3___default()), {
                expand: `lg px-md-0 p-1 m-0 border-0 ${(_styles_fixedNavbar_module_scss__WEBPACK_IMPORTED_MODULE_17___default().navbar_main_floating)} mt-4`,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_styles_fixedNavbar_module_scss__WEBPACK_IMPORTED_MODULE_17___default().sss)
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Navbar__WEBPACK_IMPORTED_MODULE_3___default().Brand), {
                        id: (_styles_fixedNavbar_module_scss__WEBPACK_IMPORTED_MODULE_17___default().home),
                        onMouseEnter: handleMouseEnter,
                        onMouseLeave: handleMouseLeave,
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                "aria-expanded": showMenu,
                                className: "jsx-eb951e38055593ef" + " " + `${(_styles_fixedNavbar_module_scss__WEBPACK_IMPORTED_MODULE_17___default().nav_icon_6)} me-3`,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "jsx-eb951e38055593ef"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "jsx-eb951e38055593ef"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "jsx-eb951e38055593ef"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_14___default()), {
                                width: 100,
                                height: 35,
                                alt: "gohoardings",
                                src: "/images/web_pics/logo.png",
                                className: `border-0 brand ${(_styles_fixedNavbar_module_scss__WEBPACK_IMPORTED_MODULE_17___default().float_brand)} ms-2`,
                                onClick: ()=>route.push("/")
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "jsx-eb951e38055593ef" + " " + `dropdown-menu ${showMenu ? "show" : ""} p-0 m-0`,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_dropdown__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {})
                            }),
                            react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default()), {
                                id: "eb951e38055593ef",
                                children: ".dropdown-menu.show.jsx-eb951e38055593ef{display:block}"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Navbar__WEBPACK_IMPORTED_MODULE_3___default().Toggle), {
                        "aria-controls": "basic-navbar-nav",
                        className: "me-3"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Navbar__WEBPACK_IMPORTED_MODULE_3___default().Collapse), {
                        id: (_styles_fixedNavbar_module_scss__WEBPACK_IMPORTED_MODULE_17___default().basic_navbar_nav),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Nav__WEBPACK_IMPORTED_MODULE_4___default()), {
                                className: `navbar-nav mx-auto  ${(_styles_fixedNavbar_module_scss__WEBPACK_IMPORTED_MODULE_17___default().search_inner_drop)} `,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_InputGroup__WEBPACK_IMPORTED_MODULE_10___default()), {
                                        className: " me-3",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_9___default().Control), {
                                            placeholder: "Search your location",
                                            "aria-describedby": "basic-addon1",
                                            autoComplete: "off",
                                            onChange: onChange,
                                            value: value,
                                            onFocus: ()=>setFocus(true),
                                            id: (_styles_fixedNavbar_module_scss__WEBPACK_IMPORTED_MODULE_17___default().search_location_box)
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: focus ? "dropdown-menu border-0 show  mt-5  ms-0" : "dropdown-menu ",
                                        id: (_styles_fixedNavbar_module_scss__WEBPACK_IMPORTED_MODULE_17___default().xyz),
                                        children: city.map((item, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: `${(_styles_fixedNavbar_module_scss__WEBPACK_IMPORTED_MODULE_17___default().border_1)} rounded-3`,
                                                onClick: ()=>onSearch(item.name),
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                    value: item.name,
                                                    className: " text-light mt-1 ps-3 ",
                                                    children: item.name
                                                })
                                            }, i))
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "p-0 m-0 fnav ms-3",
                                        onFocus: ()=>setFocus(false),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_6__.DropdownButton, {
                                            title: userType ? selecType : "Select your media type",
                                            id: (_styles_fixedNavbar_module_scss__WEBPACK_IMPORTED_MODULE_17___default().select_media_box),
                                            onSelect: (e)=>setUserType(e),
                                            children: _allApi_apis__WEBPACK_IMPORTED_MODULE_5__/* .CityNameImage.map */ .xe.map((el, i)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_6__.Dropdown.Item, {
                                                    eventKey: el.value,
                                                    className: "p-2 mt-0 text-light",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                            className: `${(_styles_fixedNavbar_module_scss__WEBPACK_IMPORTED_MODULE_17___default().select_media_icon)} text-light`,
                                                            children: [
                                                                " ",
                                                                el.icon,
                                                                " "
                                                            ]
                                                        }),
                                                        el.label
                                                    ]
                                                }, i))
                                        })
                                    }),
                                    userType && value ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_8___default()), {
                                        className: "ms-3",
                                        onClick: (a, b)=>mavigatetoMediaPage(userType, value),
                                        id: (_styles_fixedNavbar_module_scss__WEBPACK_IMPORTED_MODULE_17___default().search_button_flotnav),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_7__.MdOutlineSearch, {
                                            className: `${(_styles_fixedNavbar_module_scss__WEBPACK_IMPORTED_MODULE_17___default().search_logo)} icon-clr`
                                        })
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_8___default()), {
                                        className: `ms-3 ${(_styles_fixedNavbar_module_scss__WEBPACK_IMPORTED_MODULE_17___default().float_btn_notalowed)}`,
                                        id: (_styles_fixedNavbar_module_scss__WEBPACK_IMPORTED_MODULE_17___default().search_button_flotnav),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_7__.MdOutlineSearch, {
                                            className: `${(_styles_fixedNavbar_module_scss__WEBPACK_IMPORTED_MODULE_17___default().search_logo)} icon-clr ${(_styles_fixedNavbar_module_scss__WEBPACK_IMPORTED_MODULE_17___default().float_btn_notalowed)}`
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                                className: "  text-center me-3",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Nav__WEBPACK_IMPORTED_MODULE_4___default().Link), {
                                    className: `${(_styles_fixedNavbar_module_scss__WEBPACK_IMPORTED_MODULE_17___default().mapLink)} ${(_styles_fixedNavbar_module_scss__WEBPACK_IMPORTED_MODULE_17___default().float_map_btn)}   p-0 rounded-pill pt-1`,
                                    onClick: getMap,
                                    children: [
                                        "Map",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_7__.MdLocationPin, {
                                            className: `${(_styles_fixedNavbar_module_scss__WEBPACK_IMPORTED_MODULE_17___default().GiHamburgerMenu)} ps-0 p-0  ms-0`
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                                className: "text-center",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Userdetail, {})
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_styles_fixedNavbar_module_scss__WEBPACK_IMPORTED_MODULE_17___default().sss)
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Fixednavbar);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;