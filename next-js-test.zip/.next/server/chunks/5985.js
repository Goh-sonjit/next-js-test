exports.id = 5985;
exports.ids = [5985];
exports.modules = {

/***/ 8522:
/***/ ((module) => {

// Exports
module.exports = {
	"sendf": "login_sendf__e9XuM",
	"noget": "login_noget__ZNLRh",
	"mnd": "login_mnd__xmGXv",
	"wrapper": "login_wrapper__yLrLw",
	"opacitydiv": "login_opacitydiv__WLaGh",
	"title": "login_title___iWid",
	"img_responsive": "login_img_responsive__wiVw_",
	"img_responsive2": "login_img_responsive2__b_0ep",
	"login_container2": "login_login_container2__S7TTD",
	"brand_logo": "login_brand_logo__0Xhn0",
	"switch": "login_switch__WIpUo",
	"forgetpass": "login_forgetpass__22_Vt",
	"psaa": "login_psaa__ibQsr",
	"login_auth": "login_login_auth__Mmmra",
	"google_icon": "login_google_icon__3lpHv",
	"linkdin_icon": "login_linkdin_icon__OXDcw",
	"otp_icon": "login_otp_icon__0ZdLs"
};


/***/ }),

/***/ 5985:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_fc__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(178);
/* harmony import */ var react_icons_fc__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_fc__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _styles_login_module_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8522);
/* harmony import */ var _styles_login_module_scss__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_styles_login_module_scss__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_4__);






const LoginOauth = ({ googleSignIn , afterLogin , setWithOtp , withOtp , success  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: `ps-0 mt-3 text-center ${(_styles_login_module_scss__WEBPACK_IMPORTED_MODULE_5___default().login_auth)} mt-2`,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "row"
                }),
                withOtp ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                    width: 500,
                    height: 500,
                    alt: "phone_otp",
                    src: "/images/web_pics/gpmpas.png",
                    className: `${(_styles_login_module_scss__WEBPACK_IMPORTED_MODULE_5___default().otp_icon)} offset-1`,
                    onClick: ()=>setWithOtp(!withOtp)
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                    width: 500,
                    height: 500,
                    alt: "phone_otp",
                    src: "/images/web_pics/otp.png",
                    className: `${(_styles_login_module_scss__WEBPACK_IMPORTED_MODULE_5___default().otp_icon)} offset-1`,
                    onClick: ()=>setWithOtp(!withOtp)
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                    width: 500,
                    height: 500,
                    alt: "linkdin",
                    src: "/images/web_pics/linkdin.png",
                    className: `${(_styles_login_module_scss__WEBPACK_IMPORTED_MODULE_5___default().linkdin_icon)} offset-1`,
                    onClick: ()=>(0,next_auth_react__WEBPACK_IMPORTED_MODULE_2__.signIn)()
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fc__WEBPACK_IMPORTED_MODULE_3__.FcGoogle, {
                    className: `${(_styles_login_module_scss__WEBPACK_IMPORTED_MODULE_5___default().google_icon)} offset-1`,
                    onClick: googleSignIn
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LoginOauth);


/***/ })

};
;