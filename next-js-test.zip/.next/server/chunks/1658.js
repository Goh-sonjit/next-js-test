exports.id = 1658;
exports.ids = [1658];
exports.modules = {

/***/ 4301:
/***/ ((module) => {

// Exports
module.exports = {
	"service_content": "ourServices_service_content__BzKPC",
	"service_card": "ourServices_service_card__HKXSw",
	"service_card_img": "ourServices_service_card_img__cFIwy",
	"add_container": "ourServices_add_container__EJMPz",
	"celebration_logo": "ourServices_celebration_logo__TmLy_",
	"search_btn": "ourServices_search_btn__G9UQ0",
	"View-Detail": "ourServices_View-Detail__gUaRa",
	"slick-prev": "ourServices_slick-prev__cTQlm",
	"slick-next": "ourServices_slick-next__cmLxq"
};


/***/ }),

/***/ 1658:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _allApi_apis__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1889);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8096);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var cookies_next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8982);
/* harmony import */ var cookies_next__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(cookies_next__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _styles_ourServices_module_scss__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4301);
/* harmony import */ var _styles_ourServices_module_scss__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_styles_ourServices_module_scss__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1111);
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_hi__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_allApi_apis__WEBPACK_IMPORTED_MODULE_2__]);
_allApi_apis__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];









const Ourservices = ()=>{
    const directlink = (e)=>{
        _allApi_apis__WEBPACK_IMPORTED_MODULE_2__/* .CityNameImage.forEach */ .xe.forEach((el)=>{
            el.value2 = el.value === e.value ? true : false;
        });
        (0,cookies_next__WEBPACK_IMPORTED_MODULE_4__.setCookie)("category_name", e.value);
        (0,cookies_next__WEBPACK_IMPORTED_MODULE_4__.setCookie)("categorytag", e.label);
    };
    const directlinkget = ()=>{
        (0,cookies_next__WEBPACK_IMPORTED_MODULE_4__.setCookie)("category_name", "traditional-ooh-media");
        (0,cookies_next__WEBPACK_IMPORTED_MODULE_4__.setCookie)("city_name", "delhi");
    };
    {
        var settings = {
            dots: false,
            infinite: true,
            speed: 500,
            slidesToShow: 3,
            slidesToScroll: 1,
            initialSlide: 0,
            autoplay: true,
            pauseOnHover: true,
            responsive: [
                {
                    breakpoint: 800,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1,
                        initialSlide: 0
                    }
                },
                {
                    breakpoint: 425,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1,
                        initialSlide: 0
                    }
                }
            ]
        };
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: `${(_styles_ourServices_module_scss__WEBPACK_IMPORTED_MODULE_8___default().service_content)} container-xxl  container-xl container-lg container-md  pt-md-5 pb-md-5 servc`,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                    children: "Our Services"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h6", {
                    className: "pt-1",
                    children: [
                        "Choose from below to deliver advertisements in a truly ",
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                        "exciting, innovative and creative way."
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_slick__WEBPACK_IMPORTED_MODULE_3___default()), {
                        ...settings,
                        children: _allApi_apis__WEBPACK_IMPORTED_MODULE_2__/* .CityNameImage.map */ .xe.map((pos, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "container pt-4 ",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: `row bg-light rounded-2 ${(_styles_ourServices_module_scss__WEBPACK_IMPORTED_MODULE_8___default().service_card)} me-2 ms-2 "`,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "col p-3 ",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                width: 100,
                                                height: 100,
                                                alt: pos.srcImg,
                                                src: pos.srcImg,
                                                className: `rounded-2 ${(_styles_ourServices_module_scss__WEBPACK_IMPORTED_MODULE_8___default().service_card_img)}`
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "col p-3 ps-0 position-relative",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                    className: "position-absolute  ps-0 fw-bold",
                                                    children: pos.label
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                    href: `/${pos.value}`,
                                                    className: "text-decoration-none",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                        className: `position-absolute bottom-0  pb-3  mb-0 text-muted w-100 ${(_styles_ourServices_module_scss__WEBPACK_IMPORTED_MODULE_8___default().View_Detail)}`,
                                                        onClick: ()=>directlink(pos),
                                                        children: [
                                                            " ",
                                                            "View Detail",
                                                            " ",
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_hi__WEBPACK_IMPORTED_MODULE_5__.HiOutlineArrowNarrowRight, {
                                                                className: `ms-3 ms-md-1 ${(_styles_ourServices_module_scss__WEBPACK_IMPORTED_MODULE_8___default().icon_clr)}`
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }, i))
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "container-fluid  m-0 ",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: `row mx-auto ${(_styles_ourServices_module_scss__WEBPACK_IMPORTED_MODULE_8___default().add_container)} text-center`,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-3",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_7___default()), {
                                        width: 100,
                                        height: 100,
                                        src: "/images/web_pics/celebration.png",
                                        className: (_styles_ourServices_module_scss__WEBPACK_IMPORTED_MODULE_8___default().celebration_logo),
                                        alt: "celebration"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-6",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                className: "mb-0 mb-md-1",
                                                children: "Get Your First Ad!"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                className: "pt-1",
                                                children: "Boost your business with a free advertisement!*"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-3",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: `${(_styles_ourServices_module_scss__WEBPACK_IMPORTED_MODULE_8___default().button_serch)} text-white rounded-pill`,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_6___default()), {
                                            href: "/traditional-ooh-media-advertising",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                className: (_styles_ourServices_module_scss__WEBPACK_IMPORTED_MODULE_8___default().search_btn),
                                                onClick: directlinkget,
                                                children: "Get it Now"
                                            })
                                        })
                                    })
                                })
                            ]
                        })
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Ourservices);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;