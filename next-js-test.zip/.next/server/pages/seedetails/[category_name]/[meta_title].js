"use strict";
(() => {
var exports = {};
exports.id = 2602;
exports.ids = [2602,2197,9371,9246,9662,4670];
exports.modules = {

/***/ 3974:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9816);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);



function Loader() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "jsx-8fb85bf949523d78" + " " + "loading-container text-center",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                width: 100,
                height: 250,
                src: "/images/web_pics/loading.gif",
                className: "loading"
            }),
            react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default()), {
                id: "8fb85bf949523d78",
                children: ".loading.jsx-8fb85bf949523d78{height:200px!important;width:auto}"
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Loader);


/***/ }),

/***/ 8796:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9816);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _allApi_apicontext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3484);
/* harmony import */ var _allApi_apis__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1889);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4041);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_md__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3590);
/* harmony import */ var _allApi_axios__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3379);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _components_navbar_fixednavbar__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6826);
/* harmony import */ var react_responsive_carousel__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4508);
/* harmony import */ var react_responsive_carousel__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_responsive_carousel__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _components_loader__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3974);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var cookies_next__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8982);
/* harmony import */ var cookies_next__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(cookies_next__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_14__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_allApi_apicontext__WEBPACK_IMPORTED_MODULE_3__, _allApi_apis__WEBPACK_IMPORTED_MODULE_4__, react_toastify__WEBPACK_IMPORTED_MODULE_6__, _allApi_axios__WEBPACK_IMPORTED_MODULE_7__, _components_navbar_fixednavbar__WEBPACK_IMPORTED_MODULE_9__]);
([_allApi_apicontext__WEBPACK_IMPORTED_MODULE_3__, _allApi_apis__WEBPACK_IMPORTED_MODULE_4__, react_toastify__WEBPACK_IMPORTED_MODULE_6__, _allApi_axios__WEBPACK_IMPORTED_MODULE_7__, _components_navbar_fixednavbar__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
















const Details = (props)=>{
    const Canonicaltag = props.currentPageUrl;
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_12__.useRouter)();
    const { category_name , meta_title  } = router.query;
    const { addRemove  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(_allApi_apicontext__WEBPACK_IMPORTED_MODULE_3__/* .AccountContext */ .w0);
    const { handleShow  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(_allApi_apicontext__WEBPACK_IMPORTED_MODULE_3__/* .AccountContext */ .w0);
    const [markers, setPosts] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]);
    const [name, setName] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const [phone, setNumber] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const [email, setEmail] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const [message, setMessage] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const [error, setEror] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    let count = 0;
    const onSubmit = async (e)=>{
        e.preventDefault();
        if (name === "") {
            setEror(true);
            count = +1;
        } else if (phone.length !== 10) {
            count = +1;
            setEror(true);
        } else if (!_allApi_apis__WEBPACK_IMPORTED_MODULE_4__/* .emailformate.test */ .mX.test(email)) {
            count = +1;
            setEror(true);
        } else if (message === "") {
            count = +1;
            setEror(true);
        } else if (count === 0) {
            const data = await (0,_allApi_apis__WEBPACK_IMPORTED_MODULE_4__/* .enquiryApi */ .CL)(name, email, phone, message);
            if (data.success == true) {
                setName("");
                setNumber("");
                setEmail("");
                setMessage("");
                setEror(false);
                (0,react_toastify__WEBPACK_IMPORTED_MODULE_6__.toast)("Our team will contact you soon");
            }
        }
    };
    const mapData = async (meta)=>{
        (0,cookies_next__WEBPACK_IMPORTED_MODULE_13__.setCookie)("meta_title", meta);
        router.push("/map");
    };
    const getMedia = async ()=>{
        if (category_name && meta_title) {
            const { data  } = await _allApi_axios__WEBPACK_IMPORTED_MODULE_7__/* ["default"].post */ .Z.post("seedetails", {
                meta_title: meta_title,
                category_name: category_name
            });
            setPosts(data);
        }
    };
    const addonCart = async (e)=>{
        const data = await (0,_allApi_apis__WEBPACK_IMPORTED_MODULE_4__/* .addItem */ .jX)(e.code, e.category_name);
        if (data.message === "Login First") {
            handleShow();
        } else {
            addRemove({
                type: "INCR"
            });
            add(e);
        }
    };
    const removefroCart = async (obj)=>{
        const data = await (0,_allApi_apis__WEBPACK_IMPORTED_MODULE_4__/* .removeItem */ .cl)(obj.code);
        if (data.message == "Done") {
            addRemove({
                type: "DECR"
            });
            remove(obj);
        }
    };
    const add = (event)=>{
        let data = [
            ...markers
        ];
        data.forEach((element)=>{
            if (element.code == event.code) {
                element.isDelete = 0;
            }
            setPosts(data);
        });
    };
    const remove = (event)=>{
        let data = [
            ...markers
        ];
        data.forEach((element)=>{
            if (element.code == event.code) {
                element.isDelete = 1;
            }
            setPosts(data);
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        getMedia();
    }, [
        category_name,
        meta_title
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_navbar_fixednavbar__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {}),
            markers == 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "jsx-ae9d04ff6a70b9eb" + " " + " container-xxl  container-xl container-lg container-md",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "jsx-ae9d04ff6a70b9eb" + " " + "row  text-center my-5",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_loader__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {})
                    })
                })
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: markers.map((item, i)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_8___default()), {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                                        rel: "canonical",
                                        href: `https://www.gohoardings.com${Canonicaltag}`,
                                        className: "jsx-ae9d04ff6a70b9eb"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                                        className: "jsx-ae9d04ff6a70b9eb",
                                        children: item.page_title
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                                        charSet: "utf-8",
                                        className: "jsx-ae9d04ff6a70b9eb"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                                        name: "viewport",
                                        content: "width=device-width, initial-scale=1",
                                        className: "jsx-ae9d04ff6a70b9eb"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                                        name: "theme-color",
                                        content: "#000000",
                                        className: "jsx-ae9d04ff6a70b9eb"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                                        name: "description",
                                        content: item.meta_descriptions,
                                        className: "jsx-ae9d04ff6a70b9eb"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                                        name: "google-site-verification",
                                        content: "fLT70DRZGdH5FUdrS8w1k2Zg_VTzNJGDF9ie9v4FAzM",
                                        className: "jsx-ae9d04ff6a70b9eb"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                                        name: "keywords",
                                        content: item.meta_keywords,
                                        className: "jsx-ae9d04ff6a70b9eb"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "jsx-ae9d04ff6a70b9eb" + " " + "container-xxl  container-xl container-lg container-md detail-container animate__animated  animate__fadeIn",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h6", {
                                        className: "jsx-ae9d04ff6a70b9eb",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                onClick: ()=>router.push("/"),
                                                className: "jsx-ae9d04ff6a70b9eb" + " " + "bredcamp",
                                                children: "Home"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_5__.MdKeyboardArrowRight, {}),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                onClick: ()=>router.push("/traditional-ooh-media"),
                                                className: "jsx-ae9d04ff6a70b9eb" + " " + "bredcamp",
                                                children: "Medias"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_5__.MdKeyboardArrowRight, {}),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "jsx-ae9d04ff6a70b9eb" + " " + "bredcamp text-secondary",
                                                children: "Details"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "jsx-ae9d04ff6a70b9eb" + " " + "row mt-3 mt-md-5 ms-md-3 me-md-3 ms-0 me-0 detail-mg p-1 p-md-3 rounded-3",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "jsx-ae9d04ff6a70b9eb" + " " + "col-md-6 p-0",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_responsive_carousel__WEBPACK_IMPORTED_MODULE_10__.Carousel, {
                                                    showThumbs: false,
                                                    infiniteLoop: true,
                                                    children: item.thumbnail.split(",").map((element, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "jsx-ae9d04ff6a70b9eb",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_14___default()), {
                                                                width: 420,
                                                                height: 390,
                                                                alt: item.mediaownercompanyname,
                                                                src: element.startsWith("https") ? element : `https://${item.mediaownercompanyname.trim().split(" ").slice(0, 2).join("_").toLowerCase()}.odoads.com/media/${item.mediaownercompanyname.trim().split(" ").slice(0, 2).join("_").toLowerCase()}/media/images/new${element}`,
                                                                onError: (e)=>e.target.src = "/images/web_pics/alter-img.png",
                                                                className: "rounded-3 detail-img"
                                                            })
                                                        }, i))
                                                })
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "jsx-ae9d04ff6a70b9eb" + " " + "col-md-6 p-2 p-md-3  ps-md-4 rounded-3 text-dark",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h5", {
                                                        className: "jsx-ae9d04ff6a70b9eb" + " " + " text-uppercase",
                                                        children: [
                                                            " ",
                                                            item.subcategory
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                        className: "jsx-ae9d04ff6a70b9eb",
                                                        children: item.medianame
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                        className: "jsx-ae9d04ff6a70b9eb",
                                                        children: [
                                                            "Code : ",
                                                            item.code
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "jsx-ae9d04ff6a70b9eb" + " " + "row my-3",
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "jsx-ae9d04ff6a70b9eb" + " " + "col-4",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                                        className: "jsx-ae9d04ff6a70b9eb",
                                                                        children: "Media"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                                        className: "jsx-ae9d04ff6a70b9eb" + " " + "fw-bold",
                                                                        children: item.subcategory
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "jsx-ae9d04ff6a70b9eb" + " " + "col-4 ",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                                        className: "jsx-ae9d04ff6a70b9eb",
                                                                        children: "Size"
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h6", {
                                                                        className: "jsx-ae9d04ff6a70b9eb" + " " + "fw-bold",
                                                                        children: [
                                                                            item.height,
                                                                            "x",
                                                                            item.width,
                                                                            " ",
                                                                            item.widthunit
                                                                        ]
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "jsx-ae9d04ff6a70b9eb" + " " + "col-4",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                                        className: "jsx-ae9d04ff6a70b9eb",
                                                                        children: "Illumination"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                                        className: "jsx-ae9d04ff6a70b9eb" + " " + "fw-bold",
                                                                        children: item.illumination ? item.illumination : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                            className: "jsx-ae9d04ff6a70b9eb" + " " + "text-muted",
                                                                            children: "No Data"
                                                                        })
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "jsx-ae9d04ff6a70b9eb" + " " + "row my-2",
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "jsx-ae9d04ff6a70b9eb" + " " + "col-8",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                                        className: "jsx-ae9d04ff6a70b9eb",
                                                                        children: "FTF"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                                        className: "jsx-ae9d04ff6a70b9eb" + " " + "fw-bold",
                                                                        children: item.location
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "jsx-ae9d04ff6a70b9eb" + " " + "col-4",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                                        className: "jsx-ae9d04ff6a70b9eb",
                                                                        children: "Total Area"
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h6", {
                                                                        className: "jsx-ae9d04ff6a70b9eb" + " " + "fw-bold",
                                                                        children: [
                                                                            item.height * item.width,
                                                                            " Sq. Ft.",
                                                                            " "
                                                                        ]
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                        className: "jsx-ae9d04ff6a70b9eb",
                                                        children: [
                                                            "The hoarding is placed in prime loaction. It is visible from all the ",
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {
                                                                className: "jsx-ae9d04ff6a70b9eb"
                                                            }),
                                                            "crossing roads covering maximum views."
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "jsx-ae9d04ff6a70b9eb" + " " + "row p-0",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "jsx-ae9d04ff6a70b9eb" + " " + " col-6 position-relative",
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                    className: "jsx-ae9d04ff6a70b9eb" + " " + "bottom-0 position-absolute view",
                                                                    children: [
                                                                        "Price: ",
                                                                        parseInt(item.price / 30)
                                                                    ]
                                                                })
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "jsx-ae9d04ff6a70b9eb" + " " + "col-2",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    onClick: (element)=>mapData(item.meta_title),
                                                                    className: "jsx-ae9d04ff6a70b9eb" + " " + "location p-2 text-center rounded",
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_5__.MdLocationPin, {
                                                                        className: "icon-clr me-4 me-md-0 mt-1 mt-md-0",
                                                                        id: "detail-map-location"
                                                                    })
                                                                })
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                id: "detail-Map",
                                                                className: "jsx-ae9d04ff6a70b9eb" + " " + "col-4",
                                                                children: item.isDelete === 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    onClick: ()=>removefroCart(item),
                                                                    className: "jsx-ae9d04ff6a70b9eb" + " " + "cart-btn text-center p-2 rounded me-2",
                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h6", {
                                                                        className: "jsx-ae9d04ff6a70b9eb" + " " + " mt-2 fw-bold ",
                                                                        children: [
                                                                            " ",
                                                                            "Remove"
                                                                        ]
                                                                    })
                                                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    onClick: ()=>addonCart(item),
                                                                    className: "jsx-ae9d04ff6a70b9eb" + " " + "cart-btn text-center p-2 rounded me-2",
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                                        className: "jsx-ae9d04ff6a70b9eb" + " " + "fw-bold mt-2",
                                                                        children: "Add to Cart"
                                                                    })
                                                                })
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "jsx-ae9d04ff6a70b9eb" + " " + "py-4 py-md-5 ",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h3", {
                                                className: "jsx-ae9d04ff6a70b9eb" + " " + "ms-md-3  ms-1 fw-bold",
                                                children: [
                                                    "Media Location:",
                                                    " ",
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                        className: "jsx-ae9d04ff6a70b9eb" + " " + "text-muted fw-normal",
                                                        children: [
                                                            item.location,
                                                            " "
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "jsx-ae9d04ff6a70b9eb" + " " + "detail-map ms-md-3 me-md-3 ms-0 me-0 p-1 p-md-3 rounded-3",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("iframe", {
                                                    src: "https://maps.google.com/maps?q=" + item.latitude + "," + item.longitude + "&t=&z=15&ie=UTF8&iwloc=&output=embed",
                                                    allowFullScreen: true,
                                                    loading: "lazy",
                                                    title: "google-map",
                                                    className: "jsx-ae9d04ff6a70b9eb" + " " + "map_sectionD rounded"
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "jsx-ae9d04ff6a70b9eb" + " " + "detail-form p-3 rounded-3 my-md-5 my-4",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                    className: "jsx-ae9d04ff6a70b9eb" + " " + "txt-clr-tlk fw-bold",
                                                    children: "Get a Free Consultation!"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                                    className: "jsx-ae9d04ff6a70b9eb" + " " + "txt-clr",
                                                    children: "*Please fill all the details."
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                                    onSubmit: onSubmit,
                                                    className: "jsx-ae9d04ff6a70b9eb" + " " + 'mt-4 "position-relative',
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "jsx-ae9d04ff6a70b9eb" + " " + "form-group py-3 ",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                    htmlFor: "formGroupExampleInput",
                                                                    className: "jsx-ae9d04ff6a70b9eb",
                                                                    children: "Name*"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    autoComplete: "off",
                                                                    type: "text",
                                                                    id: "formGroupExampleInput",
                                                                    placeholder: "Your Full Name",
                                                                    value: name,
                                                                    onChange: (e)=>{
                                                                        setName(e.target.value);
                                                                    },
                                                                    className: "jsx-ae9d04ff6a70b9eb" + " " + "form-control ps-0 rounded-0"
                                                                }),
                                                                error == true && name === "" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                                                                    className: "jsx-ae9d04ff6a70b9eb" + " " + "p-0 text-danger text-small ",
                                                                    children: "Please enter your name"
                                                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: " "
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "jsx-ae9d04ff6a70b9eb" + " " + "row py-3",
                                                            children: [
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                    className: "jsx-ae9d04ff6a70b9eb" + " " + "col",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                            htmlFor: "Last-name",
                                                                            className: "jsx-ae9d04ff6a70b9eb",
                                                                            children: "Email*"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                            autoComplete: "off",
                                                                            type: "text",
                                                                            placeholder: "Your Mail ID",
                                                                            id: "first-name",
                                                                            value: email,
                                                                            onChange: (e)=>{
                                                                                setEmail(e.target.value);
                                                                            },
                                                                            className: "jsx-ae9d04ff6a70b9eb" + " " + "form-control ps-0 rounded-0"
                                                                        }),
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                                            className: "jsx-ae9d04ff6a70b9eb" + " " + "error-msg",
                                                                            children: [
                                                                                " ",
                                                                                error == true && !_allApi_apis__WEBPACK_IMPORTED_MODULE_4__/* .emailformate.test */ .mX.test(email) ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                                                                                    className: "jsx-ae9d04ff6a70b9eb" + " " + "p-0 p-0 text-danger text-small  ",
                                                                                    children: "Type your email corectly"
                                                                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                                    children: " "
                                                                                }),
                                                                                " "
                                                                            ]
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                    className: "jsx-ae9d04ff6a70b9eb" + " " + "col",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                            htmlFor: "Last-name",
                                                                            className: "jsx-ae9d04ff6a70b9eb",
                                                                            children: "Phone phone*"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                            autoComplete: "off",
                                                                            type: "phone",
                                                                            placeholder: "+1 012 3456 789",
                                                                            id: "+1 012 3456 789",
                                                                            value: phone,
                                                                            onChange: (e)=>setNumber(e.target.value),
                                                                            className: "jsx-ae9d04ff6a70b9eb" + " " + "form-control ps-0 rounded-0"
                                                                        }),
                                                                        error == true && phone.length !== 10 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                                                                            className: "jsx-ae9d04ff6a70b9eb" + " " + "p-0 text-danger text-small  ",
                                                                            children: "Type your 10 digit phone corectly"
                                                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                            children: " "
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "jsx-ae9d04ff6a70b9eb" + " " + "form-group py-3",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                    htmlFor: "formGroupExampleInput2",
                                                                    className: "jsx-ae9d04ff6a70b9eb",
                                                                    children: "Message*"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    autoComplete: "off",
                                                                    type: "text",
                                                                    id: "formGroupExampleInput2",
                                                                    placeholder: "Write your message..",
                                                                    value: message,
                                                                    onChange: (e)=>{
                                                                        setMessage(e.target.value);
                                                                    },
                                                                    className: "jsx-ae9d04ff6a70b9eb" + " " + "form-control ps-0 rounded-0"
                                                                }),
                                                                error == true && message === "" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                                                                    className: "jsx-ae9d04ff6a70b9eb" + " " + "p-0 text-danger text-small  p-0 ",
                                                                    children: "Please enter your message for our team"
                                                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                    children: " "
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "jsx-ae9d04ff6a70b9eb" + " " + " p-0 m-0  pb-5",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                    type: "submit",
                                                                    role: "button",
                                                                    className: "jsx-ae9d04ff6a70b9eb" + " " + "btn btn-lg  message-btn  float-end",
                                                                    children: "Send Message"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_toastify__WEBPACK_IMPORTED_MODULE_6__.ToastContainer, {})
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    })
                                ]
                            }, i)
                        ]
                    }))
            }),
            react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default()), {
                id: "ae9d04ff6a70b9eb",
                children: ".detail-container.jsx-ae9d04ff6a70b9eb{margin-top:9%}h2.jsx-ae9d04ff6a70b9eb{font-size:2.1rem}h3.jsx-ae9d04ff6a70b9eb{color:#4f4a4c;font-size:1.7rem}h5.jsx-ae9d04ff6a70b9eb{font-size:1.1rem;color:#4f4a4c}h6.jsx-ae9d04ff6a70b9eb{color:#373435;font-size:1rem}p.jsx-ae9d04ff6a70b9eb,span.jsx-ae9d04ff6a70b9eb{color:#373435}.detail-mg.jsx-ae9d04ff6a70b9eb{background-color:#fdfdfd;-webkit-box-shadow:rgba(98,98,105,.2)0px 7px 29px 0px;-moz-box-shadow:rgba(98,98,105,.2)0px 7px 29px 0px;box-shadow:rgba(98,98,105,.2)0px 7px 29px 0px}.detail-img.jsx-ae9d04ff6a70b9eb{height:390px;width:605px!important}.view.jsx-ae9d04ff6a70b9eb{cursor:pointer;font-weight:bold}.view.jsx-ae9d04ff6a70b9eb:hover{color:black}.location.jsx-ae9d04ff6a70b9eb{background-color:#e8e8e8;cursor:pointer}.cart-btn.jsx-ae9d04ff6a70b9eb{background-color:#fff212;cursor:pointer;color:#3d3933}.detail-map.jsx-ae9d04ff6a70b9eb{background-color:#fdfdfd;-webkit-box-shadow:rgba(98,98,105,.2)0px 7px 29px 0px;-moz-box-shadow:rgba(98,98,105,.2)0px 7px 29px 0px;box-shadow:rgba(98,98,105,.2)0px 7px 29px 0px}.map_sectionD.jsx-ae9d04ff6a70b9eb{height:60vh;width:100%}.detail-form.jsx-ae9d04ff6a70b9eb{background-color:#fdfdfd;-webkit-box-shadow:rgba(98,98,105,.2)0px 7px 29px 0px;-moz-box-shadow:rgba(98,98,105,.2)0px 7px 29px 0px;box-shadow:rgba(98,98,105,.2)0px 7px 29px 0px}.txt-clr-tlk.jsx-ae9d04ff6a70b9eb{color:#373435;font-size:2.2rem}.txt-clr.jsx-ae9d04ff6a70b9eb{color:#373435}.form-control.jsx-ae9d04ff6a70b9eb{border:none!important;border-bottom:1px solid#b5b4b4!important}label.jsx-ae9d04ff6a70b9eb{color:#6c757d!important;font-size:.9rem}.message-btn.jsx-ae9d04ff6a70b9eb{background-color:#373435;color:rgb(237,237,237);font-size:1rem;-webkit-border-radius:4px!important;-moz-border-radius:4px!important;border-radius:4px!important}.message-btn.jsx-ae9d04ff6a70b9eb:hover{background-color:#4a494a;color:rgb(237,237,237)}@media screen and (max-width:1366px){h2.jsx-ae9d04ff6a70b9eb{font-size:1.9rem}h3.jsx-ae9d04ff6a70b9eb{color:#4f4a4c;font-size:1.5rem}h5.jsx-ae9d04ff6a70b9eb{font-size:1rem;color:#4f4a4c}h6.jsx-ae9d04ff6a70b9eb{color:#373435;font-size:.9rem}.detail-img.jsx-ae9d04ff6a70b9eb{height:370px;width:585px!important}.map_sectionD.jsx-ae9d04ff6a70b9eb{height:55vh}}@media screen and (max-width:1024px){h2.jsx-ae9d04ff6a70b9eb{font-size:1.7rem}h3.jsx-ae9d04ff6a70b9eb{color:#4f4a4c;font-size:1.3rem}h5.jsx-ae9d04ff6a70b9eb{font-size:.9rem;color:#4f4a4c}h6.jsx-ae9d04ff6a70b9eb{color:#373435;font-size:.8rem}.detail-img.jsx-ae9d04ff6a70b9eb{height:375px;width:550px!important}.map_sectionD.jsx-ae9d04ff6a70b9eb{height:45vh}@media screen and (max-width:425px){.location.jsx-ae9d04ff6a70b9eb{width:85px;height:62px}.detail-img.jsx-ae9d04ff6a70b9eb{height:300px}.map_sectionD.jsx-ae9d04ff6a70b9eb{height:45vh}}}"
            })
        ]
    });
};
Details.getInitialProps = async ({ req , res  })=>{
    let currentPageUrl = "";
    if (req) {
        currentPageUrl = req.url;
    } else if (res) {
        currentPageUrl = res.socket.parser.incoming.originalUrl;
    }
    return {
        currentPageUrl
    };
};
// export async function getServerSideProps(context,  req, res ) {
//   // Fetch data from external API
//   const { category_name, meta_title } = context.query;
//     let currentPageUrl = '';
//   if (req) {
//     currentPageUrl = req.url;
//   } else if (res) {
//     currentPageUrl = res.socket.parser.incoming.originalUrl;
//   }
//   const { data } = await instance.post("seedetails", {
//         // if (category_name && meta_title) {
//         meta_title: meta_title,
//         category_name: category_name,
//       // };
//       });
//   return { props: { data, currentPageUrl } };
// }
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Details);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8982:
/***/ ((module) => {

module.exports = require("cookies-next");

/***/ }),

/***/ 3918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 5832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 358:
/***/ ((module) => {

module.exports = require("react-bootstrap");

/***/ }),

/***/ 1937:
/***/ ((module) => {

module.exports = require("react-bootstrap/Button");

/***/ }),

/***/ 5226:
/***/ ((module) => {

module.exports = require("react-bootstrap/Form");

/***/ }),

/***/ 2563:
/***/ ((module) => {

module.exports = require("react-bootstrap/InputGroup");

/***/ }),

/***/ 2540:
/***/ ((module) => {

module.exports = require("react-bootstrap/Nav");

/***/ }),

/***/ 4934:
/***/ ((module) => {

module.exports = require("react-bootstrap/Navbar");

/***/ }),

/***/ 567:
/***/ ((module) => {

module.exports = require("react-icons/bs");

/***/ }),

/***/ 8866:
/***/ ((module) => {

module.exports = require("react-icons/gi");

/***/ }),

/***/ 924:
/***/ ((module) => {

module.exports = require("react-icons/im");

/***/ }),

/***/ 4041:
/***/ ((module) => {

module.exports = require("react-icons/md");

/***/ }),

/***/ 4152:
/***/ ((module) => {

module.exports = require("react-icons/tb");

/***/ }),

/***/ 1740:
/***/ ((module) => {

module.exports = require("react-icons/tfi");

/***/ }),

/***/ 4508:
/***/ ((module) => {

module.exports = require("react-responsive-carousel");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9816:
/***/ ((module) => {

module.exports = require("styled-jsx/style");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 3590:
/***/ ((module) => {

module.exports = import("react-toastify");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [1598,2636,5675,735,29,1664,5152,1889,9293,6826,3484], () => (__webpack_exec__(8796)));
module.exports = __webpack_exports__;

})();