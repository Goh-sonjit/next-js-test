"use strict";
(() => {
var exports = {};
exports.id = 4405;
exports.ids = [4405,2197,9246];
exports.modules = {

/***/ 3673:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_navbar_fixednavbar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6826);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _allApi_apis__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1889);
/* harmony import */ var _components_mediaComponents_MainUi__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4849);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_navbar_fixednavbar__WEBPACK_IMPORTED_MODULE_1__, _allApi_apis__WEBPACK_IMPORTED_MODULE_5__, _components_mediaComponents_MainUi__WEBPACK_IMPORTED_MODULE_6__]);
([_components_navbar_fixednavbar__WEBPACK_IMPORTED_MODULE_1__, _allApi_apis__WEBPACK_IMPORTED_MODULE_5__, _components_mediaComponents_MainUi__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const Media = (props)=>{
    const ErrorPage = next_dynamic__WEBPACK_IMPORTED_MODULE_7___default()(()=>__webpack_require__.e(/* import() */ 8560).then(__webpack_require__.bind(__webpack_require__, 8560)), {
        loadableGenerated: {
            modules: [
                "[category_name]\\index.jsx -> " + "../404"
            ]
        }
    });
    const Metatag = props.MetaKeys;
    const Canonicaltag = props.currentPageUrl;
    const [noOfLogo, setnoOfLogo] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(16);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const [value, setValue] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const [focus, setFocus] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const [locationData, setlocationData] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]);
    const [mediaData, setMediadata] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]);
    const [categoryData, setcategoryData] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]);
    const [search, setSearch] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]);
    const { category_name  } = router.query;
    const SelectServc = async (obj)=>{
        _allApi_apis__WEBPACK_IMPORTED_MODULE_5__/* .CityNameImage.forEach */ .xe.forEach((el)=>{
            el.value2 = el.value === obj.value ? true : false;
        });
        router.push(`/${obj.value}`);
    };
    const getData = async ()=>{
        const noofPage = parseInt(noOfLogo + 3);
        let data = [];
        if (category_name) {
            if (category_name.includes("-")) {
                data = await (0,_allApi_apis__WEBPACK_IMPORTED_MODULE_5__/* .mediaApi */ .XF)(category_name, noofPage);
                setSearch(data);
            } else {
                data = await (0,_allApi_apis__WEBPACK_IMPORTED_MODULE_5__/* .getCityDataApi */ .$F)(category_name);
                setSearch(data);
            }
        }
    };
    const apiforFillters = async ()=>{
        const data = await (0,_allApi_apis__WEBPACK_IMPORTED_MODULE_5__/* .mediaApi */ .XF)(category_name, noOfLogo);
        setMediadata(data);
        setlocationData(data);
        setcategoryData(data);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        getData();
        apiforFillters();
    }, [
        category_name,
        noOfLogo
    ]);
    const onSearch = async (searchCity)=>{
        setValue(searchCity);
        setFocus(false);
        router.push(`/${category_name}/${searchCity}`);
    };
    let city = "";
    const validCategories = [
        "traditional-ooh-media",
        "digital-media",
        "mall-media",
        "office-media",
        "transit-media",
        "airport-media",
        "inflight-media",
        "delhi",
        "pune",
        "chennai",
        "bengaluru",
        "mumbai",
        "hyderabad"
    ];
    if (validCategories.includes(category_name)) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_head__WEBPACK_IMPORTED_MODULE_4___default()), {
                    children: Metatag.map((el)=>{
                        if (category_name === el.value) {
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                                        rel: "canonical",
                                        href: `https://www.gohoardings.com${Canonicaltag}`
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                                        children: el.page_titel
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                                        charSet: "utf-8"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                                        rel: "icon",
                                        href: "https://www.gohoardings.com/assets/images/favicon.png"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                                        name: "viewport",
                                        content: "width=device-width, initial-scale=1"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                                        name: "theme-color",
                                        content: "#000000"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                                        name: "description",
                                        content: el.page_decri
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                                        name: "google-site-verification",
                                        content: "fLT70DRZGdH5FUdrS8w1k2Zg_VTzNJGDF9ie9v4FAzM"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                                        name: "keywords",
                                        content: el.meta_keyword
                                    })
                                ]
                            });
                        }
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_navbar_fixednavbar__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_mediaComponents_MainUi__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                    noOfLogo: noOfLogo,
                    setnoOfLogo: setnoOfLogo,
                    categoryData: categoryData,
                    mediaData: mediaData,
                    locationData: locationData,
                    setSearch: setSearch,
                    category_name: category_name,
                    search: search,
                    onSearch: onSearch,
                    SelectServc: SelectServc,
                    value: value,
                    focus: focus,
                    serviceIcon: _allApi_apis__WEBPACK_IMPORTED_MODULE_5__/* .CityNameImage */ .xe,
                    city: city,
                    setValue: setValue,
                    setFocus: setFocus
                })
            ]
        });
    } else {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ErrorPage, {})
        });
    }
};
Media.getInitialProps = async ({ req , res  })=>{
    let currentPageUrl = "";
    if (req) {
        currentPageUrl = req.url;
    } else if (res) {
        currentPageUrl = res.socket.parser.incoming.originalUrl;
    }
    const MetaKeys = [
        {
            value: "traditional-ooh-media",
            page_titel: "Outdoor Advertising Agency in India | OOH in India | Gohoardings",
            page_decri: "Gohoarding is the leading company of OOH Advertising agency in India. Gohoardings provide Hoardings across  India at best price. | Gohoardings Solution LLP",
            meta_keyword: "OOH Advertising in India, Outdoor Advertising in India, Hoardings Company in India, OOH Branding in India, Hoardings Agency in India, Billboard Advertising in India, Hoarding Rates in India, Outdoor Publicity Company in India, Unipole Advertising in India. Bus Shelter, Pole Kiosk Advertising, Gohoardings Solution in India"
        },
        {
            value: "digital-media",
            page_titel: "Digital OOH Advertising Agency | Digital OOH in India | Gohoardings",
            page_decri: "Gohoarding is the Leading Company of Digital OOH Advertising Agency in India. Gohoardings provides Digital Hoarding across India at best price | Gohoardings Solution",
            meta_keyword: "Digital OOH Advertising in India, Outdoor Advertising in India, Digital Billboard Agency in India, Digital OOH Advertising details, Rates, And services in India, Digital OOH, Outdoor Advertising, Traditional OOH, Internet Advertising, OOH news India, OOH Industry"
        },
        {
            value: "mall-media",
            page_titel: "Mall Advertising Agency in India, Advertising in Malls | Gohoardings",
            page_decri: "Gohoardings is one of the leading Mall Advertising Agency in India, Which helps brands to grow their brands with Advertising in Malls and supermarkets. | Gohoardings",
            meta_keyword: "Mall Advertising in India, Mall Ads India, Mall Marketing In India, Advertising in Malls India, Mall Branding India, Mall Promotions India, Mall Events India, Mall Activations India, Digital Mall Advertising in India, Retail Mall Advertising in India, Mall Advertising Solutions in India, Mall Signage India, Mall Advertising Rates India"
        },
        {
            value: "office-media",
            page_titel: "Office Branding Company in India, Office Hoardings | Gohoardings",
            page_decri: "Office Branding Company in India, It is helpful for business for brand awareness, Office Space Advertising, Office Branding in India | Gohoardings Solution LLP",
            meta_keyword: "Office Space Advertising, Tech Park Branding,Software Offices,Office Branding, Co-woking office space branding, Office Branding Agency in Mumbai, India, Branding agencies in India"
        },
        {
            value: "transit-media",
            page_titel: "Transit Advertising company in Delhi | Gohoardings Solution LLP",
            page_decri: "Go Hoardings offers a wide range of transit media advertising solutions to help you reach your target audience, Train, Mobile Van, State Roadways Buses, Auto Rickshaws, Metro and local train Advertising.",
            meta_keyword: "Transit Media Advertising Company Delhi, Transit Media Company Mumbai, Transportation Ads Company India, Transit Media Advertising Agency, Transportation Ads Company, Advertising in Auto Rickshaws, Advertising in State Roadways Buses, Advertising in Metro Feeder Buses, Advertising in Tarmac Coaches, Advertising in Cabs, Advertising in Delhi Metro"
        },
        {
            value: "airport-media",
            page_titel: "Airport Advertising Company in India, Airport Branding | Gohoardings",
            page_decri: "Airport Advertising Company in India, Showcase your brand in Airports. Get the more attention on you brands with help of Airport & Airlines ads | Gohoardings.com",
            meta_keyword: "Airport Advertising, Airlines Advertising, Airport Advertising Rates, Airport Advertising Company in Noida, India, Airport Ad Company in Delhi, Airport Branding Agency in India, Indian Airport Advertising Company in Delhi, Delhi Airport Branding, Airlines Advertising"
        },
        {
            value: "inflight-media",
            page_titel: "Inflight Advertising Agency in Noida, India | Gohoardings Solution",
            page_decri: "India's Leading Inflight Advertising Agency in Noida, India, We are in contact with many airlines in India providing the solution for Inflight Advertising Options. We surely help you to achieve this by displaying your ad on boarding passes and baggage tags. | Gohoardings Solutions.",
            meta_keyword: "Inflight Advertising, Advertising in Hello 6E Magazine, Advertising in Indigo In-flight Magazine, Advertising in Spice Route Magazine, Advertising in Spice Jet In-flight Magazine, Advertising in Go Air In-flight Magazine, Advertising in Jet Wings Magazine, Advertising in Jet Airways Inflight Magazine, Advertising in Air India Inflight Magazine, Advertising in Shubh Yatra Magazine, Advertising in Go Getter Inflight Magazine, Advertising on Airport  Luggage Trolleys, Advertising on Meal Tray in Airlines, Advertising on Seat Back Devices, Advertising in Vistara inflight Magazine"
        }
    ];
    return {
        MetaKeys,
        currentPageUrl
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Media);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8982:
/***/ ((module) => {

module.exports = require("cookies-next");

/***/ }),

/***/ 3918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 5832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 358:
/***/ ((module) => {

module.exports = require("react-bootstrap");

/***/ }),

/***/ 1937:
/***/ ((module) => {

module.exports = require("react-bootstrap/Button");

/***/ }),

/***/ 5226:
/***/ ((module) => {

module.exports = require("react-bootstrap/Form");

/***/ }),

/***/ 2563:
/***/ ((module) => {

module.exports = require("react-bootstrap/InputGroup");

/***/ }),

/***/ 2540:
/***/ ((module) => {

module.exports = require("react-bootstrap/Nav");

/***/ }),

/***/ 4934:
/***/ ((module) => {

module.exports = require("react-bootstrap/Navbar");

/***/ }),

/***/ 567:
/***/ ((module) => {

module.exports = require("react-icons/bs");

/***/ }),

/***/ 8866:
/***/ ((module) => {

module.exports = require("react-icons/gi");

/***/ }),

/***/ 1111:
/***/ ((module) => {

module.exports = require("react-icons/hi");

/***/ }),

/***/ 924:
/***/ ((module) => {

module.exports = require("react-icons/im");

/***/ }),

/***/ 4041:
/***/ ((module) => {

module.exports = require("react-icons/md");

/***/ }),

/***/ 4152:
/***/ ((module) => {

module.exports = require("react-icons/tb");

/***/ }),

/***/ 1740:
/***/ ((module) => {

module.exports = require("react-icons/tfi");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9816:
/***/ ((module) => {

module.exports = require("styled-jsx/style");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [1598,2636,5675,735,29,1664,5152,1889,9293,6826,3484,4849], () => (__webpack_exec__(3673)));
module.exports = __webpack_exports__;

})();