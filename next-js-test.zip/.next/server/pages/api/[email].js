(() => {
var exports = {};
exports.id = 6942;
exports.ids = [6942];
exports.modules = {

/***/ 8432:
/***/ ((module) => {

"use strict";
module.exports = require("bcryptjs");

/***/ }),

/***/ 4802:
/***/ ((module) => {

"use strict";
module.exports = require("cookie");

/***/ }),

/***/ 9344:
/***/ ((module) => {

"use strict";
module.exports = require("jsonwebtoken");

/***/ }),

/***/ 2744:
/***/ ((module) => {

"use strict";
module.exports = require("mysql");

/***/ }),

/***/ 5184:
/***/ ((module) => {

"use strict";
module.exports = require("nodemailer");

/***/ }),

/***/ 7773:
/***/ ((module) => {

"use strict";
module.exports = require("redis");

/***/ }),

/***/ 8910:
/***/ ((module) => {

"use strict";
module.exports = require("request");

/***/ }),

/***/ 5616:
/***/ ((module) => {

"use strict";
module.exports = import("next-connect");;

/***/ }),

/***/ 7147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 2333:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_connect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5616);
/* harmony import */ var _server_utils_error__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(326);
/* harmony import */ var _server_utils_error__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_server_utils_error__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _server_controller_otp__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8938);
/* harmony import */ var _server_sitemapdata__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7530);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([next_connect__WEBPACK_IMPORTED_MODULE_0__]);
next_connect__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const handler = (0,next_connect__WEBPACK_IMPORTED_MODULE_0__["default"])({
    error: (_server_utils_error__WEBPACK_IMPORTED_MODULE_1___default())
});
handler.patch(_server_controller_otp__WEBPACK_IMPORTED_MODULE_2__/* .sendOTP */ .OA);
handler.put(_server_controller_otp__WEBPACK_IMPORTED_MODULE_2__/* .sendPasswordEmail */ .td);
handler.get(_server_controller_otp__WEBPACK_IMPORTED_MODULE_2__/* .checkOTP */ .wf);
handler.post(_server_sitemapdata__WEBPACK_IMPORTED_MODULE_3__/* .SiteMapProduct */ .N);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handler);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8798:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

const nodemailer = __webpack_require__(5184);
exports.sendEmail = async (options)=>{
    var transport = nodemailer.createTransport({
        host: process.env.EMAIL_HOST,
        port: process.env.EMAIL_PORT,
        secureConnection: true,
        auth: {
            user: process.env.EMAIL_USER,
            pass: process.env.EMAIL_PASS
        }
    });
    const mailOptions = {
        from: process.env.EMAIL_USER,
        to: options.email,
        subject: options.subject,
        text: options.message,
        attachments: options.attachments
    };
    transport.sendMail(mailOptions, function(error, response) {
        if (error) {
            return error;
        } else {
            return true;
        }
    // if you don't want to use this transport object anymore, uncomment following line
    //smtpTransport.close(); // shut down the connection pool, no more messages
    });
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [4806,326,3383,8938,7530], () => (__webpack_exec__(2333)));
module.exports = __webpack_exports__;

})();