"use strict";
(() => {
var exports = {};
exports.id = 5039;
exports.ids = [5039];
exports.modules = {

/***/ 8432:
/***/ ((module) => {

module.exports = require("bcryptjs");

/***/ }),

/***/ 4802:
/***/ ((module) => {

module.exports = require("cookie");

/***/ }),

/***/ 9344:
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ 1738:
/***/ ((module) => {

module.exports = require("multer");

/***/ }),

/***/ 2744:
/***/ ((module) => {

module.exports = require("mysql");

/***/ }),

/***/ 3284:
/***/ ((module) => {

module.exports = require("next-connect");

/***/ }),

/***/ 8910:
/***/ ((module) => {

module.exports = require("request");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 4067:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _server_controller_REGISTERlOGIN__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5276);
/* harmony import */ var _server_middelware_token__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3383);


const multer = __webpack_require__(1738);
const nc = __webpack_require__(3284);
const path = __webpack_require__(1017);
const handle = nc();
const config = {
    api: {
        bodyParser: false
    }
};
const imageConfig = multer.diskStorage({
    destination: (req, file, callback)=>{
        callback(null, "public/images/profile_image");
    },
    filename: (req, file, callback)=>{
        callback(null, file.fieldname + "_" + Date.now() + path.extname(file.originalname));
    }
});
const upload = multer({
    storage: imageConfig
});
const isImage = upload.single("file");
handle.use(isImage);
handle.post(_server_middelware_token__WEBPACK_IMPORTED_MODULE_1__.verifyToken, _server_controller_REGISTERlOGIN__WEBPACK_IMPORTED_MODULE_0__/* .updateImage */ .gO);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handle);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [4806,3383,5276], () => (__webpack_exec__(4067)));
module.exports = __webpack_exports__;

})();