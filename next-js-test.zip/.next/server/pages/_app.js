(() => {
var exports = {};
exports.id = 2888;
exports.ids = [2888,9371,476,6726,3329,3775,9246,9662,4670];
exports.modules = {

/***/ 9547:
/***/ ((module) => {

// Exports
module.exports = {
	"mobilenav": "mobileNav_mobilenav___H3CZ",
	"navbrand": "mobileNav_navbrand__Vs5aP",
	"search_logo": "mobileNav_search_logo__jPrgE"
};


/***/ }),

/***/ 5563:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9816);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9306);
/* harmony import */ var react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _allApi_apicontext__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3484);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6652);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_icons_bi__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var cookies_next__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8982);
/* harmony import */ var cookies_next__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(cookies_next__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4041);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_icons_md__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3590);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _allApi_apis__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(1889);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_allApi_apicontext__WEBPACK_IMPORTED_MODULE_6__, react_toastify__WEBPACK_IMPORTED_MODULE_12__, _allApi_apis__WEBPACK_IMPORTED_MODULE_14__]);
([_allApi_apicontext__WEBPACK_IMPORTED_MODULE_6__, react_toastify__WEBPACK_IMPORTED_MODULE_12__, _allApi_apis__WEBPACK_IMPORTED_MODULE_14__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);















const Footer = ()=>{
    const route = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const [serviceIcon, setServiceIcon] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(_allApi_apis__WEBPACK_IMPORTED_MODULE_14__/* .CityNameImage */ .xe);
    const [email, setEmail] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]);
    const { handleClose , handleShow , show  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(_allApi_apicontext__WEBPACK_IMPORTED_MODULE_6__/* .AccountContext */ .w0);
    const LoginN = next_dynamic__WEBPACK_IMPORTED_MODULE_8___default()(()=>Promise.all(/* import() */[__webpack_require__.e(9332), __webpack_require__.e(5985), __webpack_require__.e(3462), __webpack_require__.e(6413), __webpack_require__.e(7733), __webpack_require__.e(9083), __webpack_require__.e(3651)]).then(__webpack_require__.bind(__webpack_require__, 3651)), {
        loadableGenerated: {
            modules: [
                "..\\components\\footer.jsx -> " + "@/pages/login/loginParent"
            ]
        }
    });
    const handelSubmit = async (e)=>{
        let count = 0;
        e.preventDefault();
        if (!_allApi_apis__WEBPACK_IMPORTED_MODULE_14__/* .emailformate.test */ .mX.test(email)) {
            count = +1;
        } else if (count === 0) {
            const data = await (0,_allApi_apis__WEBPACK_IMPORTED_MODULE_14__/* .enquiryApi */ .CL)(email);
            if (data.success == true) {
                setEmail("");
                (0,react_toastify__WEBPACK_IMPORTED_MODULE_12__.toast)("Thank for becoming our member, You will get best deals from us.");
            }
        }
    };
    const services = [
        ...serviceIcon
    ];
    const direactMedia = (e)=>{
        (0,cookies_next__WEBPACK_IMPORTED_MODULE_10__.setCookie)("category_name", e);
        (0,cookies_next__WEBPACK_IMPORTED_MODULE_10__.setCookie)("city_name", "delhi");
        services.map((el)=>{
            if (el.value == e) {
                el.value2 = true;
            }
            if (el.value !== e) {
                el.value2 = false;
            }
        });
        setServiceIcon(services);
        route.push(`/${e}`);
    };
    const logo = [
        {
            id: 1,
            img: "/images/web_pics/facebook.png",
            alt: "logo1",
            link: "https://www.facebook.com/gohoardings/"
        },
        {
            id: 2,
            img: "/images/web_pics/insta.png",
            alt: "logo2",
            link: "https://www.instagram.com/gohoardings/"
        },
        {
            id: 3,
            img: "/images/web_pics/twiter.png",
            alt: "logo3",
            link: "https://twitter.com/gohoardings"
        },
        {
            id: 4,
            img: "/images/web_pics/linkdin.png",
            alt: "logo4",
            link: "https://www.linkedin.com/company/gohoardings/"
        },
        {
            id: 5,
            img: "/images/web_pics/meail.png",
            alt: "logo5",
            link: "mailto:info@gohoardings.com"
        }
    ];
    const cities = [
        {
            name: "Delhi",
            city: "delhi"
        },
        {
            name: "Pune",
            city: "pune"
        },
        {
            name: "Bengaluru",
            city: "bengaluru"
        },
        {
            name: "Chennai",
            city: "chennai"
        },
        {
            name: "Hyderabad",
            city: "hyderabad"
        },
        {
            name: "Mumbai",
            city: "mumbai"
        }
    ];
    const direactCity = (e)=>{
        (0,cookies_next__WEBPACK_IMPORTED_MODULE_10__.setCookie)("category_name", "traditional-media");
        (0,cookies_next__WEBPACK_IMPORTED_MODULE_10__.setCookie)("city_name", e);
        const services = [
            ...serviceIcon
        ];
        services.map((el)=>{
            el.value2 = false;
        });
        setServiceIcon(services);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "jsx-7ea048adc8eba943" + " " + " footerN-content  pb-3  p-0 px-3 px-md-5 py-md-1  pt-md-5 ",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "jsx-7ea048adc8eba943" + " " + "row footer-branding pb-md-4 pb-2",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "jsx-7ea048adc8eba943" + " " + "col-md-3 pt-3 pt-md-1 ",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                    href: "/",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_13___default()), {
                                        width: 245,
                                        height: 43,
                                        src: "/images/web_pics/logo.png",
                                        alt: "gohoardings",
                                        className: "brand-logo-footer "
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "jsx-7ea048adc8eba943" + " " + "col-md-9 ",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                        className: "jsx-7ea048adc8eba943" + " " + "f-heading pt-2 pt-md-0",
                                        children: "India's Largest Outdoor Advertising Company"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                        className: "jsx-7ea048adc8eba943" + " " + "f-second-heading pt-1",
                                        children: "It's advertising network spread across 130 cities with more than 1.2 lakh OOH and DOOH sites offering hassle free branding experiences at an unmatched price."
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "jsx-7ea048adc8eba943" + " " + "row pt-3",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "jsx-7ea048adc8eba943" + " " + "col  py-md-3 ms-md-2 quick-links",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                        className: "jsx-7ea048adc8eba943" + " " + "   f-heading",
                                        children: "Quick Links"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                        className: "jsx-7ea048adc8eba943" + " " + "position-relative  pt-md-3  ps-0",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                                className: "jsx-7ea048adc8eba943" + " " + "py-md-2",
                                                children: [
                                                    " ",
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                        href: "https://odoads.com/register",
                                                        target: "_blank",
                                                        className: "jsx-7ea048adc8eba943" + " " + " text-decoration-none f-heading-clr  mb-0",
                                                        children: "Login As Media Owner"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                onClick: handleShow,
                                                id: "footerPopUp",
                                                className: "jsx-7ea048adc8eba943" + " " + "py-md-2 text-decoration-none f-heading-clr ",
                                                children: "Login As Advertiser"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                className: "jsx-7ea048adc8eba943" + " " + "pos-absolute",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        className: "jsx-7ea048adc8eba943" + " " + "py-md-2",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                            href: "https://www.odoads.com/",
                                                            target: "_blank",
                                                            className: "jsx-7ea048adc8eba943" + " " + " text-decoration-none f-heading-clr mb-0",
                                                            children: "Odoads"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        className: "jsx-7ea048adc8eba943" + " " + " text-decoration-none f-heading-clr mb-0 py-md-2",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                            href: "https://blog.gohoardings.com/",
                                                            target: "_blank",
                                                            className: "jsx-7ea048adc8eba943" + " " + " text-decoration-none f-heading-clr mb-0",
                                                            children: "Blog"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                                        className: "jsx-7ea048adc8eba943" + " " + "py-md-2",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                onClick: ()=>route.push("/about-us"),
                                                                className: "jsx-7ea048adc8eba943" + " " + " text-decoration-none f-heading-clr mb-0",
                                                                children: "About Us"
                                                            }),
                                                            " "
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        className: "jsx-7ea048adc8eba943" + " " + "py-md-2",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            onClick: ()=>route.push("/team"),
                                                            className: "jsx-7ea048adc8eba943" + " " + " text-decoration-none f-heading-clr mb-0",
                                                            children: "Team"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        className: "jsx-7ea048adc8eba943" + " " + "py-md-2",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            onClick: ()=>route.push("/contact-us"),
                                                            className: "jsx-7ea048adc8eba943" + " " + " text-decoration-none f-heading-clr mb-0",
                                                            children: "Contact"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                                        className: "jsx-7ea048adc8eba943" + " " + "py-md-2 text-decoration-none ",
                                                        children: [
                                                            " ",
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                onClick: ()=>route.push("/privacy"),
                                                                className: "jsx-7ea048adc8eba943" + " " + " f-heading-clr mb-0",
                                                                children: "Privacy Policy"
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "jsx-7ea048adc8eba943" + " " + "col py-md-3 ms-md-2 popular-media",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                        className: "jsx-7ea048adc8eba943" + " " + " f-heading",
                                        children: "Popular Services"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                        className: "jsx-7ea048adc8eba943" + " " + " pt-md-3   ps-0",
                                        children: _allApi_apis__WEBPACK_IMPORTED_MODULE_14__/* .CityNameImage.map */ .xe.map((el, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                onClick: (e)=>direactMedia(el.value),
                                                className: "jsx-7ea048adc8eba943" + " " + " py-md-2  text-decoration-none f-heading-clr",
                                                children: el.label
                                            }, i))
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "jsx-7ea048adc8eba943" + " " + "col  py-md-3 ms-md-2 p-md-1",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                        className: "jsx-7ea048adc8eba943" + " " + "   f-heading",
                                        children: "Trending Cities"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                        className: "jsx-7ea048adc8eba943" + " " + " pt-md-3   ps-0 ",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "jsx-7ea048adc8eba943" + " " + "pos-absolute end-0 top-0 me-5",
                                            children: cities.map((el, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                    href: `/${el.city}`,
                                                    className: "text-decoration-none ",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        onClick: (e)=>direactCity(el.city),
                                                        className: "jsx-7ea048adc8eba943" + " " + " py-md-2  text-decoration-none f-heading-clr ",
                                                        children: el.name
                                                    })
                                                }, i))
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "jsx-7ea048adc8eba943" + " " + "col  py-md-3",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                        className: "jsx-7ea048adc8eba943" + " " + "  f-heading",
                                        children: "Reach us"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                        className: "jsx-7ea048adc8eba943" + " " + " pt-md-3  ps-0",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                                className: "jsx-7ea048adc8eba943" + " " + "py-md-2 reach-clr py-md-2 py-1",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_7__.FiPhoneCall, {
                                                        className: "me-3 icon-clr"
                                                    }),
                                                    " +91 7777871717"
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                                className: "jsx-7ea048adc8eba943" + " " + "py-md-2 reach-clr py-md-2 py-1",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bi__WEBPACK_IMPORTED_MODULE_9__.BiMailSend, {
                                                        className: "me-3 icon-clr"
                                                    }),
                                                    "info@gohoardings.com"
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                                className: "jsx-7ea048adc8eba943" + " " + "d-flex reach-clr py-md-3 py-1",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_11__.MdLocationOn, {
                                                        className: "me-3 icon-clr mt-1"
                                                    }),
                                                    " ",
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                        className: "jsx-7ea048adc8eba943" + " " + "reach-clr",
                                                        children: [
                                                            "E-82, Sector 06",
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {
                                                                className: "jsx-7ea048adc8eba943"
                                                            }),
                                                            "Noida, 201301 (U.P.)"
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "jsx-7ea048adc8eba943" + " " + "grid-container1 ",
                                                children: logo.map((clients, index)=>{
                                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "jsx-7ea048adc8eba943" + " " + "grid-item",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                            href: clients.link,
                                                            target: "_blank",
                                                            className: "jsx-7ea048adc8eba943",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_13___default()), {
                                                                width: 27,
                                                                height: 27,
                                                                src: clients.img,
                                                                alt: clients.alt,
                                                                className: "img-fluid logo-img"
                                                            })
                                                        })
                                                    }, index);
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "jsx-7ea048adc8eba943" + " " + "row  payment-footer-section ",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                id: "letHide",
                                className: "jsx-7ea048adc8eba943" + " " + "col text-light d-none d-md-block"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "jsx-7ea048adc8eba943" + " " + "col text-light  mt-md-0 d-none d-md-block"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "jsx-7ea048adc8eba943" + " " + "col text-light  offset-md-3 d-none d-md-block",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                        className: "jsx-7ea048adc8eba943" + " " + "f-heading  text-nowrap  ",
                                        children: "Best deals in your inbox"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                        onSubmit: handelSubmit,
                                        className: "jsx-7ea048adc8eba943" + " " + "d-flex  p-2 ps-md-1 pt-1 ps-0 smv",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "email",
                                                value: email,
                                                autoComplete: "off",
                                                placeholder: "Enter you email address",
                                                formcontrolname: "email",
                                                id: "footer-input",
                                                onChange: (e)=>setEmail(e.target.value),
                                                className: "jsx-7ea048adc8eba943" + " " + "text-dark border-0  p-2 cnt-input-box rounded-start mt-md-2 "
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                                type: "submit",
                                                className: "jsx-7ea048adc8eba943" + " " + " btn   w-25  border-0 rounded-0 rounded-end mt-md-2 p-0",
                                                children: [
                                                    "Contact",
                                                    " "
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_toastify__WEBPACK_IMPORTED_MODULE_12__.ToastContainer, {})
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                        className: "jsx-7ea048adc8eba943" + " " + " py-0 text-muted head6",
                                        children: "* Join our newsletter for the most recent information."
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "jsx-7ea048adc8eba943" + " " + "row my-2 text-center",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: "jsx-7ea048adc8eba943" + " " + "  text-light f-heading-clr ",
                            children: "copyrights \xa9 2023 Gohoardings Solutions LLP"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Modal__WEBPACK_IMPORTED_MODULE_5___default()), {
                show: show,
                onHide: handleClose,
                "aria-labelledby": "contained-modal-title-vcenter",
                centered: true,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(LoginN, {
                    className: "jsx-7ea048adc8eba943"
                })
            }),
            react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default()), {
                id: "7ea048adc8eba943",
                children: "#not-work.jsx-7ea048adc8eba943{color:rgb(220,220,220);font-size:1.1rem}cnt-input-box.jsx-7ea048adc8eba943:focus{border:none}#footer-input.jsx-7ea048adc8eba943:focus{outline:none}.footerN-content.jsx-7ea048adc8eba943{background-color:#212121}button.jsx-7ea048adc8eba943{color:black;font-weight:500;background-color:#fff323}button.jsx-7ea048adc8eba943:hover{color:black;font-weight:500;background-color:#ede111}.footer-branding.jsx-7ea048adc8eba943{border-bottom:2px solid rgb(211,211,211)}.brand-logo-footer.jsx-7ea048adc8eba943{width:240px}.f-heading.jsx-7ea048adc8eba943{color:#ffff;font-size:1.5rem;font-weight:600}.f-second-heading.jsx-7ea048adc8eba943{color:rgb(220,220,220);font-size:1rem;font-weight:400}.f-heading-clr.jsx-7ea048adc8eba943{color:rgb(220,220,220);font-size:1rem;cursor:pointer}.f-heading-clr.jsx-7ea048adc8eba943:hover{color:#fff320}.reach-clr.jsx-7ea048adc8eba943{color:rgb(220,220,220);font-size:1rem}li.jsx-7ea048adc8eba943{list-style-type:none}.grid-container1.jsx-7ea048adc8eba943{width:300px;display:grid;grid-template-columns:1fr 1fr 1fr 1fr 1fr}#footerPopUp.jsx-7ea048adc8eba943{cursor:pointer}.grid-item.jsx-7ea048adc8eba943{-webkit-transition:-webkit-transform.3s;-moz-transition:-moz-transform.3s;-o-transition:-o-transform.3s;transition:-webkit-transform.3s;transition:-moz-transform.3s;transition:-o-transform.3s;transition:transform.3s;text-align:start}.logo-img.jsx-7ea048adc8eba943{height:28px;width:28px}.tawk-min-container.jsx-7ea048adc8eba943 .tawk-button-circle.tawk-button-large.jsx-7ea048adc8eba943{background-color:#d5d509!important}.grid-item.jsx-7ea048adc8eba943:hover{-webkit-transform:scale(1.2);-moz-transform:scale(1.2);-ms-transform:scale(1.2);-o-transform:scale(1.2);transform:scale(1.2)}.payment-footer-section.jsx-7ea048adc8eba943{margin-top:-3%}@media screen and (max-width:1366px){.brand-logo-footer.jsx-7ea048adc8eba943{width:190px!important}.f-heading.jsx-7ea048adc8eba943{font-size:1.5rem}.reach-clr.jsx-7ea048adc8eba943{font-size:1.1rem}.grid-container1.jsx-7ea048adc8eba943{width:260px}.grid-item.jsx-7ea048adc8eba943{text-align:start}.logo-img.jsx-7ea048adc8eba943{height:26px;width:26px}}@media screen and (max-width:1024px){.brand-logo-footer.jsx-7ea048adc8eba943{width:130px!important}.f-heading.jsx-7ea048adc8eba943{font-size:1rem}.f-second-heading.jsx-7ea048adc8eba943{font-size:.8rem}.f-heading-clr.jsx-7ea048adc8eba943{font-size:.8rem}.reach-clr.jsx-7ea048adc8eba943{font-size:.8rem}.grid-container1.jsx-7ea048adc8eba943{width:230px}.grid-item.jsx-7ea048adc8eba943{text-align:start}.logo-img.jsx-7ea048adc8eba943{height:20px;width:20px}#letHide.jsx-7ea048adc8eba943{display:none}.smv.jsx-7ea048adc8eba943{height:45px}.head6.jsx-7ea048adc8eba943{font-size:.6rem}}"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7617:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4041);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_md__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _styles_mobileNav_module_scss__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9547);
/* harmony import */ var _styles_mobileNav_module_scss__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_styles_mobileNav_module_scss__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_6__);








const Mobilenav = ()=>{
    const Userdetail = next_dynamic__WEBPACK_IMPORTED_MODULE_5___default()(null, {
        loadableGenerated: {
            modules: [
                "..\\components\\navbar\\mobilenav.jsx -> " + "./userdetail"
            ]
        },
        ssr: false
    });
    const route = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "mbilview ",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: `${(_styles_mobileNav_module_scss__WEBPACK_IMPORTED_MODULE_7___default().mobilenav)} fixed-top ps-1 pe-1`,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "m-1",
                        "data-bs-toggle": "offcanvas",
                        "data-bs-target": "#offcanvasScrolling",
                        "aria-controls": "offcanvasScrolling",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_3__.MdMenu, {
                            className: `${(_styles_mobileNav_module_scss__WEBPACK_IMPORTED_MODULE_7___default().search_logo)} `
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_6___default()), {
                        width: 50,
                        height: 30,
                        alt: "gohoardings",
                        src: "/images/web_pics/logo.png",
                        className: `${(_styles_mobileNav_module_scss__WEBPACK_IMPORTED_MODULE_7___default().navbrand)} m-1`,
                        onClick: ()=>route.push("/")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "float-end mt-1 d-flex",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "m-1",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Userdetail, {})
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "offcanvas offcanvas-start",
                "data-bs-scroll": "true",
                "data-bs-backdrop": "false",
                tabIndex: "-1",
                id: "offcanvasScrolling",
                "aria-labelledby": "offcanvasScrollingLabel",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "offcanvas-header",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_6___default()), {
                                width: 50,
                                height: 30,
                                alt: "gohoardings",
                                src: "/images/web_pics/logo.png",
                                className: `${(_styles_mobileNav_module_scss__WEBPACK_IMPORTED_MODULE_7___default().navbrand)} m-1 mt-0`,
                                onClick: ()=>route.push("/")
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                type: "button",
                                className: "btn-close ",
                                "data-bs-dismiss": "offcanvas",
                                "aria-label": "Close"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "offcanvas-body",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                            className: "list-group list-group-flush",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    className: "list-group-item",
                                    "data-bs-dismiss": "offcanvas",
                                    onClick: ()=>route.push("https://blog.gohoardings.com/"),
                                    children: "Blogs"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    className: "list-group-item",
                                    "data-bs-dismiss": "offcanvas",
                                    onClick: ()=>route.push("/contact-us"),
                                    children: "Contact Us"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    className: "list-group-item",
                                    "data-bs-dismiss": "offcanvas",
                                    onClick: ()=>route.push("/about-us"),
                                    children: "About Us"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    className: "list-group-item",
                                    "data-bs-dismiss": "offcanvas",
                                    onClick: ()=>route.push("/media-and-news"),
                                    children: "News & Media"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    className: "list-group-item",
                                    "data-bs-dismiss": "offcanvas",
                                    onClick: ()=>route.push("/faqs"),
                                    children: "FAQs"
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Mobilenav);


/***/ }),

/***/ 6004:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_globals_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3716);
/* harmony import */ var _styles_globals_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_scss__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_responsive_carousel_lib_styles_carousel_min_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3559);
/* harmony import */ var react_responsive_carousel_lib_styles_carousel_min_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_responsive_carousel_lib_styles_carousel_min_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8278);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(782);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var animate_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5544);
/* harmony import */ var animate_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(animate_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_date_range_dist_styles_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(886);
/* harmony import */ var react_date_range_dist_styles_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_date_range_dist_styles_css__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_date_range_dist_theme_default_css__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8130);
/* harmony import */ var react_date_range_dist_theme_default_css__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_date_range_dist_theme_default_css__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var bootstrap_dist_css_bootstrap_css__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5931);
/* harmony import */ var bootstrap_dist_css_bootstrap_css__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(bootstrap_dist_css_bootstrap_css__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8819);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _allApi_apicontext__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(3484);
/* harmony import */ var _components_footer__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(5563);
/* harmony import */ var _components_navbar_mobilenav__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(7617);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_allApi_apicontext__WEBPACK_IMPORTED_MODULE_13__, _components_footer__WEBPACK_IMPORTED_MODULE_14__]);
([_allApi_apicontext__WEBPACK_IMPORTED_MODULE_13__, _components_footer__WEBPACK_IMPORTED_MODULE_14__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
















function App({ Component , pageProps , session  }) {
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        Promise.resolve(/* import() */).then(__webpack_require__.t.bind(__webpack_require__, 7661, 23));
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_11__.SSRProvider, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_allApi_apicontext__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .ZP, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(next_auth_react__WEBPACK_IMPORTED_MODULE_12__.SessionProvider, {
                    session: session,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_navbar_mobilenav__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                            ...pageProps
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_footer__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {})
            ]
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (App);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5544:
/***/ (() => {



/***/ }),

/***/ 5931:
/***/ (() => {



/***/ }),

/***/ 886:
/***/ (() => {



/***/ }),

/***/ 8130:
/***/ (() => {



/***/ }),

/***/ 3559:
/***/ (() => {



/***/ }),

/***/ 8819:
/***/ (() => {



/***/ }),

/***/ 782:
/***/ (() => {



/***/ }),

/***/ 8278:
/***/ (() => {



/***/ }),

/***/ 3716:
/***/ (() => {



/***/ }),

/***/ 7661:
/***/ ((module) => {

"use strict";
module.exports = require("bootstrap/dist/js/bootstrap.js");

/***/ }),

/***/ 8982:
/***/ ((module) => {

"use strict";
module.exports = require("cookies-next");

/***/ }),

/***/ 1649:
/***/ ((module) => {

"use strict";
module.exports = require("next-auth/react");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 9274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 5832:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 358:
/***/ ((module) => {

"use strict";
module.exports = require("react-bootstrap");

/***/ }),

/***/ 9306:
/***/ ((module) => {

"use strict";
module.exports = require("react-bootstrap/Modal");

/***/ }),

/***/ 67:
/***/ ((module) => {

"use strict";
module.exports = require("react-google-login");

/***/ }),

/***/ 9847:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/ai");

/***/ }),

/***/ 6652:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/bi");

/***/ }),

/***/ 567:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/bs");

/***/ }),

/***/ 178:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/fc");

/***/ }),

/***/ 2750:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/fi");

/***/ }),

/***/ 8866:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/gi");

/***/ }),

/***/ 924:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/im");

/***/ }),

/***/ 4041:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/md");

/***/ }),

/***/ 4152:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/tb");

/***/ }),

/***/ 1740:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/tfi");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9816:
/***/ ((module) => {

"use strict";
module.exports = require("styled-jsx/style");

/***/ }),

/***/ 9648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ }),

/***/ 3590:
/***/ ((module) => {

"use strict";
module.exports = import("react-toastify");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [1598,2636,5675,735,29,1664,5152,1889,3484], () => (__webpack_exec__(6004)));
module.exports = __webpack_exports__;

})();